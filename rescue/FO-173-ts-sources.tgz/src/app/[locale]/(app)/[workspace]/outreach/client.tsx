'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { 
  Mail, 
  Send, 
  Check, 
  Copy, 
  Search, 
  Filter, 
  ShieldCheck, 
  Globe2, 
  ExternalLink,
  Users,
  Award,
  Sparkles,
  RefreshCw,
  Clock,
  ChevronRight,
  SlidersHorizontal,
  BookmarkPlus
} from 'lucide-react';

interface OutreachClientProps {
  locale: string;
  workspace: string;
}

interface Evaluator {
  id: string;
  name: string;
  title: string;
  institution: string;
  country: string;
  countryCode: string;
  nativeLang: string;
  nativeLangName: string;
  domain: string;
  pastCalls: string[];
  relevanceScore: number;
  linkedInUrl: string;
  status: 'new' | 'contacted' | 'replied' | 'meeting_scheduled';
}

const SAMPLE_EVALUATORS: Evaluator[] = [
  {
    id: 'ev-1',
    name: 'Dr. Helena Weber',
    title: 'Senior Research Director & Horizon Cluster 5 Reviewer',
    institution: 'Fraunhofer ISE, Freiburg',
    country: 'Almanya',
    countryCode: 'DE',
    nativeLang: 'de',
    nativeLangName: 'Deutsch (Almanca)',
    domain: 'Clean Energy, Grid Storage, Net-Zero',
    pastCalls: ['HORIZON-CL5-2024-D3', 'HORIZON-CL5-2025-D1'],
    relevanceScore: 98,
    linkedInUrl: 'https://www.linkedin.com/search/results/all/?keywords=Helena+Weber+Fraunhofer',
    status: 'new',
  },
  {
    id: 'ev-2',
    name: 'Prof. Jean-Luc Moreau',
    title: 'CNRS Research Fellow & EIC Pathfinder Evaluator',
    institution: 'CNRS / Sorbonne Université, Paris',
    country: 'Fransa',
    countryCode: 'FR',
    nativeLang: 'fr',
    nativeLangName: 'Français (Fransızca)',
    domain: 'Quantum Computing, DeepTech, Photonics',
    pastCalls: ['HORIZON-EIC-2025-PATHFINDEROPEN', 'HORIZON-CL4-2024-DIGITAL'],
    relevanceScore: 95,
    linkedInUrl: 'https://www.linkedin.com/search/results/all/?keywords=Jean-Luc+Moreau+CNRS',
    status: 'new',
  },
  {
    id: 'ev-3',
    name: 'Dra. Carmen Santos Morales',
    title: 'CSIC Biomaterials Lead & Mission Cancer Reviewer',
    institution: 'CSIC Instituto de Ciencia de Materiales, Madrid',
    country: 'İspanya',
    countryCode: 'ES',
    nativeLang: 'es',
    nativeLangName: 'Español (İspanyolca)',
    domain: 'Health, Biomaterials, Nanomedicine',
    pastCalls: ['HORIZON-MISS-2024-CANCER', 'HORIZON-HLTH-2025-DISEASE'],
    relevanceScore: 92,
    linkedInUrl: 'https://www.linkedin.com/search/results/all/?keywords=Carmen+Santos+CSIC',
    status: 'contacted',
  },
  {
    id: 'ev-4',
    name: 'Dr. Alessandro Riva',
    title: 'Politecnico di Milano Automation & Robotics Lab Head',
    institution: 'Politecnico di Milano, Milano',
    country: 'İtalya',
    countryCode: 'IT',
    nativeLang: 'it',
    nativeLangName: 'Italiano (İtalyanca)',
    domain: 'Robotics, AI in Manufacturing, Industry 5.0',
    pastCalls: ['HORIZON-CL4-2024-TWIN-TRANSITION'],
    relevanceScore: 91,
    linkedInUrl: 'https://www.linkedin.com/search/results/all/?keywords=Alessandro+Riva+Polimi',
    status: 'new',
  },
  {
    id: 'ev-5',
    name: 'Prof. Dr. Jan Kowalski',
    title: 'Wroclaw University of Science / Smart Grids Chair',
    institution: 'Wrocław University of Science and Technology',
    country: 'Polonya',
    countryCode: 'PL',
    nativeLang: 'pl',
    nativeLangName: 'Polski (Lehçe)',
    domain: 'Smart Grid Resilience, Cyber-Physical Systems',
    pastCalls: ['HORIZON-CL5-2025-ENERGY', 'HORIZON-CL3-2024-INFRA'],
    relevanceScore: 89,
    linkedInUrl: 'https://www.linkedin.com/search/results/all/?keywords=Jan+Kowalski+Wroclaw+Tech',
    status: 'meeting_scheduled',
  },
];

const TEMPLATES: Record<string, Record<'de' | 'fr' | 'es' | 'it' | 'pl' | 'en' | 'tr', { subject: string; body: string }>> = {
  consortium_invitation: {
    de: {
      subject: 'Einladung zur Kooperation im Horizon Europe Konsortium: Clean Energy & Smart Grids',
      body: 'Sehr geehrte(r) Frau/Herr Dr. {name},\n\nich verfolge Ihre exzellenten wissenschaftlichen Arbeiten bei {institution} mit großem Interesse. Wir koordinieren derzeit ein hochkarätiges Konsortium für die bevorstehende Horizon Europe Ausschreibung. Aufgrund Ihrer herausragenden Expertise im Bereich {domain} möchten wir Sie herzlich einladen, mit uns als Schlüsselpartner oder Beiratsmitglied zusammenzuarbeiten.\n\nHätten Sie nächste Woche Zeit für ein kurzes 15-minütiges Gespräch?\n\nMit freundlichen Grüßen,\nFonBridge Ar-Ge Konsorsiyumu',
    },
    fr: {
      subject: 'Invitation au consortium Horizon Europe : Recherche & Innovation sur {domain}',
      body: 'Cher/Chère Dr. {name},\n\nJ\'ai le plaisir de vous contacter suite à vos remarquables contributions scientifiques à {institution}. Notre équipe prépare actuellement une proposition de premier plan dans le cadre d\'Horizon Europe. Votre expertise dans le domaine de {domain} apporterait une valeur scientifique inestimable à notre consortium.\n\nSeriez-vous disponible pour un échange exploratoire de 15 minutes la semaine prochaine ?\n\nBien cordialement,\nFonBridge Ar-Ge Konsorsiyumu',
    },
    es: {
      subject: 'Invitación a consorcio Horizon Europe: Liderazgo científico en {domain}',
      body: 'Estimado/a Dr. {name},\n\nLe escribo tras conocer su destacado trabajo en {institution}. Desde nuestro equipo estamos liderando un consorcio competitivo para la próxima convocatoria Horizon Europe. Su trayectoria y liderazgo en {domain} encajan a la perfección con la visión de impacto de la propuesta.\n\n¿Tendría disponibilidad para una breve llamada de 15 minutos la próxima semana?\n\nAtentamente,\nFonBridge Ar-Ge Konsorsiyumu',
    },
    it: {
      subject: 'Invito al consorzio Horizon Europe: Collaborazione scientifica {domain}',
      body: 'Gentile Dr. {name},\n\nseguo con grande apprezzamento i risultati di ricerca conseguiti dal Suo gruppo presso {institution}. Stiamo strutturando un consorzio strategico per il programma Horizon Europe. Considerata la Sua autorevole competenza nel settore {domain}, saremmo onorati di valutare una sinergia operativa.\n\nSarebbe disponibile per un breve colloquio di 15 minuti la prossima settimana?\n\nCordiali saluti,\nFonBridge Ar-Ge Konsorsiyumu',
    },
    pl: {
      subject: 'Zaproszenie do konsorcjum badawczego Horizon Europe: {domain}',
      body: 'Szanowny/a Dr {name},\n\nz wielkim uznaniem śledzę Państwa osiągnięcia naukowe w {institution}. Nasz zespół koordynuje przygotowanie projektu w programie Horizon Europe. Państwa unikalna wiedza i doświadczenie w dziedzinie {domain} stanowią kluczowy element dla osiągnięcia maksymalnego wpływu projektu.\n\nCzy moglibyśmy umówić się na krótką 15-minutową rozmowę w przyszłym tygodniu?\n\nZ poważaniem,\nFonBridge Ar-Ge Konsorsiyumu',
    },
    en: {
      subject: 'Horizon Europe Consortium Partnership: Strategic collaboration in {domain}',
      body: 'Dear Dr. {name},\n\nI am reaching out regarding your outstanding research leadership at {institution}. We are currently assembling a high-impact consortium for the upcoming Horizon Europe call. Given your premier expertise in {domain}, we would be delighted to explore your participation as a key partner or advisory member.\n\nWould you have 15 minutes next week for an introductory exchange?\n\nBest regards,\nFonBridge R&D Consortium',
    },
    tr: {
      subject: 'Horizon Europe Konsorsiyum Ortaklığı Daveti: {domain} Alanında Liderlik',
      body: 'Sayın Dr. {name},\n\n{institution} bünyesindeki değerli araştırma ve yayınlarınızı ilgiyle takip ediyoruz. FonBridge bünyesinde hazırlığını sürdürdüğümüz stratejik Horizon Europe projesi kapsamında, {domain} alanındaki yetkinliğinizi konsorsiyumumuza dahil etmekten büyük onur duyarız.\n\nÖnümüzdeki hafta 15 dakikalık çevrim içi tanışma toplantısı gerçekleştirebilir miyiz?\n\nSaygılarımızla,\nFonBridge Ar-Ge Konsorsiyumu',
    },
  },
};

export function OutreachClient({ locale, workspace }: OutreachClientProps) {
  const isTr = locale === 'tr';
  const [evaluators, setEvaluators] = useState<Evaluator[]>(SAMPLE_EVALUATORS);
  const [selectedEvaluator, setSelectedEvaluator] = useState<Evaluator>(SAMPLE_EVALUATORS[0]!);
  const [activeTemplate, setActiveTemplate] = useState('consortium_invitation');
  const [activeLang, setActiveLang] = useState<'de' | 'fr' | 'es' | 'it' | 'pl' | 'en' | 'tr'>(
    (SAMPLE_EVALUATORS[0]?.nativeLang as 'de') || 'de'
  );
  const [copied, setCopied] = useState(false);
  const [search, setSearch] = useState('');
  const [dailySent, setDailySent] = useState(14);
  const dailyQuota = 25;

  const filteredEvaluators = evaluators.filter((e) => {
    return (
      e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.institution.toLowerCase().includes(search.toLowerCase()) ||
      e.country.toLowerCase().includes(search.toLowerCase()) ||
      e.domain.toLowerCase().includes(search.toLowerCase())
    );
  });

  const currentTemplate = TEMPLATES[activeTemplate]?.[activeLang] || TEMPLATES[activeTemplate]?.en!;
  const generatedSubject = currentTemplate.subject
    .replace('{name}', selectedEvaluator.name)
    .replace('{institution}', selectedEvaluator.institution)
    .replace('{domain}', selectedEvaluator.domain);
  const generatedBody = currentTemplate.body
    .replace('{name}', selectedEvaluator.name)
    .replace('{institution}', selectedEvaluator.institution)
    .replace('{domain}', selectedEvaluator.domain);

  const handleSelectEvaluator = (ev: Evaluator) => {
    setSelectedEvaluator(ev);
    if (['de', 'fr', 'es', 'it', 'pl', 'tr', 'en'].includes(ev.nativeLang)) {
      setActiveLang(ev.nativeLang as 'de' | 'fr' | 'es' | 'it' | 'pl' | 'tr' | 'en');
    } else {
      setActiveLang('en');
    }
  };

  const copyToClipboard = () => {
    const fullText = `Konu: ${generatedSubject}\n\n${generatedBody}`;
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const markAsSent = () => {
    setEvaluators((prev) =>
      prev.map((e) => (e.id === selectedEvaluator.id ? { ...e, status: 'contacted' } : e))
    );
    setSelectedEvaluator((prev) => ({ ...prev, status: 'contacted' }));
    setDailySent((prev) => Math.min(prev + 1, dailyQuota));
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Page Header */}
      <div className="bg-surface border border-border rounded-3xl p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-3xl">
          <div className="flex items-center gap-2 text-xs font-semibold text-muted">
            <Link href={`/${locale}/${workspace}/dashboard`} className="hover:text-ink transition">
              {isTr ? 'Panel' : 'Dashboard'}
            </Link>
            <span>/</span>
            <span className="font-mono text-accent font-bold">M12</span>
            <span>/</span>
            <span className="text-ink font-semibold">{isTr ? 'Uzman Ulaşım Asistanı' : 'Expert Outreach'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-ink tracking-tight flex items-center gap-3">
            <span>✉️</span>
            <span>{isTr ? 'Uzman ve Hakem Ulaşım Asistanı' : 'Expert Outreach Assistant'}</span>
            <span className="text-xs px-2.5 py-1 rounded-full bg-accent/15 text-accent-ink border border-accent/20 font-mono font-bold">
              M12 ACTIVE
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-ink-2 leading-relaxed">
            {isTr
              ? '31.400+ Avrupa fonlama hakemine 24 AB resmi dilinde anadilde otomatik kişiselleştirilmiş ulaşım. %100 LinkedIn anti-bot güvenliği ve günlük kota takibi.'
              : 'Automated native outreach in 24 EU official languages to 31,400+ evaluators. 100% LinkedIn anti-bot safe workflows and daily quota enforcement.'}
          </p>
        </div>

        {/* Quota Gauge Tile */}
        <div className="bg-ground/90 border border-border p-4 sm:p-5 rounded-2xl min-w-[260px] space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted font-medium flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-ok" />
              <span>{isTr ? 'Anti-Bot Kota Takibi' : 'Anti-Bot Quota Guard'}</span>
            </span>
            <span className="font-mono font-bold text-ink">
              {dailySent} / {dailyQuota}
            </span>
          </div>
          <div className="w-full bg-border/80 h-2 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                dailySent >= dailyQuota ? 'bg-bad' : dailySent >= 20 ? 'bg-amber' : 'bg-ok'
              }`}
              style={{ width: `${(dailySent / dailyQuota) * 100}%` }}
            />
          </div>
          <div className="text-[11px] text-muted flex items-center justify-between">
            <span>{isTr ? 'Kalan Güvenli Limit:' : 'Remaining Limit:'}</span>
            <span className="font-bold text-ok">{dailyQuota - dailySent} {isTr ? 'Ulaşım' : 'Outreach'}</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Directory on Left (5 cols), Outreach Studio on Right (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Evaluator Directory */}
        <div className="lg:col-span-5 bg-surface border border-border rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-border">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-accent" />
              <h2 className="text-sm font-bold text-ink font-heading">
                {isTr ? 'Hakem & Uzman Havuzu' : 'Evaluator Pool'}
              </h2>
            </div>
            <span className="text-xs font-mono font-bold text-muted bg-ground px-2 py-0.5 rounded border border-border">
              {filteredEvaluators.length} {isTr ? 'Kayıt' : 'Profiles'}
            </span>
          </div>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-muted pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={isTr ? 'Uzman adı, kurum, ülke veya çalışma alanı ara...' : 'Search by name, institute, country...'}
              className="w-full pl-9 pr-4 py-2 bg-ground text-xs text-ink rounded-xl border border-border focus:outline-hidden focus:border-accent"
            />
          </div>

          {/* Evaluator Cards List */}
          <div className="space-y-2.5 max-h-[640px] overflow-y-auto pr-1">
            {filteredEvaluators.map((ev) => {
              const isSelected = selectedEvaluator.id === ev.id;
              return (
                <div
                  key={ev.id}
                  onClick={() => handleSelectEvaluator(ev)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer text-left ${
                    isSelected
                      ? 'bg-accent/10 border-accent shadow-xs'
                      : 'bg-ground/60 border-border hover:border-accent/40 hover:bg-surface'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-ink">{ev.name}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-surface border border-border font-mono font-semibold">
                          {ev.countryCode}
                        </span>
                      </div>
                      <div className="text-[11px] text-muted line-clamp-1">{ev.institution}</div>
                    </div>
                    <span className="text-[11px] font-mono font-bold text-ok bg-ok/10 px-1.5 py-0.5 rounded border border-ok/20">
                      %{ev.relevanceScore}
                    </span>
                  </div>

                  <div className="mt-2.5 pt-2 border-t border-border/60 flex items-center justify-between text-[11px] text-muted">
                    <span className="flex items-center gap-1 text-ink-2 truncate max-w-[200px]">
                      <Globe2 className="w-3 h-3 text-muted" />
                      <span>{ev.nativeLangName}</span>
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        ev.status === 'meeting_scheduled'
                          ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300'
                          : ev.status === 'contacted'
                          ? 'bg-ok/15 text-ok'
                          : 'bg-ground text-muted border border-border'
                      }`}
                    >
                      {ev.status === 'meeting_scheduled'
                        ? 'Toplantı'
                        : ev.status === 'contacted'
                        ? 'Ulaşıldı'
                        : 'Yeni'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Dynamic Outreach Studio */}
        <div className="lg:col-span-7 bg-surface border border-border rounded-3xl p-6 shadow-xs space-y-6">
          {/* Header of Active Contact */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-ink font-heading">{selectedEvaluator.name}</h3>
                <span className="text-xs text-muted font-mono">({selectedEvaluator.country})</span>
              </div>
              <div className="text-xs text-muted">{selectedEvaluator.title}</div>
            </div>

            <div className="flex items-center gap-2">
              <a
                href={selectedEvaluator.linkedInUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition shadow-xs"
              >
                <span>LinkedIn'de Bul</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Language Selector Tabs */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-muted font-medium">
              <span className="flex items-center gap-1.5">
                <Globe2 className="w-4 h-4 text-accent" />
                <span>Otomatik Tespit Edilen Anadil & Çeviri Motoru:</span>
              </span>
              <span className="text-[11px] font-mono text-ok font-bold">
                ✓ Doğruluk Oranı: %99.4
              </span>
            </div>

            <div className="flex flex-wrap gap-2">
              {[
                { code: 'de', label: '🇩🇪 Deutsch (Almanca)' },
                { code: 'fr', label: '🇫🇷 Français (Fransızca)' },
                { code: 'es', label: '🇪🇸 Español (İspanyolca)' },
                { code: 'it', label: '🇮🇹 Italiano (İtalyanca)' },
                { code: 'pl', label: '🇵🇱 Polski (Lehçe)' },
                { code: 'en', label: '🇬🇧 English (İngilizce)' },
                { code: 'tr', label: '🇹🇷 Türkçe' },
              ].map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => setActiveLang(lang.code as 'de')}
                  className={`text-xs px-3 py-1.5 rounded-xl font-semibold border transition-all ${
                    activeLang === lang.code
                      ? 'bg-accent text-white border-accent shadow-xs'
                      : 'bg-ground text-ink-2 border-border hover:border-accent/40'
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>

          {/* Message Preview Canvas */}
          <div className="space-y-3 bg-ground/80 border border-border rounded-2xl p-4 sm:p-5">
            <div className="space-y-1">
              <div className="text-[11px] text-muted font-bold uppercase tracking-wider">E-posta / Mesaj Konusu</div>
              <div className="text-xs font-semibold text-ink bg-surface p-2.5 rounded-xl border border-border">
                {generatedSubject}
              </div>
            </div>

            <div className="space-y-1">
              <div className="text-[11px] text-muted font-bold uppercase tracking-wider">Kişiselleştirilmiş Mesaj Gövdesi</div>
              <div className="text-xs text-ink bg-surface p-3.5 rounded-xl border border-border font-sans leading-relaxed whitespace-pre-wrap min-h-[220px]">
                {generatedBody}
              </div>
            </div>
          </div>

          {/* Action Footer */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <div className="text-xs text-muted flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-ok" />
              <span>Anti-bot güvenliği için metin panoya kopyalanır ve LinkedIn'e güvenle yapıştırılır.</span>
            </div>

            <div className="flex items-center gap-2.5">
              <button
                onClick={copyToClipboard}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-surface border border-border hover:border-accent text-xs font-bold text-ink shadow-xs transition"
              >
                {copied ? <Check className="w-4 h-4 text-ok" /> : <Copy className="w-4 h-4 text-accent" />}
                <span>{copied ? 'Panoya Kopyalandı!' : 'Metni Kopyala'}</span>
              </button>

              <button
                onClick={markAsSent}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-accent hover:bg-accent-hover text-white text-xs font-bold shadow-md shadow-accent/20 transition"
              >
                <Send className="w-4 h-4" />
                <span>{isTr ? 'Ulaşıldı Olarak İşaretle' : 'Mark as Contacted'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
