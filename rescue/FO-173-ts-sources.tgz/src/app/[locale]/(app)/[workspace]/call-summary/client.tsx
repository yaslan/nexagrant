'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { 
  FileText, 
  Sparkles, 
  Upload, 
  Link2, 
  Check, 
  Copy, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  Clock, 
  Target, 
  Coins, 
  ShieldCheck, 
  ChevronDown, 
  ChevronUp,
  FileCode,
  ArrowRight,
  RefreshCw,
  FolderOpen,
  Laptop,
  BookmarkCheck,
  Send,
  BookOpen,
  X,
  FileUp,
  ExternalLink
} from 'lucide-react';
import { 
  analyzeCallSourceAction, 
  saveCallSummaryAsBlogDraftAction, 
  type SummarySection 
} from './actions';

interface CallSummaryClientProps {
  locale: string;
  workspace: string;
  initialTopicId?: string;
  initialTitle?: string;
  initialProgramme?: string;
  autoGenerate?: boolean;
}

const DEFAULT_SECTIONS: SummarySection[] = [
  {
    number: 1,
    title: 'Çağrı Kimliği, Kapsam ve Temel Hedefler',
    badge: 'Kapsam & Vizyon',
    content:
      'HORIZON-CL5-2026-D4-02: Akıllı Şehirler İçin Temiz Enerji Geçişi ve Şebeke Esnekliği. Çağrı, kentsel enerji talebini yerel yenilenebilir üretim (güneş, jeotermal, biyokütle) ve merkeziyetsiz batarya depolama sistemleriyle optimize eden dijital ikiz çözümlerini hedeflemektedir.',
  },
  {
    number: 2,
    title: 'Konsorsiyum ve Ortaklık Gereksinimleri',
    badge: 'Ortaklık Şartı',
    content:
      'En az 3 farklı AB Üye Ülkesi veya Asosye Ülkeden bağımsız tüzel kişilik. Zorunlu profil: En az 2 pilot belediye (Lighthouse / Follower City), 1 şebeke dağıtım şirketi (DSO) ve 1 akademik modelleme lideri.',
  },
  {
    number: 3,
    title: 'Uygunluk ve Katılım Kriterleri',
    badge: 'Uygunluk Matrisi',
    content:
      'Research and Innovation Actions (RIA) türü başvuru. Tüzel kişiliği olan üniversiteler, araştırma merkezleri, KOBİ\'ler ve kamu kurumları %100 doğrudan maliyet karşılama oranıyla hibe almaya uygundur.',
  },
  {
    number: 4,
    title: 'Bütçe, Finansman Oranları ve Mali Kurallar',
    badge: '€18.000.000 Toplam',
    content:
      'Proje başına önerilen bütçe: 4.000.000 € – 6.000.000 €. Tahmini desteklenecek proje sayısı: 3 adet. Genel gider oranı: %25 sabit dolaylı maliyet katkısı. Personel-ay birim maliyetleri Horizon kurallarına tabidir.',
  },
  {
    number: 5,
    title: 'Beklenen Çıktılar ve Etki (KPI\'lar)',
    badge: 'Etki & KPI',
    content:
      'Pilot bölgelerde pik elektrik talebinde en az %28 azalma; CO2 eşdeğeri sera gazı emisyonlarında yıllık 4.500 ton net tasarruf; açık kaynaklı belediye enerji yönetim yazılımının 5 takipçi şehre replikasyonu.',
  },
  {
    number: 6,
    title: 'Mükemmeliyet (Excellence) Kriterleri',
    badge: 'Hakem Ağırlığı: %50',
    content:
      'Teknolojinin mevcut durumunun (State-of-the-Art) ötesine geçen yapay zeka tabanlı yük tahmin algoritmaları; çok paydaşlı birlikte tasarım (co-design) metodolojisi; cinsiyet boyutu ve disiplinler arası sosyal inovasyon entegrasyonu.',
  },
  {
    number: 7,
    title: 'Uygulama, İş Paketleri ve Zaman Çizelgesi',
    badge: '36-48 Ay',
    content:
      'Önerilen 6 İş Paketi mimarisi: WP1 Yönetim ve Koordinasyon; WP2 Gereksinim Analizi & Veri Mimarisi; WP3 Dijital İkiz & Algoritma Geliştirme; WP4 Pilot Gösterim ve Canlı Doğrulama; WP5 Replikasyon ve Sürdürülebilirlik; WP6 İletişim, Yaygınlaştırma ve Sömürü.',
  },
  {
    number: 8,
    title: 'AB Politika Hedefleriyle Uyum',
    badge: 'Green Deal & Net-Zero',
    content:
      'European Green Deal 2050 karbon nötr hedefleri, EU Cities Mission (100 İklim Nötr Şehir) ve REPowerEU enerji bağımsızlığı stratejisiyle doğrudan birebir uyum zorunludur.',
  },
  {
    number: 9,
    title: 'Hedeflenen TRL Seviyesi',
    badge: 'TRL 5 → TRL 7',
    content:
      'Başlangıç TRL: 4 veya 5 (Laboratuvarda veya simülasyonda doğrulanmış prototipler). Proje bitişi: TRL 7 (Operasyonel ortamda çalışan ve 2 farklı iklim bölgesinde test edilmiş entegre sistem gösterimi).',
  },
  {
    number: 10,
    title: 'Fikri Mülkiyet (IP) ve Açık Bilim Gereksinimleri',
    badge: 'Open Access & FAIR',
    content:
      'Tüm hakemli bilimsel yayınlar derhal açık erişim (Open Access) lisansıyla yayımlanmalıdır. Üretilen araştırma verileri FAIR (Bulunabilir, Erişilebilir, Birlikte Çalışabilir, Yeniden Kullanılabilir) ilkelerine uygun olmalı ve DMP (Veri Yönetim Planı) sunulmalıdır.',
  },
  {
    number: 11,
    title: 'Kritik Riskler ve Güvenlik Tedbirleri',
    badge: 'Siber Güvenlik & GDPR',
    content:
      'Akıllı sayaç ve belediye tüketim verilerinin işlenmesinde GDPR tam uyumu; kritik şebeke altyapılarına yönelik siber saldırı riskini önlemek için IEC 62443 endüstriyel güvenlik sertifikasyonu.',
  },
  {
    number: 12,
    title: 'FonBridge Stratejik Başvuru Tavsiyeleri',
    badge: 'Kazanma Taktikleri',
    content:
      '1. Konsorsiyuma Güney veya Doğu Avrupa\'dan en az 1 Genişleme Ülkesi (Widening Country) belediyesi dahil edin; bu durum hakem değerlendirmesinde coğrafi denge avantajı sağlar.\n2. M3 modülümüzden DoH (Do No Significant Harm) kanıt paketlerini doğrudan ekleyin.\n3. M6 Hakem Simülatöründe başvuru taslağını G2 aşamasında ESR denetiminden geçirin.',
  },
];

const PRESET_CALLS = [
  {
    id: 'HORIZON-CL4-2027-SPACE-07-84',
    title: 'Yeni Nesil Uzay ve Uydu Teknolojileri, Yörünge İçi Servisler ve Takımyıldızı Dayanıklılığı',
    programme: 'Horizon Europe (Cluster 4: Space)',
    url: 'https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/opportunities/topic-details/HORIZON-CL4-2027-SPACE-07-84',
  },
  {
    id: 'HORIZON-CL5-2026-D4-02',
    title: 'Akıllı Şehirler İçin Temiz Enerji Geçişi ve Şebeke Esnekliği',
    programme: 'Horizon Europe (Cluster 5: Energy)',
    url: 'https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/opportunities/topic-details/horizon-cl5-2026-d4-02',
  },
  {
    id: 'HORIZON-CL1-2026-DISEASE-01',
    title: 'Yenilikçi Dijital Sağlık Araçları ve Biyomedikal Veri Analitiği',
    programme: 'Horizon Europe (Cluster 1: Health)',
    url: 'https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/opportunities/topic-details/horizon-cl1-2026-disease-01',
  },
  {
    id: 'TUBITAK-1501-ARGE',
    title: 'TÜBİTAK 1501 - Sanayi Ar-Ge Projeleri Destekleme Programı',
    programme: 'TÜBİTAK TEYDEB',
    url: 'https://tubitak.gov.tr/tr/destekler/sanayi/ulusal-destek-programlari/1501',
  },
];

export function CallSummaryClient({
  locale,
  workspace,
  initialTopicId,
  initialTitle,
  initialProgramme,
  autoGenerate,
}: CallSummaryClientProps) {
  const isTr = locale === 'tr';

  // Input Modes: 'url' | 'file' | 'project'
  const [inputMode, setInputMode] = useState<'url' | 'file' | 'project'>('url');
  
  // URL Input
  const [inputUrl, setInputUrl] = useState(
    initialTopicId 
      ? `https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/opportunities/topic-details/${initialTopicId}`
      : 'https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/opportunities/topic-details/HORIZON-CL4-2027-SPACE-07-84?isExactMatch=true&status=31094501,31094502,31094503&frameworkProgramme=43108390&order=DESC&pageNumber=1&pageSize=50&sortBy=startDate'
  );

  // File Upload State
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    size: string;
    type: string;
    textSnippet?: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Output and Status
  const [currentCallTitle, setCurrentCallTitle] = useState(initialTitle || 'Akıllı Şehirler İçin Temiz Enerji Geçişi ve Şebeke Esnekliği');
  const [currentTopicId, setCurrentTopicId] = useState(initialTopicId || 'HORIZON-CL5-2026-D4-02');
  const [currentProgramme, setCurrentProgramme] = useState(initialProgramme || 'Horizon Europe');
  const [currentSourceLabel, setCurrentSourceLabel] = useState('Varsayılan Analiz');
  const [sections, setSections] = useState<SummarySection[]>(DEFAULT_SECTIONS);
  const [expandedSection, setExpandedSection] = useState<number | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  // Blog Draft State
  const [isSavingDraft, setIsSavingDraft] = useState(false);
  const [draftSavedResult, setDraftSavedResult] = useState<{ slug: string } | null>(null);
  const [draftError, setDraftError] = useState<string | null>(null);

  // Handle URL or initial load auto-generation
  useEffect(() => {
    if (initialTopicId || autoGenerate) {
      handleAnalyze({ topicId: initialTopicId, title: initialTitle, url: inputUrl });
    }
  }, [initialTopicId, autoGenerate]);

  const toggleSection = (num: number) => {
    setExpandedSection((prev) => (prev === num ? null : num));
  };

  const expandAll = () => {
    setExpandedSection(sections.length > 0 ? -1 : null); // -1 will indicate all expanded
  };

  const collapseAll = () => {
    setExpandedSection(null);
  };

  // Main Generator Function
  const handleAnalyze = async (override?: { url?: string; topicId?: string; title?: string; fileName?: string; fileText?: string }) => {
    setIsGenerating(true);
    setDraftSavedResult(null);
    setDraftError(null);

    const payload = {
      url: override?.url !== undefined ? override.url : (inputMode === 'url' ? inputUrl : ''),
      topicId: override?.topicId || (inputMode === 'project' ? currentTopicId : undefined),
      fileName: override?.fileName || (inputMode === 'file' ? uploadedFile?.name : undefined),
      fileText: override?.fileText || (inputMode === 'file' ? uploadedFile?.textSnippet : undefined),
    };

    try {
      const res = await analyzeCallSourceAction(payload);
      if (res.ok) {
        setSections(res.sections);
        setCurrentCallTitle(res.title);
        if (res.topicId) setCurrentTopicId(res.topicId);
        if (res.programme) setCurrentProgramme(res.programme);

        if (payload.fileName) {
          setCurrentSourceLabel(`Dosya: ${payload.fileName}`);
        } else if (payload.url) {
          setCurrentSourceLabel(`URL: ${res.topicId || payload.url.slice(0, 45) + '...'}`);
        } else {
          setCurrentSourceLabel(`Proje: ${res.topicId || 'Kayıtlı Çağrı'}`);
        }
      }
    } catch (e) {
      console.error('Call analysis failed:', e);
    } finally {
      setIsGenerating(false);
    }
  };

  // File Handling (Upload from computer)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    processSelectedFile(file);
  };

  const processSelectedFile = (file: File) => {
    const sizeFormatted = file.size > 1024 * 1024
      ? `${(file.size / (1024 * 1024)).toFixed(1)} MB`
      : `${Math.round(file.size / 1024)} KB`;

    const fileType = file.name.split('.').pop()?.toUpperCase() || 'FILE';

    // If text or markdown, read sample snippet
    if (file.type.includes('text') || file.name.endsWith('.txt') || file.name.endsWith('.md')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        setUploadedFile({
          name: file.name,
          size: sizeFormatted,
          type: fileType,
          textSnippet: text.slice(0, 3000),
        });
      };
      reader.readAsText(file);
    } else {
      // PDF or DOCX
      setUploadedFile({
        name: file.name,
        size: sizeFormatted,
        type: fileType,
        textSnippet: `Dosya Adı: ${file.name}\nBoyut: ${sizeFormatted}\nTür: ${fileType}`,
      });
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  // Copy full markdown
  const copyFullMarkdown = () => {
    const md = [
      `# ${currentCallTitle}`,
      `**Çağrı Kodu:** ${currentTopicId} | **Program:** ${currentProgramme}`,
      `---\n`,
      ...sections.map((s) => `### ${s.number}. ${s.title} [${s.badge}]\n\n${s.content}\n`),
    ].join('\n---\n\n');

    navigator.clipboard.writeText(md);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // Save as Blog Draft (Directly to Blog Section)
  const handleSaveToBlogDraft = async () => {
    setIsSavingDraft(true);
    setDraftError(null);
    setDraftSavedResult(null);

    try {
      const res = await saveCallSummaryAsBlogDraftAction({
        title: currentCallTitle,
        topicId: currentTopicId,
        sections,
        category: 'Çağrı Özeti (Taslak)',
      });

      if (res.ok && res.slug) {
        setDraftSavedResult({ slug: res.slug });
      } else {
        setDraftError(res.error || 'Taslak kaydedilirken bir hata oluştu');
      }
    } catch (err: any) {
      setDraftError(err?.message || 'Bağlantı hatası');
    } finally {
      setIsSavingDraft(false);
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Page Header */}
      <div className="bg-surface border border-border rounded-3xl p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-3xl">
          <div className="flex items-center gap-2 text-xs font-semibold text-muted">
            <Link href={`/${locale}/${workspace}/dashboard`} className="hover:text-ink transition">
              {isTr ? 'Panel' : 'Dashboard'}
            </Link>
            <span>/</span>
            <span className="font-mono text-accent font-bold">M13</span>
            <span>/</span>
            <span className="text-ink font-semibold">{isTr ? 'Çağrı Özeti Motoru' : 'Call Summary Engine'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-ink tracking-tight flex items-center gap-3">
            <span>📑</span>
            <span>{isTr ? 'Proje Çağrısı Özeti ve Analiz Motoru' : 'Call Summary & Requirement Engine'}</span>
            <span className="text-xs px-2.5 py-1 rounded-full bg-accent/15 text-accent-ink border border-accent/20 font-mono font-bold">
              M13 ACTIVE
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-ink-2 leading-relaxed">
            {isTr
              ? 'Web bağlantısı, PDF, DOCX ve metin kaynaklarından 12 bölümlü stratejik Türkçe çağrı özeti, uygunluk matrisi ve başvuru gereksinim analizi üreten yapay zeka motoru. Çıktılar tek tıkla blog taslağı olarak kaydedilebilir.'
              : '12-section AI-powered strategic call brief, eligibility matrix, and proposal requirement analyzer from Web, PDF, DOCX, and text sources. Summaries can be saved directly as blog drafts.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Save to Blog Draft Button */}
          <button
            onClick={handleSaveToBlogDraft}
            disabled={isSavingDraft || isGenerating}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-accent/10 hover:bg-accent/20 border border-accent/30 text-xs font-bold text-accent-ink shadow-xs transition disabled:opacity-50"
            title={isTr ? 'Bu 12 bölümlü özeti Blog bölümüne taslak olarak kaydet' : 'Save as draft blog post'}
          >
            {isSavingDraft ? (
              <RefreshCw className="w-4 h-4 animate-spin text-accent" />
            ) : (
              <BookOpen className="w-4 h-4 text-accent" />
            )}
            <span>{isSavingDraft ? 'Taslak Kaydediliyor...' : 'Blog Taslağı Olarak Kaydet'}</span>
          </button>

          {/* Copy Full Markdown */}
          <button
            onClick={copyFullMarkdown}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-surface border border-border hover:border-accent text-xs font-bold text-ink shadow-xs transition"
          >
            {copied ? <Check className="w-4 h-4 text-ok" /> : <Copy className="w-4 h-4 text-accent" />}
            <span>{copied ? 'Kopyalandı!' : 'Tam Özeti Kopyala'}</span>
          </button>
        </div>
      </div>

      {/* Draft Saved Success Notification Banner */}
      {draftSavedResult && (
        <div className="p-4 rounded-2xl border border-ok/30 bg-ok/10 text-ink shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-fadeIn">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-ok/20 text-ok flex items-center justify-center shrink-0">
              <BookmarkCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-ok">
                Özet Blog Bölümüne Taslak Olarak Başarıyla Eklendi!
              </h4>
              <p className="text-xs text-ink-2 mt-0.5">
                Bu 12 bölümlü çağrı analizi, Blog Yönetiminde incelemeniz ve yayınlamanız için taslak durumunda bekliyor.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Link
              href={`/${locale}/admin/blog`}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-surface border border-border hover:border-accent text-xs font-bold text-ink transition"
            >
              <span>Blog Yönetimine Git</span>
              <ArrowRight className="w-3.5 h-3.5 text-accent" />
            </Link>
            <Link
              href={`/${locale}/blog/${draftSavedResult.slug}`}
              target="_blank"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-accent text-white text-xs font-bold transition hover:opacity-90"
            >
              <span>Önizle</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      )}

      {draftError && (
        <div className="p-4 rounded-2xl border border-bad/30 bg-bad/10 text-bad text-xs font-semibold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>Taslak kaydedilemedi: {draftError}</span>
        </div>
      )}

      {/* Input Hub: 3 Tabs (URL, File Upload, Project Selection) */}
      <div className="bg-surface border border-border rounded-3xl p-6 shadow-xs space-y-6">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-2 border-b border-border pb-4">
          <button
            onClick={() => setInputMode('url')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
              inputMode === 'url'
                ? 'bg-accent text-white shadow-xs'
                : 'bg-ground text-ink-2 hover:bg-surface-hover border border-border'
            }`}
          >
            <Link2 className="w-4 h-4" />
            <span>Web Bağlantısı (URL)</span>
          </button>

          <button
            onClick={() => setInputMode('file')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
              inputMode === 'file'
                ? 'bg-accent text-white shadow-xs'
                : 'bg-ground text-ink-2 hover:bg-surface-hover border border-border'
            }`}
          >
            <Laptop className="w-4 h-4" />
            <span>Bilgisayardan Dosya Yükle (PDF, DOCX, TXT)</span>
          </button>

          <button
            onClick={() => setInputMode('project')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
              inputMode === 'project'
                ? 'bg-accent text-white shadow-xs'
                : 'bg-ground text-ink-2 hover:bg-surface-hover border border-border'
            }`}
          >
            <FolderOpen className="w-4 h-4" />
            <span>Proje Çağrılarından Seç</span>
          </button>
        </div>

        {/* Tab 1: Web URL Mode */}
        {inputMode === 'url' && (
          <div className="space-y-4">
            <div className="text-xs font-bold uppercase tracking-wider text-muted flex items-center gap-2">
              <Link2 className="w-4 h-4 text-accent" />
              <span>{isTr ? 'Kaynak Doküman veya Çağrı Portalı Bağlantısı' : 'Source Document or Funding Portal Link'}</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-grow">
                <input
                  type="text"
                  value={inputUrl}
                  onChange={(e) => setInputUrl(e.target.value)}
                  placeholder="https://ec.europa.eu/... veya çağrı linki yapıştırın"
                  className="w-full px-4 py-3 bg-ground text-xs font-mono text-ink rounded-xl border border-border focus:outline-hidden focus:border-accent"
                />
              </div>

              <button
                onClick={() => handleAnalyze()}
                disabled={isGenerating || !inputUrl.trim()}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-accent hover:bg-accent-hover text-white text-xs font-bold shadow-md shadow-accent/20 transition disabled:opacity-50 whitespace-nowrap cursor-pointer"
              >
                {isGenerating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                <span>{isGenerating ? 'Analiz Ediliyor...' : '12 Bölümlü Özet Üret'}</span>
              </button>
            </div>

            {/* Quick Presets */}
            <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-muted">
              <span className="font-semibold text-[11px]">Hızlı Örnekler:</span>
              <button
                type="button"
                onClick={() => {
                  const url = 'https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/opportunities/topic-details/HORIZON-CL4-2027-SPACE-07-84?isExactMatch=true&status=31094501,31094502,31094503&frameworkProgramme=43108390&order=DESC&pageNumber=1&pageSize=50&sortBy=startDate';
                  setInputUrl(url);
                  handleAnalyze({ url });
                }}
                className="px-2.5 py-1 rounded-lg bg-ground hover:bg-surface-hover border border-border text-[11px] font-mono text-ink transition"
              >
                🚀 HORIZON-CL4-2027-SPACE-07-84 (Uzay Çağrısı)
              </button>
              <button
                type="button"
                onClick={() => {
                  const url = 'https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/opportunities/topic-details/horizon-cl5-2026-d4-02';
                  setInputUrl(url);
                  handleAnalyze({ url });
                }}
                className="px-2.5 py-1 rounded-lg bg-ground hover:bg-surface-hover border border-border text-[11px] font-mono text-ink transition"
              >
                🌱 HORIZON-CL5-2026-D4-02 (Temiz Enerji)
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: File Upload from Computer Mode */}
        {inputMode === 'file' && (
          <div className="space-y-4">
            <div className="text-xs font-bold uppercase tracking-wider text-muted flex items-center gap-2">
              <Laptop className="w-4 h-4 text-accent" />
              <span>{isTr ? 'Bilgisayardan Doküman Yükleme' : 'Upload Document From Computer'}</span>
            </div>

            {/* Drop Zone */}
            <div
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-border hover:border-accent/60 rounded-2xl p-8 text-center cursor-pointer transition bg-ground/50 hover:bg-ground flex flex-col items-center justify-center space-y-3"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.docx,.doc,.txt,.md"
                onChange={handleFileChange}
                className="hidden"
              />
              <div className="w-12 h-12 rounded-2xl bg-accent/15 text-accent-ink flex items-center justify-center shadow-xs">
                <FileUp className="w-6 h-6" />
              </div>

              <div>
                <p className="text-sm font-bold text-ink font-heading">
                  {uploadedFile ? 'Dosyayı Değiştirmek İçin Tıklayın veya Sürükleyin' : 'Çağrı Dokümanını Buraya Sürükleyin veya Dosya Seçin'}
                </p>
                <p className="text-xs text-muted mt-1">
                  Bilgisayarınızdan PDF, Word (DOCX), Metin (TXT) veya Markdown dosyalarını doğrudan yükleyebilirsiniz.
                </p>
              </div>

              <div className="flex items-center gap-2 text-[11px] font-mono text-muted">
                <span className="px-2 py-0.5 rounded bg-surface border border-border font-semibold">PDF (25 MB)</span>
                <span className="px-2 py-0.5 rounded bg-surface border border-border font-semibold">DOCX</span>
                <span className="px-2 py-0.5 rounded bg-surface border border-border font-semibold">TXT / MD</span>
              </div>
            </div>

            {/* Selected File Card */}
            {uploadedFile && (
              <div className="p-4 rounded-xl border border-accent/30 bg-accent/5 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-accent text-white flex items-center justify-center font-bold text-xs uppercase">
                    {uploadedFile.type}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-ink flex items-center gap-2">
                      <span>{uploadedFile.name}</span>
                      <span className="text-[11px] font-mono text-muted font-normal">({uploadedFile.size})</span>
                    </div>
                    <div className="text-[11px] text-ok font-semibold flex items-center gap-1 mt-0.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Doküman yüklendi ve analize hazır</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleAnalyze()}
                    disabled={isGenerating}
                    className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-accent hover:bg-accent-hover text-white text-xs font-bold shadow-md shadow-accent/20 transition disabled:opacity-50"
                  >
                    {isGenerating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    <span>{isGenerating ? 'Analiz Ediliyor...' : 'Yüklenen Dokümandan 12 Bölümlü Özet Üret'}</span>
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setUploadedFile(null);
                    }}
                    className="p-2 rounded-lg text-muted hover:text-bad border border-border hover:bg-surface transition"
                    title="Dosyayı kaldır"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Select from Project Calls Mode */}
        {inputMode === 'project' && (
          <div className="space-y-4">
            <div className="text-xs font-bold uppercase tracking-wider text-muted flex items-center gap-2">
              <FolderOpen className="w-4 h-4 text-accent" />
              <span>{isTr ? 'Kayıtlı Proje Çağrıları Listesinden Seçin' : 'Select from Project Calls'}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {PRESET_CALLS.map((call) => {
                const isSelected = currentTopicId === call.id;
                return (
                  <div
                    key={call.id}
                    onClick={() => {
                      setCurrentTopicId(call.id);
                      setCurrentCallTitle(call.title);
                      setInputUrl(call.url);
                      handleAnalyze({ topicId: call.id, title: call.title, url: call.url });
                    }}
                    className={`p-4 rounded-xl border text-left cursor-pointer transition flex flex-col justify-between gap-3 ${
                      isSelected
                        ? 'border-accent bg-accent/10 shadow-xs'
                        : 'border-border bg-ground hover:bg-surface-hover'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="font-mono font-bold text-xs text-accent">{call.id}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-surface border border-border text-muted">
                          {call.programme}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-ink line-clamp-2">{call.title}</h4>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-border/60 text-[11px]">
                      <span className="text-accent font-semibold flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Seç ve 12 Bölümlü Özet Üret</span>
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-muted" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Feature Badges Footer */}
        <div className="flex flex-wrap items-center gap-3 pt-2 text-[11px] text-muted border-t border-border/60">
          <span>Desteklenen Girdi Formatları:</span>
          <span className="px-2 py-0.5 rounded bg-ground border border-border font-mono font-semibold">Web URL</span>
          <span className="px-2 py-0.5 rounded bg-ground border border-border font-mono font-semibold">PDF (25 MB)</span>
          <span className="px-2 py-0.5 rounded bg-ground border border-border font-mono font-semibold">DOCX</span>
          <span className="px-2 py-0.5 rounded bg-ground border border-border font-mono font-semibold">TXT / Markdown</span>
          <span className="text-ok font-semibold ml-auto flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>SSRF Korumalı Güvenli İndirici & YZ Doğrulama</span>
          </span>
        </div>
      </div>

      {/* Active Call Summary Header Card */}
      <div className="bg-surface border border-border rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-xs font-bold text-accent bg-accent/15 px-2.5 py-0.5 rounded-full border border-accent/20">
              {currentTopicId}
            </span>
            <span className="text-xs text-muted font-medium bg-ground px-2.5 py-0.5 rounded-full border border-border">
              {currentProgramme}
            </span>
            <span className="text-xs text-ink-2 font-medium bg-ground px-2.5 py-0.5 rounded-full border border-border">
              Kaynak: {currentSourceLabel}
            </span>
          </div>
          <h2 className="text-base sm:text-lg font-bold text-ink font-heading leading-tight pt-1">
            {currentCallTitle}
          </h2>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={expandAll}
            className="px-3 py-1.5 rounded-lg bg-ground hover:bg-surface-hover border border-border text-xs font-semibold text-ink transition"
          >
            Tümünü Aç
          </button>
          <button
            onClick={collapseAll}
            className="px-3 py-1.5 rounded-lg bg-ground hover:bg-surface-hover border border-border text-xs font-semibold text-ink transition"
          >
            Tümünü Daralt
          </button>
        </div>
      </div>

      {/* Structured 12-Section Output Showcase */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-ink font-heading flex items-center gap-2">
            <Layers className="w-4 h-4 text-accent" />
            <span>{isTr ? '12 Bölümlü Stratejik Çağrı Raporu' : '12-Section Strategic Call Analysis'}</span>
          </h2>
          <span className="text-xs font-mono font-bold text-ok bg-ok/10 px-2.5 py-1 rounded-full border border-ok/20 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>12 / 12 Bölüm Tamamlandı</span>
          </span>
        </div>

        <div className="grid grid-cols-1 gap-3.5">
          {sections.map((section) => {
            const isExpanded = expandedSection === -1 || expandedSection === section.number;
            return (
              <div
                key={section.number}
                className="bg-surface border border-border rounded-2xl p-4 sm:p-5 shadow-xs transition-all hover:border-accent/30"
              >
                <div
                  onClick={() => toggleSection(section.number)}
                  className="flex items-start justify-between gap-4 cursor-pointer select-none"
                >
                  <div className="flex items-start gap-3">
                    <span className="w-7 h-7 rounded-xl bg-accent/15 text-accent-ink font-mono font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      {section.number}
                    </span>
                    <div>
                      <h3 className="text-sm font-bold text-ink font-heading">{section.title}</h3>
                      <span className="text-[11px] font-semibold text-accent font-mono mt-0.5 inline-block">
                        {section.badge}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs text-muted">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </span>
                  </div>
                </div>

                {isExpanded && (
                  <div className="mt-3 pt-3 border-t border-border/60 text-xs sm:text-sm text-ink-2 leading-relaxed whitespace-pre-line font-sans animate-fadeIn">
                    {section.content}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
