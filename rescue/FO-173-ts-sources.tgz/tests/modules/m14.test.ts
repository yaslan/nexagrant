import { describe, it, expect } from 'vitest';
import { m14Manifest } from '../../src/modules/m14/manifest';
import { getManifest, getRouteOwner } from '../../src/lib/modules/registry';
import { getWorkspaceRoute } from '../../src/lib/routes';
import {
  TRAINING_STAGES,
  TRAINING_LESSONS,
  ACADEMY_TEMPLATES,
} from '../../src/modules/m14/content';

describe('M14 Training & Academy Module', () => {
  it('manifest is registered and valid', () => {
    expect(m14Manifest.id).toBe('M14');
    expect(m14Manifest.key).toBe('training');
    expect(m14Manifest.isActive).toBe(true);

    const fromRegistry = getManifest('M14');
    expect(fromRegistry).toBe(m14Manifest);

    const owner = getRouteOwner('training');
    expect(owner).not.toBeNull();
    expect(owner?.moduleId).toBe('M14');
    expect(owner?.permission).toBe('training:read');
  });

  it('correctly resolves localized workspace routes', () => {
    expect(getWorkspaceRoute('training', 'tr', 'test-ws')).toBe('/tr/test-ws/egitim');
    expect(getWorkspaceRoute('training', 'en', 'test-ws')).toBe('/en/test-ws/training');
  });

  it('declares valid stages and complete curriculum', () => {
    expect(TRAINING_STAGES.length).toBe(2);
    const stageIds = TRAINING_STAGES.map((s) => s.id);
    expect(stageIds).toContain('stage1_platform');
    expect(stageIds).toContain('stage2_grants');

    const stage1Lessons = TRAINING_LESSONS.filter((l) => l.stage === 'stage1_platform');
    const stage2Lessons = TRAINING_LESSONS.filter((l) => l.stage === 'stage2_grants');

    // Stage 1 covers General + M1 to M13 (at least 14 lessons)
    expect(stage1Lessons.length).toBeGreaterThanOrEqual(14);
    const stage1Refs = stage1Lessons.map((l) => l.moduleRef);
    expect(stage1Refs).toContain('GENERAL');
    expect(stage1Refs).toContain('M1');
    expect(stage1Refs).toContain('M2');
    expect(stage1Refs).toContain('M5');
    expect(stage1Refs).toContain('M6');
    expect(stage1Refs).toContain('M13');

    // Stage 2 covers Call, Consortium, Proposal, Submission (4 stages)
    expect(stage2Lessons.length).toBe(4);
    const stage2Ids = stage2Lessons.map((l) => l.id);
    expect(stage2Ids).toContain('grant-step1-calls');
    expect(stage2Ids).toContain('grant-step2-consortium');
    expect(stage2Ids).toContain('grant-step3-proposal');
    expect(stage2Ids).toContain('grant-step4-submission');
  });

  it('ensures all quizzes have valid options and index bounds', () => {
    for (const lesson of TRAINING_LESSONS) {
      if (lesson.quiz) {
        for (const q of lesson.quiz) {
          expect(q.options.length).toBeGreaterThanOrEqual(2);
          expect(q.correctIndex).toBeGreaterThanOrEqual(0);
          expect(q.correctIndex).toBeLessThan(q.options.length);
          expect(q.explanation.length).toBeGreaterThan(0);
        }
      }
    }
  });

  it('ensures templates repository has content and valid format', () => {
    expect(ACADEMY_TEMPLATES.length).toBeGreaterThanOrEqual(3);
    for (const tmpl of ACADEMY_TEMPLATES) {
      expect(tmpl.id.length).toBeGreaterThan(0);
      expect(tmpl.titleTr.length).toBeGreaterThan(0);
      expect(tmpl.content.length).toBeGreaterThan(50);
      expect(tmpl.format.length).toBeGreaterThan(0);
    }
  });
});
