import OutreachPage from '../outreach/page';
export default OutreachPage;
