// Role is imported as a value, not a string literal: src/types/prisma-override.d.ts
// declares it as a TS enum, so 'MEMBER' is not assignable to Role (TS2322).
import { Role } from '@prisma/client';

import { plansGrantingModule } from '@/lib/billing/catalog';
import { ModuleManifest } from '@/lib/modules/types';

export const m12Manifest: ModuleManifest = {
  id: 'M12',
  key: 'outreach',
  name: 'Expert Outreach Assistant',
  description: 'Automated native language outreach in 24 EU languages, 31,400+ EU evaluators and quota tracking.',
  version: '1.0',
  requires: ['M1', 'M4'],
  recommends: [],
  planTiers: plansGrantingModule('M12'),
  addOnSku: null,
  routes: [{ path: 'outreach', permission: 'outreach:read' }],
  nav: [{ labelKey: 'outreach', routeKey: 'outreach', order: 80 }],
  permissions: [
    { id: 'outreach:read', minRole: Role.MEMBER },
    { id: 'outreach:write', minRole: Role.WRITER },
  ],
  tables: ['Relationship', 'Interaction'],
  isActive: true,
};
