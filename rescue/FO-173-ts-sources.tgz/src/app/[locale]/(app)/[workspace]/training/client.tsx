'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import { getWorkspaceRoute, type WorkspaceRouteKey } from '@/lib/routes';
import {
  TRAINING_STAGES,
  TRAINING_LESSONS,
  ACADEMY_TEMPLATES,
} from '@/modules/m14/content';
import { TrainingLesson, TrainingStage } from '@/modules/m14/types';

interface TrainingClientProps {
  locale: string;
  workspace: string;
}

export function TrainingClient({ locale, workspace }: TrainingClientProps) {
  const isTr = locale === 'tr';

  // Active Main Tab: 'stage1_platform' | 'stage2_grants' | 'templates' | 'diagnostic'
  const [activeTab, setActiveTab] = useState<TrainingStage | 'templates' | 'diagnostic'>('stage1_platform');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<'all' | 'beginner' | 'intermediate' | 'advanced'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Selected Lesson for Reader Modal / Drawer
  const [activeLesson, setActiveLesson] = useState<TrainingLesson | null>(null);

  // Completed Lessons Tracked in LocalStorage
  const [completedLessonIds, setCompletedLessonIds] = useState<string[]>([]);
  const [mounted, setMounted] = useState(false);

  // Active Quiz State for current lesson
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  // Copy notification state
  const [copiedTemplateId, setCopiedTemplateId] = useState<string | null>(null);

  // Diagnostic Readiness Audit State
  const [diagnosticAnswers, setDiagnosticAnswers] = useState({
    callTarget: 'yes',
    partners: 'partial',
    evidence: 'no',
    budget: 'partial',
    evaluator: 'no',
  });

  // Load completed lessons from localStorage on mount
  useEffect(() => {
    setMounted(true);
    try {
      const stored = localStorage.getItem(`fonbridge_academy_progress_${workspace}`);
      if (stored) {
        setCompletedLessonIds(JSON.parse(stored));
      }
    } catch {
      // Ignore localStorage errors
    }
  }, [workspace]);

  // Persist completed lessons
  const toggleLessonComplete = (lessonId: string) => {
    setCompletedLessonIds((prev) => {
      const next = prev.includes(lessonId)
        ? prev.filter((id) => id !== lessonId)
        : [...prev, lessonId];
      try {
        localStorage.setItem(`fonbridge_academy_progress_${workspace}`, JSON.stringify(next));
      } catch {
        // Ignore
      }
      return next;
    });
  };

  // Filter lessons
  const currentStageLessons = useMemo(() => {
    if (activeTab === 'templates' || activeTab === 'diagnostic') return [];
    return TRAINING_LESSONS.filter((l) => l.stage === activeTab);
  }, [activeTab]);

  const categories = useMemo(() => {
    const set = new Set<string>();
    currentStageLessons.forEach((l) => set.add(isTr ? l.category : l.categoryEn));
    return ['all', ...Array.from(set)];
  }, [currentStageLessons, isTr]);

  const filteredLessons = useMemo(() => {
    return currentStageLessons.filter((l) => {
      const title = isTr ? l.titleTr : l.titleEn;
      const desc = isTr ? l.shortDescTr : l.shortDescEn;
      const cat = isTr ? l.category : l.categoryEn;

      const matchesSearch =
        searchQuery === '' ||
        title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        desc.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (l.moduleRef && l.moduleRef.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesLevel = selectedLevel === 'all' || l.level === selectedLevel;
      const matchesCategory = selectedCategory === 'all' || cat === selectedCategory;

      return matchesSearch && matchesLevel && matchesCategory;
    });
  }, [currentStageLessons, searchQuery, selectedLevel, selectedCategory, isTr]);

  // Total Progress Stats
  const totalLessonsCount = TRAINING_LESSONS.length;
  const totalCompletedCount = completedLessonIds.length;
  const progressPercent = totalLessonsCount > 0 ? Math.round((totalCompletedCount / totalLessonsCount) * 100) : 0;

  // Stage 1 vs Stage 2 specific counts
  const stage1Total = TRAINING_LESSONS.filter((l) => l.stage === 'stage1_platform').length;
  const stage1Completed = TRAINING_LESSONS.filter(
    (l) => l.stage === 'stage1_platform' && completedLessonIds.includes(l.id)
  ).length;

  const stage2Total = TRAINING_LESSONS.filter((l) => l.stage === 'stage2_grants').length;
  const stage2Completed = TRAINING_LESSONS.filter(
    (l) => l.stage === 'stage2_grants' && completedLessonIds.includes(l.id)
  ).length;

  // Handle lesson open
  const openLesson = (lesson: TrainingLesson) => {
    setActiveLesson(lesson);
    setQuizAnswers({});
    setQuizSubmitted(false);
  };

  // Copy template handler
  const handleCopyTemplate = (id: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedTemplateId(id);
    setTimeout(() => setCopiedTemplateId(null), 3000);
  };

  // Calculate diagnostic readiness score
  const diagnosticScore = useMemo(() => {
    let score = 0;
    if (diagnosticAnswers.callTarget === 'yes') score += 20;
    else if (diagnosticAnswers.callTarget === 'partial') score += 10;

    if (diagnosticAnswers.partners === 'yes') score += 25;
    else if (diagnosticAnswers.partners === 'partial') score += 12;

    if (diagnosticAnswers.evidence === 'yes') score += 20;
    else if (diagnosticAnswers.evidence === 'partial') score += 10;

    if (diagnosticAnswers.budget === 'yes') score += 15;
    else if (diagnosticAnswers.budget === 'partial') score += 8;

    if (diagnosticAnswers.evaluator === 'yes') score += 20;
    else if (diagnosticAnswers.evaluator === 'partial') score += 10;

    return Math.min(100, score);
  }, [diagnosticAnswers]);

  return (
    <div className="space-y-8 font-sans pb-16">
      {/* ───────────────────────────────────────────────────────────────────────── */}
      {/* HERO SECTION & PROGRESS DASHBOARD */}
      {/* ───────────────────────────────────────────────────────────────────────── */}
      <div className="relative overflow-hidden rounded-2xl bg-surface border border-line p-6 md:p-8 shadow-xs">
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-accent/15 text-accent-ink border border-accent/20">
              <span>🎓</span>
              <span>{isTr ? 'FonBridge Eğitim & Akademi Modülü (M14)' : 'FonBridge Training & Academy (M14)'}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
            </div>

            <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-ink tracking-tight">
              {isTr ? 'Proje & Hibe Mükemmeliyet Akademisi' : 'Grant & Project Mastery Academy'}
            </h1>

            <p className="text-sm md:text-base text-ink-2 leading-relaxed">
              {isTr
                ? 'FonBridge sistem ve modül kılavuzlarından; çağrı arama, ortak bulma, konsorsiyum kurma ve hibe teklifi yazımına kadar uçtan uca interaktif eğitim ve rehberlik platformu.'
                : 'Interactive learning masterclass covering FonBridge system architecture, module usage, plus end-to-end grant lifecycle from call discovery to proposal writing.'}
            </p>
          </div>

          {/* Quick Progress KPI Widget */}
          <div className="w-full lg:w-80 bg-surface-hover/80 border border-line rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-muted">
                {isTr ? 'Genel Eğitim İlerlemesi' : 'Overall Progress'}
              </span>
              <span className="text-sm font-bold text-accent-ink">
                %{mounted ? progressPercent : 0}
              </span>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-2.5 bg-line rounded-full overflow-hidden">
              <div
                className="h-full bg-accent transition-all duration-500 rounded-full"
                style={{ width: `${mounted ? progressPercent : 0}%` }}
              />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-line/60">
              <div>
                <span className="text-muted block">{isTr ? 'Bölüm 1 (Sistem)' : 'Stage 1 (System)'}</span>
                <span className="font-semibold text-ink">
                  {mounted ? stage1Completed : 0} / {stage1Total} {isTr ? 'Tamamlandı' : 'Done'}
                </span>
              </div>
              <div>
                <span className="text-muted block">{isTr ? 'Bölüm 2 (Hibe)' : 'Stage 2 (Grants)'}</span>
                <span className="font-semibold text-ink">
                  {mounted ? stage2Completed : 0} / {stage2Total} {isTr ? 'Tamamlandı' : 'Done'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ───────────────────────────────────────────────────────────────────────── */}
      {/* NAVIGATION TABS */}
      {/* ───────────────────────────────────────────────────────────────────────── */}
      <div className="flex flex-wrap items-center gap-2 border-b border-line pb-2">
        <button
          onClick={() => {
            setActiveTab('stage1_platform');
            setSelectedCategory('all');
          }}
          className={`px-4 py-2.5 rounded-xl font-medium text-sm flex items-center gap-2 transition-all ${
            activeTab === 'stage1_platform'
              ? 'bg-accent text-white shadow-sm font-semibold'
              : 'text-ink-2 hover:bg-surface-hover hover:text-ink'
          }`}
        >
          <span>🖥️</span>
          <span>{isTr ? 'Bölüm 1: FonBridge Sistem & Modül Kılavuzu' : 'Stage 1: System & Modules Guide'}</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-black/15 font-mono">
            {stage1Completed}/{stage1Total}
          </span>
        </button>

        <button
          onClick={() => {
            setActiveTab('stage2_grants');
            setSelectedCategory('all');
          }}
          className={`px-4 py-2.5 rounded-xl font-medium text-sm flex items-center gap-2 transition-all ${
            activeTab === 'stage2_grants'
              ? 'bg-accent text-white shadow-sm font-semibold'
              : 'text-ink-2 hover:bg-surface-hover hover:text-ink'
          }`}
        >
          <span>🌍</span>
          <span>{isTr ? 'Bölüm 2: Genel Proje & Hibe Yaşam Döngüsü' : 'Stage 2: Grants Lifecycle Masterclass'}</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-black/15 font-mono">
            {stage2Completed}/{stage2Total}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('templates')}
          className={`px-4 py-2.5 rounded-xl font-medium text-sm flex items-center gap-2 transition-all ${
            activeTab === 'templates'
              ? 'bg-accent text-white shadow-sm font-semibold'
              : 'text-ink-2 hover:bg-surface-hover hover:text-ink'
          }`}
        >
          <span>📥</span>
          <span>{isTr ? 'Hazır Şablonlar & Kontrol Listeleri' : 'Templates & Checklists'}</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-line font-mono text-muted">
            {ACADEMY_TEMPLATES.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('diagnostic')}
          className={`px-4 py-2.5 rounded-xl font-medium text-sm flex items-center gap-2 transition-all ${
            activeTab === 'diagnostic'
              ? 'bg-accent text-white shadow-sm font-semibold'
              : 'text-ink-2 hover:bg-surface-hover hover:text-ink'
          }`}
        >
          <span>📊</span>
          <span>{isTr ? 'Proje Hazırlık Değerlendiricisi' : 'Readiness Diagnostic'}</span>
          <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-amber/20 text-amber">
            AUDIT
          </span>
        </button>
      </div>

      {/* ───────────────────────────────────────────────────────────────────────── */}
      {/* STAGE DESCRIPTION BANNER */}
      {/* ───────────────────────────────────────────────────────────────────────── */}
      {activeTab === 'stage1_platform' && (
        <div className="bg-surface border border-line rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-lg font-bold text-ink flex items-center gap-2">
              <span>🖥️</span>
              <span>{isTr ? 'Sistem ve Modül Kullanım Rehberi' : 'Platform & Module Walkthrough'}</span>
            </h2>
            <p className="text-xs md:text-sm text-muted">
              {isTr
                ? 'Çalışma alanı kurulumu, RBAC rolleri, 4-Eyes çift onay güvenlik standardı ve M1-M13 modüllerinin adım adım uygulamalı iş akışları.'
                : 'Workspace setup, RBAC permissions, 4-Eyes dual review rules, and step-by-step guides for M1 to M13 modules.'}
            </p>
          </div>
          <div className="text-xs text-muted bg-surface-hover px-3 py-1.5 rounded-lg border border-line">
            {isTr ? 'Tavsiye: Modülleri sırayla inceleyin' : 'Recommended: Follow modules in order'}
          </div>
        </div>
      )}

      {activeTab === 'stage2_grants' && (
        <div className="bg-surface border border-line rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-lg font-bold text-ink flex items-center gap-2">
              <span>🌍</span>
              <span>{isTr ? 'Uçtan Uca Hibe ve Proje Yaşam Döngüsü Masterclass' : 'End-to-End Grants Lifecycle Masterclass'}</span>
            </h2>
            <p className="text-xs md:text-sm text-muted">
              {isTr
                ? 'Aşama 1 (Çağrı Arama) → Aşama 2 (Konsorsiyum Kurma) → Aşama 3 (Teklif Yazımı & Kalite) → Aşama 4 (Başvuru & GAP) metodolojisi.'
                : 'Stage 1 (Call Search) → Stage 2 (Consortium) → Stage 3 (Proposal Writing) → Stage 4 (Submission & GAP) methodology.'}
            </p>
          </div>
          <div className="text-xs text-muted bg-surface-hover px-3 py-1.5 rounded-lg border border-line">
            {isTr ? 'Horizon Europe & Ulusal Hibeler' : 'Horizon Europe & National Grants'}
          </div>
        </div>
      )}

      {/* ───────────────────────────────────────────────────────────────────────── */}
      {/* SEARCH AND FILTERS (For Lesson Stages) */}
      {/* ───────────────────────────────────────────────────────────────────────── */}
      {(activeTab === 'stage1_platform' || activeTab === 'stage2_grants') && (
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <input
              type="text"
              placeholder={isTr ? 'Ders veya modül ara (örn: CORDIS, konsept, bütçe)...' : 'Search lessons (e.g. CORDIS, budget)...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-surface border border-line rounded-xl text-sm text-ink placeholder:text-muted focus:outline-hidden focus:border-accent"
            />
            <span className="absolute left-3 top-2.5 text-muted text-sm">🔍</span>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-muted hover:text-ink text-xs"
              >
                ✕
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Level Filter */}
            <div className="flex items-center gap-1 bg-surface border border-line rounded-xl p-1 text-xs">
              <button
                onClick={() => setSelectedLevel('all')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  selectedLevel === 'all' ? 'bg-accent/15 text-accent-ink font-semibold' : 'text-muted hover:text-ink'
                }`}
              >
                {isTr ? 'Tüm Seviyeler' : 'All Levels'}
              </button>
              <button
                onClick={() => setSelectedLevel('beginner')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  selectedLevel === 'beginner' ? 'bg-accent/15 text-accent-ink font-semibold' : 'text-muted hover:text-ink'
                }`}
              >
                {isTr ? 'Başlangıç' : 'Beginner'}
              </button>
              <button
                onClick={() => setSelectedLevel('intermediate')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  selectedLevel === 'intermediate' ? 'bg-accent/15 text-accent-ink font-semibold' : 'text-muted hover:text-ink'
                }`}
              >
                {isTr ? 'Orta' : 'Intermediate'}
              </button>
              <button
                onClick={() => setSelectedLevel('advanced')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  selectedLevel === 'advanced' ? 'bg-accent/15 text-accent-ink font-semibold' : 'text-muted hover:text-ink'
                }`}
              >
                {isTr ? 'İleri' : 'Advanced'}
              </button>
            </div>

            {/* Category Filter */}
            {categories.length > 2 && (
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-surface border border-line rounded-xl px-3 py-2 text-xs font-medium text-ink focus:outline-hidden"
              >
                <option value="all">{isTr ? 'Tüm Kategoriler' : 'All Categories'}</option>
                {categories
                  .filter((c) => c !== 'all')
                  .map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
              </select>
            )}
          </div>
        </div>
      )}

      {/* ───────────────────────────────────────────────────────────────────────── */}
      {/* LESSON CARDS GRID */}
      {/* ───────────────────────────────────────────────────────────────────────── */}
      {(activeTab === 'stage1_platform' || activeTab === 'stage2_grants') && (
        <>
          {filteredLessons.length === 0 ? (
            <div className="bg-surface border border-line rounded-2xl p-12 text-center space-y-3">
              <span className="text-4xl">🔎</span>
              <h3 className="text-lg font-bold text-ink">
                {isTr ? 'Aradığınız kriterlere uygun ders bulunamadı' : 'No lessons found'}
              </h3>
              <p className="text-sm text-muted">
                {isTr ? 'Arama teriminizi veya filtreleri sıfırlayarak tekrar deneyin.' : 'Try adjusting your search query or filters.'}
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedLevel('all');
                  setSelectedCategory('all');
                }}
                className="mt-2 text-xs font-semibold text-accent-ink hover:underline"
              >
                {isTr ? 'Filtreleri Temizle' : 'Clear Filters'}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredLessons.map((lesson) => {
                const isCompleted = completedLessonIds.includes(lesson.id);
                return (
                  <div
                    key={lesson.id}
                    className={`group bg-surface border rounded-2xl p-5 flex flex-col justify-between transition-all duration-200 hover:shadow-md ${
                      isCompleted ? 'border-ok/30 bg-ok/5' : 'border-line hover:border-accent/40'
                    }`}
                  >
                    <div className="space-y-4">
                      {/* Card Header Badges */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl p-2 rounded-xl bg-surface-hover border border-line/60">
                            {lesson.icon}
                          </span>
                          {lesson.moduleRef && (
                            <span className="px-2 py-0.5 rounded-md text-xs font-mono font-bold bg-accent/15 text-accent-ink border border-accent/20">
                              {lesson.moduleRef}
                            </span>
                          )}
                          <span className="text-xs px-2 py-0.5 rounded-md bg-surface-hover text-muted font-medium">
                            {isTr ? lesson.category : lesson.categoryEn}
                          </span>
                        </div>

                        {/* Completion Indicator */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleLessonComplete(lesson.id);
                          }}
                          title={isTr ? 'Tamamlandı olarak işaretle' : 'Toggle completed'}
                          className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors ${
                            isCompleted
                              ? 'bg-ok text-white shadow-2xs'
                              : 'bg-surface-hover text-muted hover:text-ink border border-line'
                          }`}
                        >
                          {isCompleted ? '✓' : '○'}
                        </button>
                      </div>

                      {/* Title & Short Description */}
                      <div className="space-y-1.5">
                        <h3 className="font-bold text-base text-ink group-hover:text-accent transition-colors">
                          {isTr ? lesson.titleTr : lesson.titleEn}
                        </h3>
                        <p className="text-xs text-ink-2 leading-relaxed line-clamp-2">
                          {isTr ? lesson.shortDescTr : lesson.shortDescEn}
                        </p>
                      </div>
                    </div>

                    {/* Card Footer */}
                    <div className="pt-4 mt-4 border-t border-line/60 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-3 text-muted">
                        <span>⏱️ {lesson.durationMinutes} dk</span>
                        <span className="capitalize">
                          {lesson.level === 'beginner'
                            ? isTr ? 'Başlangıç' : 'Beginner'
                            : lesson.level === 'intermediate'
                            ? isTr ? 'Orta' : 'Intermediate'
                            : isTr ? 'İleri' : 'Advanced'}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {lesson.actionRoute && (
                          <Link
                            href={getWorkspaceRoute(lesson.actionRoute, locale, workspace)}
                            className="p-1.5 rounded-lg bg-surface-hover text-muted hover:text-accent hover:bg-accent/10 transition-colors"
                            title={isTr ? lesson.actionLabelTr : lesson.actionLabelEn}
                          >
                            ↗
                          </Link>
                        )}
                        <button
                          onClick={() => openLesson(lesson)}
                          className="px-3 py-1.5 rounded-lg bg-accent text-white font-medium hover:bg-accent-strong transition-colors"
                        >
                          {isTr ? 'Kılavuzu Oku' : 'Read Guide'}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* ───────────────────────────────────────────────────────────────────────── */}
      {/* TAB: TEMPLATES & CHECKLISTS REPOSITORY */}
      {/* ───────────────────────────────────────────────────────────────────────── */}
      {activeTab === 'templates' && (
        <div className="space-y-6">
          <div className="bg-surface border border-line rounded-xl p-5">
            <h2 className="text-lg font-bold text-ink flex items-center gap-2">
              <span>📥</span>
              <span>{isTr ? 'Hazır Hibe ve Teklif Şablonları Deposu' : 'Grant Templates & Checklists Repository'}</span>
            </h2>
            <p className="text-xs md:text-sm text-muted mt-1">
              {isTr
                ? 'Horizon Europe ve ulusal hibe projelerinizde doğrudan kullanabileceğiniz doğrulanmış şablonlar, kontrol listeleri ve sözleşme modelleri.'
                : 'Verified proposal checklists, EoI formats, and DESCA consortium guidelines ready to copy or download.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {ACADEMY_TEMPLATES.map((tmpl) => (
              <div
                key={tmpl.id}
                className="bg-surface border border-line rounded-2xl p-6 flex flex-col justify-between space-y-4 hover:border-accent/40 transition-colors"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="px-2.5 py-1 rounded-md bg-accent/15 text-accent-ink font-semibold">
                      {isTr ? tmpl.categoryTr : tmpl.categoryEn}
                    </span>
                    <span className="font-mono text-muted text-[11px]">{tmpl.format}</span>
                  </div>

                  <h3 className="text-base font-bold text-ink">
                    {isTr ? tmpl.titleTr : tmpl.titleEn}
                  </h3>

                  <div className="p-3 bg-ground rounded-xl text-xs font-mono text-ink-2 max-h-48 overflow-y-auto whitespace-pre-wrap border border-line">
                    {tmpl.content}
                  </div>
                </div>

                <div className="pt-3 border-t border-line flex items-center justify-between">
                  <button
                    onClick={() => handleCopyTemplate(tmpl.id, tmpl.content)}
                    className="w-full py-2 px-4 rounded-xl bg-accent text-white font-medium text-xs hover:bg-accent-strong transition-colors flex items-center justify-center gap-2"
                  >
                    <span>{copiedTemplateId === tmpl.id ? '✓' : '📋'}</span>
                    <span>
                      {copiedTemplateId === tmpl.id
                        ? isTr ? 'Panoya Kopyalandı!' : 'Copied to Clipboard!'
                        : isTr ? 'Metni Kopyala' : 'Copy Content'}
                    </span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ───────────────────────────────────────────────────────────────────────── */}
      {/* TAB: DIAGNOSTIC READINESS AUDIT TOOL */}
      {/* ───────────────────────────────────────────────────────────────────────── */}
      {activeTab === 'diagnostic' && (
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="bg-surface border border-line rounded-2xl p-6 md:p-8 space-y-6">
            <div className="space-y-2 border-b border-line pb-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-amber/15 text-amber border border-amber/20">
                <span>⚡</span>
                <span>{isTr ? 'İnteraktif Proje Sağlık & Hazırlık Denetimi' : 'Interactive Project Readiness Audit'}</span>
              </div>
              <h2 className="text-xl md:text-2xl font-bold text-ink">
                {isTr ? 'Projeniz AB veya Ulusal Hibe Başvurusuna Ne Kadar Hazır?' : 'How Ready is Your Proposal for Grant Submission?'}
              </h2>
              <p className="text-sm text-ink-2">
                {isTr
                  ? 'Aşağıdaki 5 kritik soruyu yanıtlayarak projenizin eksik yönlerini tespit edin ve hangi FonBridge modülünden destek almanız gerektiğini anında görün.'
                  : 'Answer 5 key diagnostic questions to uncover proposal bottlenecks and identify which FonBridge modules to leverage.'}
              </p>
            </div>

            {/* Questions List */}
            <div className="space-y-6">
              {/* Question 1 */}
              <div className="space-y-2">
                <label className="text-sm font-bold text-ink block">
                  {isTr ? '1. Hedeflenen Çağrı ve Şartname Analizi (M13)' : '1. Target Call & Scope Analysis (M13)'}
                </label>
                <p className="text-xs text-muted">
                  {isTr
                    ? 'Çağrının Expected Outcomes (Beklenen Çıktılar) ve TRL şartları resmi olarak analiz edilip özetlendi mi?'
                    : 'Have the expected outcomes, scope, and TRL requirements been synthesized?'}
                </p>
                <div className="grid grid-cols-3 gap-3 pt-1">
                  {[
                    { val: 'yes', labelTr: 'Evet, Tam Analiz Edildi (%100)', labelEn: 'Yes, Fully Analyzed' },
                    { val: 'partial', labelTr: 'Kısmen, Genel Bilgimiz Var', labelEn: 'Partially Known' },
                    { val: 'no', labelTr: 'Hayır, Şartname İncelenmedi', labelEn: 'No, Not Analyzed' },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setDiagnosticAnswers((prev) => ({ ...prev, callTarget: opt.val as any }))}
                      className={`p-3 rounded-xl border text-xs font-medium text-left transition-all ${
                        diagnosticAnswers.callTarget === opt.val
                          ? 'border-accent bg-accent/10 text-accent-ink font-semibold'
                          : 'border-line bg-surface hover:bg-surface-hover text-ink-2'
                      }`}
                    >
                      {isTr ? opt.labelTr : opt.labelEn}
                    </button>
                  ))}
                </div>
              </div>

              {/* Question 2 */}
              <div className="space-y-2">
                <label className="text-sm font-bold text-ink block">
                  {isTr ? '2. Konsorsiyum Dengesi & 3 Ülke Kuralı (M1, M8, M12)' : '2. Consortium Balance & 3-Country Rule (M1, M8, M12)'}
                </label>
                <p className="text-xs text-muted">
                  {isTr
                    ? 'En az 3 farklı ülkeden 3 bağımsız kurum var mı? Akademi, Sanayi (KOBİ) ve Son Kullanıcı dengesi sağlandı mı?'
                    : 'Are at least 3 distinct countries represented with balanced Academia, SME, and End-User participation?'}
                </p>
                <div className="grid grid-cols-3 gap-3 pt-1">
                  {[
                    { val: 'yes', labelTr: 'Tam Konsorsiyum Hazır', labelEn: 'Consortium Complete' },
                    { val: 'partial', labelTr: 'Ortak Arayışımız Sürüyor', labelEn: 'Searching Partners' },
                    { val: 'no', labelTr: 'Yalnızca Tek Başınayız', labelEn: 'Sole Applicant / None' },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setDiagnosticAnswers((prev) => ({ ...prev, partners: opt.val as any }))}
                      className={`p-3 rounded-xl border text-xs font-medium text-left transition-all ${
                        diagnosticAnswers.partners === opt.val
                          ? 'border-accent bg-accent/10 text-accent-ink font-semibold'
                          : 'border-line bg-surface hover:bg-surface-hover text-ink-2'
                      }`}
                    >
                      {isTr ? opt.labelTr : opt.labelEn}
                    </button>
                  ))}
                </div>
              </div>

              {/* Question 3 */}
              <div className="space-y-2">
                <label className="text-sm font-bold text-ink block">
                  {isTr ? '3. Kanıt Paketi & AB Politika Referansları (M3)' : '3. Evidence Pack & EU Policy Citations (M3)'}
                </label>
                <p className="text-xs text-muted">
                  {isTr
                    ? 'Green Deal, Digital Decade veya SDG göstergelerine dayanan doğrulanabilir istatistiki kanıtlar eklendi mi?'
                    : 'Are claims substantiated with verifiable Eurostat or EU policy data?'}
                </p>
                <div className="grid grid-cols-3 gap-3 pt-1">
                  {[
                    { val: 'yes', labelTr: 'Resmi Kanıtlar Eklendi', labelEn: 'Yes, Documented' },
                    { val: 'partial', labelTr: 'Bazı Referanslar Var', labelEn: 'Some References' },
                    { val: 'no', labelTr: 'Henüz Kanıt Eklenmedi', labelEn: 'No Evidence Yet' },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setDiagnosticAnswers((prev) => ({ ...prev, evidence: opt.val as any }))}
                      className={`p-3 rounded-xl border text-xs font-medium text-left transition-all ${
                        diagnosticAnswers.evidence === opt.val
                          ? 'border-accent bg-accent/10 text-accent-ink font-semibold'
                          : 'border-line bg-surface hover:bg-surface-hover text-ink-2'
                      }`}
                    >
                      {isTr ? opt.labelTr : opt.labelEn}
                    </button>
                  ))}
                </div>
              </div>

              {/* Question 4 */}
              <div className="space-y-2">
                <label className="text-sm font-bold text-ink block">
                  {isTr ? '4. İş Paketleri & Kişi-Ay (Person-Month) Bütçesi (M5, M11)' : '4. Work Packages & Person-Month Budget (M5, M11)'}
                </label>
                <p className="text-xs text-muted">
                  {isTr
                    ? 'WP liderlikleri dağıtıldı mı? Kişi-Ay (PM) ve doğrudan maliyet hesapları kuruşu kuruşuna denk mi?'
                    : 'Are Work Package person-months and direct costs calculated with precision?'}
                </p>
                <div className="grid grid-cols-3 gap-3 pt-1">
                  {[
                    { val: 'yes', labelTr: 'Bütçe & WP Tamamlandı', labelEn: 'Budget & WPs Ready' },
                    { val: 'partial', labelTr: 'Kaba Taslak Hazır', labelEn: 'Rough Estimate Only' },
                    { val: 'no', labelTr: 'Bütçe Hesaplanmadı', labelEn: 'Not Calculated' },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setDiagnosticAnswers((prev) => ({ ...prev, budget: opt.val as any }))}
                      className={`p-3 rounded-xl border text-xs font-medium text-left transition-all ${
                        diagnosticAnswers.budget === opt.val
                          ? 'border-accent bg-accent/10 text-accent-ink font-semibold'
                          : 'border-line bg-surface hover:bg-surface-hover text-ink-2'
                      }`}
                    >
                      {isTr ? opt.labelTr : opt.labelEn}
                    </button>
                  ))}
                </div>
              </div>

              {/* Question 5 */}
              <div className="space-y-2">
                <label className="text-sm font-bold text-ink block">
                  {isTr ? '5. Hakem Simülasyonu & Yapay Zeka ESR Puanı (M6)' : '5. Evaluator Lens & ESR AI Simulation (M6)'}
                </label>
                <p className="text-xs text-muted">
                  {isTr
                    ? 'Teklif metniniz Excellence, Impact, Implementation kriterlerinde derin AI hakem denetiminden geçirildi mi?'
                    : 'Has the draft been scored across Excellence, Impact, and Implementation criteria?'}
                </p>
                <div className="grid grid-cols-3 gap-3 pt-1">
                  {[
                    { val: 'yes', labelTr: '13+/15 Puan Alındı', labelEn: 'Scored 13+/15 ESR' },
                    { val: 'partial', labelTr: 'Kısmen Puanlandı', labelEn: 'Partial Review' },
                    { val: 'no', labelTr: 'Hakem Simülasyonu Yapılmadı', labelEn: 'Not Simulated' },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setDiagnosticAnswers((prev) => ({ ...prev, evaluator: opt.val as any }))}
                      className={`p-3 rounded-xl border text-xs font-medium text-left transition-all ${
                        diagnosticAnswers.evaluator === opt.val
                          ? 'border-accent bg-accent/10 text-accent-ink font-semibold'
                          : 'border-line bg-surface hover:bg-surface-hover text-ink-2'
                      }`}
                    >
                      {isTr ? opt.labelTr : opt.labelEn}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Diagnostic Score Card & Recommendations */}
            <div className="pt-6 border-t border-line bg-surface-hover rounded-xl p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-muted">
                    {isTr ? 'Hesaplanan Hibe Başvuru Hazırlık Skoru' : 'Calculated Grant Readiness Score'}
                  </span>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-3xl font-black text-ink">%{diagnosticScore}</span>
                    <span
                      className={`text-xs px-2.5 py-1 rounded-full font-bold ${
                        diagnosticScore >= 80
                          ? 'bg-ok/20 text-ok border border-ok/30'
                          : diagnosticScore >= 50
                          ? 'bg-amber/20 text-amber border border-amber/30'
                          : 'bg-bad/20 text-bad border border-bad/30'
                      }`}
                    >
                      {diagnosticScore >= 80
                        ? isTr ? 'BAŞVURUYA ÇOK YAKIN' : 'READY TO SUBMIT'
                        : diagnosticScore >= 50
                        ? isTr ? 'GELİŞTİRİLMESİ GEREKEN ALANLAR VAR' : 'IN PROGRESS'
                        : isTr ? 'ÖNEMLİ EKSİKLER MEVCUT' : 'CRITICAL GAPS'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Link
                    href={getWorkspaceRoute('pipeline', locale, workspace)}
                    className="px-4 py-2 bg-accent text-white font-medium text-xs rounded-xl hover:bg-accent-strong transition-colors"
                  >
                    {isTr ? 'Pipeline\'da Projeyi Başlat' : 'Open Project in Pipeline'}
                  </Link>
                </div>
              </div>

              {/* Tailored Module Advice */}
              <div className="space-y-2 pt-2 text-xs text-ink-2">
                <span className="font-bold text-ink block">
                  {isTr ? '💡 FonBridge Modül Önerileri:' : '💡 Recommended FonBridge Modules:'}
                </span>
                <ul className="list-disc pl-5 space-y-1">
                  {diagnosticAnswers.callTarget !== 'yes' && (
                    <li>
                      <strong>M13 (Çağrı Özeti):</strong>{' '}
                      {isTr
                        ? '100 sayfalık şartnameyi yükleyip 12 bölümlü stratejik özet çıkarın.'
                        : 'Upload call documentation to extract a 12-section strategic brief.'}
                    </li>
                  )}
                  {diagnosticAnswers.partners !== 'yes' && (
                    <li>
                      <strong>M1 (CORDIS) & M8 (Eşleştirici):</strong>{' '}
                      {isTr
                        ? 'Geçmiş AB projelerinde deneyimli lider koordinatör ve partnerleri bulun.'
                        : 'Discover experienced coordinators and partners via CORDIS big data.'}
                    </li>
                  )}
                  {diagnosticAnswers.evidence !== 'yes' && (
                    <li>
                      <strong>M3 (Kanıt Paketi):</strong>{' '}
                      {isTr
                        ? 'Teklif iddialarınızı Eurostat ve AB politika göstergeleriyle destekleyin.'
                        : 'Back claims with verified Eurostat and policy impact benchmarks.'}
                    </li>
                  )}
                  {diagnosticAnswers.evaluator !== 'yes' && (
                    <li>
                      <strong>M6 (Hakem Simülasyonu):</strong>{' '}
                      {isTr
                        ? 'Excellence, Impact ve Implementation puanınızı teslim öncesi simüle edin.'
                        : 'Simulate official ESR scores before submitting to the EU portal.'}
                    </li>
                  )}
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ───────────────────────────────────────────────────────────────────────── */}
      {/* LESSON DETAIL MODAL / DRAWER */}
      {/* ───────────────────────────────────────────────────────────────────────── */}
      {activeLesson && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-surface border border-line rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto">
            {/* Modal Header */}
            <div className="p-6 border-b border-line flex items-start justify-between gap-4 bg-surface-hover/50">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{activeLesson.icon}</span>
                  {activeLesson.moduleRef && (
                    <span className="px-2 py-0.5 rounded-md text-xs font-mono font-bold bg-accent/15 text-accent-ink border border-accent/20">
                      {activeLesson.moduleRef}
                    </span>
                  )}
                  <span className="text-xs px-2.5 py-0.5 rounded-md bg-surface border border-line text-muted font-medium">
                    {isTr ? activeLesson.category : activeLesson.categoryEn}
                  </span>
                  <span className="text-xs text-muted">
                    ⏱️ {activeLesson.durationMinutes} dk
                  </span>
                </div>

                <h2 className="text-xl md:text-2xl font-bold text-ink">
                  {isTr ? activeLesson.titleTr : activeLesson.titleEn}
                </h2>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => toggleLessonComplete(activeLesson.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                    completedLessonIds.includes(activeLesson.id)
                      ? 'bg-ok text-white shadow-2xs'
                      : 'bg-surface border border-line text-ink-2 hover:bg-surface-hover'
                  }`}
                >
                  <span>{completedLessonIds.includes(activeLesson.id) ? '✓' : '○'}</span>
                  <span>
                    {completedLessonIds.includes(activeLesson.id)
                      ? isTr ? 'Tamamlandı' : 'Completed'
                      : isTr ? 'Tamamla' : 'Mark as Done'}
                  </span>
                </button>

                <button
                  onClick={() => setActiveLesson(null)}
                  className="w-8 h-8 rounded-full bg-surface border border-line text-muted hover:text-ink flex items-center justify-center transition-colors"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Modal Content Body */}
            <div className="p-6 md:p-8 overflow-y-auto space-y-8 flex-1">
              {/* Short Intro */}
              <div className="p-4 rounded-xl bg-accent/5 border border-accent/15 text-sm text-ink-2">
                {isTr ? activeLesson.shortDescTr : activeLesson.shortDescEn}
              </div>

              {/* Sections */}
              <div className="space-y-6">
                {activeLesson.sections.map((section, idx) => (
                  <div key={idx} className="space-y-3 bg-surface border border-line rounded-xl p-5">
                    <h3 className="text-base font-bold text-ink flex items-center gap-2">
                      <span className="text-accent-ink font-mono text-sm">#{idx + 1}</span>
                      <span>{section.title}</span>
                    </h3>

                    <div className="text-sm text-ink-2 leading-relaxed whitespace-pre-line">
                      {section.content}
                    </div>

                    {section.codeOrFormula && (
                      <div className="p-3 rounded-lg bg-ground border border-line font-mono text-xs text-accent-ink font-semibold">
                        {section.codeOrFormula}
                      </div>
                    )}

                    {section.tips && section.tips.length > 0 && (
                      <div className="mt-3 p-3.5 bg-amber/10 border border-amber/20 rounded-xl space-y-1.5">
                        <span className="text-xs font-bold text-amber flex items-center gap-1.5 uppercase tracking-wider">
                          <span>💡</span> {isTr ? 'Uzman İpucu' : 'Expert Tip'}
                        </span>
                        <ul className="list-disc pl-5 text-xs text-ink-2 space-y-1">
                          {section.tips.map((tip, tIdx) => (
                            <li key={tIdx}>{tip}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {section.keyTakeaway && (
                      <div className="p-3 bg-ok/10 border border-ok/20 rounded-xl text-xs font-semibold text-ok flex items-start gap-2">
                        <span>🎯</span>
                        <span>{section.keyTakeaway}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Interactive Quiz (if available) */}
              {activeLesson.quiz && activeLesson.quiz.length > 0 && (
                <div className="border border-line rounded-2xl p-6 bg-surface-hover/50 space-y-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">📝</span>
                      <h3 className="text-base font-bold text-ink">
                        {isTr ? 'Mini Bilgi Sınavı & Pekiştirme' : 'Knowledge Check Quiz'}
                      </h3>
                    </div>
                    <span className="text-xs text-muted">
                      {activeLesson.quiz.length} {isTr ? 'Soru' : 'Question(s)'}
                    </span>
                  </div>

                  {activeLesson.quiz.map((q, qIdx) => {
                    const selectedOpt = quizAnswers[qIdx];
                    const isCorrect = selectedOpt === q.correctIndex;
                    return (
                      <div key={qIdx} className="space-y-3 bg-surface p-4 rounded-xl border border-line">
                        <p className="text-sm font-semibold text-ink">
                          {qIdx + 1}. {q.question}
                        </p>

                        <div className="space-y-2">
                          {q.options.map((opt, optIdx) => {
                            const isChosen = selectedOpt === optIdx;
                            let style = 'border-line bg-surface hover:bg-surface-hover text-ink-2';
                            if (quizSubmitted) {
                              if (optIdx === q.correctIndex) {
                                style = 'border-ok bg-ok/15 text-ok font-semibold';
                              } else if (isChosen && !isCorrect) {
                                style = 'border-bad bg-bad/15 text-bad';
                              }
                            } else if (isChosen) {
                              style = 'border-accent bg-accent/15 text-accent-ink font-semibold';
                            }

                            return (
                              <button
                                key={optIdx}
                                onClick={() => {
                                  if (!quizSubmitted) {
                                    setQuizAnswers((prev) => ({ ...prev, [qIdx]: optIdx }));
                                  }
                                }}
                                className={`w-full p-2.5 rounded-lg border text-xs text-left transition-all ${style}`}
                              >
                                {opt}
                              </button>
                            );
                          })}
                        </div>

                        {quizSubmitted && (
                          <div
                            className={`p-3 rounded-lg text-xs leading-relaxed ${
                              isCorrect ? 'bg-ok/10 text-ok border border-ok/20' : 'bg-bad/10 text-bad border border-bad/20'
                            }`}
                          >
                            <strong>{isCorrect ? '✓ Doğru!' : '✕ Yanlış!'}</strong> {q.explanation}
                          </div>
                        )}
                      </div>
                    );
                  })}

                  {!quizSubmitted ? (
                    <button
                      onClick={() => setQuizSubmitted(true)}
                      disabled={Object.keys(quizAnswers).length < activeLesson.quiz.length}
                      className="px-4 py-2 bg-accent text-white font-medium text-xs rounded-xl hover:bg-accent-strong disabled:opacity-50 transition-colors"
                    >
                      {isTr ? 'Cevapları Kontrol Et' : 'Submit Answers'}
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setQuizSubmitted(false);
                        setQuizAnswers({});
                      }}
                      className="text-xs text-accent-ink font-semibold hover:underline"
                    >
                      {isTr ? 'Testi Tekrar Çöz' : 'Retake Quiz'}
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 md:px-8 border-t border-line bg-surface-hover/60 flex items-center justify-between">
              <div>
                {activeLesson.actionRoute && (
                  <Link
                    href={getWorkspaceRoute(activeLesson.actionRoute, locale, workspace)}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-accent/15 text-accent-ink border border-accent/20 font-semibold text-xs hover:bg-accent/25 transition-colors"
                  >
                    <span>{isTr ? activeLesson.actionLabelTr : activeLesson.actionLabelEn}</span>
                    <span>→</span>
                  </Link>
                )}
              </div>

              <button
                onClick={() => {
                  if (!completedLessonIds.includes(activeLesson.id)) {
                    toggleLessonComplete(activeLesson.id);
                  }
                  setActiveLesson(null);
                }}
                className="px-5 py-2 rounded-xl bg-accent text-white font-semibold text-xs hover:bg-accent-strong transition-colors"
              >
                {isTr ? 'Anladım & Kapat' : 'Complete & Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
