// Role is imported as a value, not a string literal: src/types/prisma-override.d.ts
// declares it as a TS enum, so 'MEMBER' is not assignable to Role (TS2322).
import { Role } from '@prisma/client';

import { plansGrantingModule } from '@/lib/billing/catalog';
import { ModuleManifest } from '@/lib/modules/types';

export const m13Manifest: ModuleManifest = {
  id: 'M13',
  key: 'call-summary',
  name: 'Project Call Summary Generator',
  description: '12-section AI-powered strategic call brief and requirement analyzer from multi-format documents.',
  version: '1.0',
  requires: [],
  recommends: ['M9'],
  planTiers: plansGrantingModule('M13'),
  addOnSku: null,
  routes: [{ path: 'call-summary', permission: 'call-summary:read' }],
  nav: [{ labelKey: 'callSummary', routeKey: 'callSummary', order: 90 }],
  permissions: [
    { id: 'call-summary:read', minRole: Role.MEMBER },
    { id: 'call-summary:write', minRole: Role.WRITER },
  ],
  tables: ['Call', 'Topic'],
  isActive: true,
};
