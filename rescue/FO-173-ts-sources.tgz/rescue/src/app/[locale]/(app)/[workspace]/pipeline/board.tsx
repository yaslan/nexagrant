'use client';

import React, { useState, useTransition, useMemo, useEffect } from 'react';
import Link from 'next/link';
import { useTranslations } from 'next-intl';
import { Gate } from '@prisma/client';
import {
  Maximize2,
  X,
  ExternalLink,
  Users,
  MessageSquare,
  Send,
  Clock,
  ChevronRight,
  ArrowRight,
  Award,
  Copy,
  Check,
  Sparkles,
  UserCheck
} from 'lucide-react';
import {
  moveOpportunityStage,
  createOpportunity,
  assignOpportunityOwner,
  addOpportunityNote,
  getOpportunityFormMembers,
  getSuggestedTopics
} from './actions';
import type { NoteEntry, OpportunityItem, WorkspaceMember } from '@/lib/k5-pipeline/pipelineStore';
import { errorMessage } from '@/lib/errors';
import { useActionErrorText } from '@/lib/hooks/use-action-error-text';

interface KanbanBoardProps {
  /**
   * OpportunityItem, not the bare Opportunity row: the board reads `ownerName`
   * and `notesList`, which the pipeline store adds and the table does not have.
   * The page feeds it DB rows and in-memory rows merged into this one shape.
   */
  opportunities: OpportunityItem[];
  workspace?: string;
  locale?: string;
}

/**
 * Identity for a toast, so its dismiss timer can tell it apart from a later
 * one. A counter rather than `Date.now()`: the clock is impure during render,
 * and two toasts raised in the same millisecond would have collided.
 */
let toastSequence = 0;
const nextToastId = () => (toastSequence += 1);

/** The intended-role filter above the board; matches the <option> values. */
type RoleFilter = 'all' | 'coordinator' | 'partner';

const GATES: { key: Gate; subtitle: string; color: string }[] = [
  { key: 'G0', subtitle: 'Stratejik Uygunluk & Filtre', color: 'border-t-blue-500' },
  { key: 'G1', subtitle: 'Konsept Notu & Mimari', color: 'border-t-teal-500' },
  { key: 'G2', subtitle: 'Partner Eşleştirme & Bütçe', color: 'border-t-purple-500' },
  { key: 'G3', subtitle: 'Part A & B / Hakem Simülasyonu', color: 'border-t-amber-500' },
  { key: 'G4', subtitle: 'AB Portalına Teslim & Onay', color: 'border-t-emerald-500' },
];

/**
 * One card's note draft. `authorId` is REQUIRED, deliberately: the author
 * `<select>` below is controlled on this field, and React downgrades a
 * controlled select to an uncontrolled one the moment its `value` is
 * `undefined`. Making the field optional would legalise that; keeping it total
 * pushes the burden onto whoever writes the record — which is where it belongs.
 */
export type NoteInput = { text: string; authorId: string };

/**
 * Clear a card's note text after the note has been posted, without dropping who
 * was writing it.
 *
 * This used to be `{ ...prev[oppId], text: '' }` inline. `prev[oppId]` is
 * `NoteInput | undefined`, and spreading the undefined case produced
 * `{ text: '' }` with no `authorId`. That object is truthy, so the
 * `noteInputs[opp.id] || { text: '', authorId: ... }` repair further down never
 * fired; the missing field reached the controlled select as `value={undefined}`
 * and made the card's next note fall back to `members[0]` — silently posting it
 * under the wrong name.
 */
export function clearNoteText(
  prev: Record<string, NoteInput>,
  oppId: string,
  fallbackAuthorId: string
): Record<string, NoteInput> {
  return {
    ...prev,
    [oppId]: { text: '', authorId: prev[oppId]?.authorId ?? fallbackAuthorId },
  };
}

export default function KanbanBoard({
  opportunities: initialOpps,
  workspace = 'default',
  locale = 'tr',
}: KanbanBoardProps) {
  const t = useTranslations('pipeline');
  const [opps, setOpps] = useState<OpportunityItem[]>(initialOpps);
  const [isPending, startTransition] = useTransition();
  const errorText = useActionErrorText();

  // Real tenant members and live call topics — fetched once on mount, since this
  // client component has no server context of its own to read them with.
  const [members, setMembers] = useState<WorkspaceMember[]>([]);
  const [suggestedTopics, setSuggestedTopics] = useState<{ identifier: string; title: string }[]>([]);

  // Fullscreen Opportunity Modal State
  const [fullscreenOppId, setFullscreenOppId] = useState<string | null>(null);
  const [fullscreenNoteText, setFullscreenNoteText] = useState('');
  const [fullscreenNoteAuthorId, setFullscreenNoteAuthorId] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [copiedTopic, setCopiedTopic] = useState(false);

  const fullscreenOpp = useMemo(
    () => opps.find((o) => o.id === fullscreenOppId) || null,
    [opps, fullscreenOppId]
  );

  const openFullscreen = (opp: OpportunityItem) => {
    setFullscreenOppId(opp.id);
    const currentAuthor = noteInputs[opp.id]?.authorId || members[0]?.id || '';
    setFullscreenNoteAuthorId(currentAuthor);
    setFullscreenNoteText('');
  };

  const closeFullscreen = () => {
    setFullscreenOppId(null);
    setFullscreenNoteText('');
  };

  useEffect(() => {
    if (!fullscreenOppId) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setFullscreenOppId(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = originalOverflow;
    };
  }, [fullscreenOppId]);

  const handleCopyTopic = (topic: string) => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(topic);
      setCopiedTopic(true);
      setTimeout(() => setCopiedTopic(false), 2000);
    }
  };

  const handleAddFullscreenNote = (oppId: string) => {
    if (!fullscreenNoteText.trim()) return;

    const author = members.find((m) => m.id === fullscreenNoteAuthorId) || members[0];
    if (!author) {
      showToast('Kullanıcı listesi henüz yüklenmedi, lütfen tekrar deneyin.', 'error');
      return;
    }
    const text = fullscreenNoteText.trim();

    startTransition(async () => {
      try {
        const res = await addOpportunityNote({
          opportunityId: oppId,
          text,
          authorName: author.name,
          authorAvatar: author.avatar,
        });

        if (res.success && res.note) {
          setOpps((prev) =>
            prev.map((o) => {
              if (o.id === oppId) {
                const existingNotes = o.notesList || [];
                return { ...o, notesList: [...existingNotes, res.note] };
              }
              return o;
            })
          );

          setFullscreenNoteText('');
          showToast(`${author.name} kullanıcısının notu eklendi!`, 'success');
        }
      } catch (err) {
        console.error(err);
        showToast(errorText(err, 'Not eklenirken hata oluştu.'), 'error');
      }
    });
  };

  const handleMoveStageFromModal = (oppId: string, targetStage: Gate) => {
    if (fullscreenOpp?.stage === targetStage) return;

    setOpps((prev) =>
      prev.map((o) => (o.id === oppId ? { ...o, stage: targetStage } : o))
    );

    startTransition(async () => {
      try {
        await moveOpportunityStage(oppId, targetStage);
        showToast(`Fırsat ${targetStage} aşamasına taşındı.`, 'info');
      } catch (err) {
        console.error(err);
        showToast(errorText(err, 'Aşama güncellenirken hata oluştu.'), 'error');
        setOpps(initialOpps);
      }
    });
  };

  useEffect(() => {
    getOpportunityFormMembers().then((res) => {
      if (res.success) setMembers(res.members);
    });
    getSuggestedTopics().then((res) => {
      if (res.success) setSuggestedTopics(res.topics);
    });
  }, []);

  // Expanded cards state (default minimized for clean high-density view)
  const [expandedCardIds, setExpandedCardIds] = useState<Record<string, boolean>>({});
  const [allExpanded, setAllExpanded] = useState(false);

  // New Note Input State per Card
  const [noteInputs, setNoteInputs] = useState<Record<string, { text: string; authorId: string }>>({});

  const toggleExpand = (oppId: string) => {
    setExpandedCardIds((prev) => ({ ...prev, [oppId]: !prev[oppId] }));
  };

  const toggleAllExpand = () => {
    const nextState = !allExpanded;
    setAllExpanded(nextState);
    const newMap: Record<string, boolean> = {};
    opps.forEach((o) => {
      newMap[o.id] = nextState;
    });
    setExpandedCardIds(newMap);
  };

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<RoleFilter>('all');
  const [ownerFilter, setOwnerFilter] = useState<string>('all');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalStage, setModalStage] = useState<Gate>('G0');

  // New Opportunity Form
  const [formData, setFormData] = useState({
    title: '',
    topicId: '',
    intendedRole: 'coordinator',
    ownerId: '',
    stage: 'G0' as Gate,
    notes: '',
  });

  // The owner the form will actually submit. The member list is fetched after
  // mount, so `formData.ownerId` starts empty and cannot default to `members[0]`
  // the way the old fixed array did — this derives the fallback at render time
  // instead of writing it back into state from an effect (which would be a
  // cascading render, and is what `react-hooks/set-state-in-effect` forbids).
  const selectedOwnerId = formData.ownerId || members[0]?.id || '';

  // Toasts
  const [toast, setToast] = useState<{ id: number; text: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = nextToastId();
    setToast({ id, text, type });
    setTimeout(() => {
      setToast((prev) => (prev?.id === id ? null : prev));
    }, 4000);
  };

  // Drag & Drop
  const handleDragStart = (e: React.DragEvent, oppId: string) => {
    e.dataTransfer.setData('oppId', oppId);
  };

  const handleDrop = async (e: React.DragEvent, newStage: Gate) => {
    e.preventDefault();
    const oppId = e.dataTransfer.getData('oppId');
    if (!oppId) return;

    const opp = opps.find((o) => o.id === oppId);
    if (!opp || opp.stage === newStage) return;

    setOpps((prev) => prev.map((o) => (o.id === oppId ? { ...o, stage: newStage } : o)));

    startTransition(async () => {
      try {
        await moveOpportunityStage(oppId, newStage);
        showToast(`Fırsat ${newStage} aşamasına taşındı.`, 'info');
      } catch (err) {
        console.error(err);
        showToast(errorText(err, 'Aşama güncellenirken hata oluştu.'), 'error');
        setOpps(initialOpps);
      }
    });
  };

  const allowDrop = (e: React.DragEvent) => {
    e.preventDefault();
  };

  // Quick Change Owner / Assign Responsible User
  const handleAssignOwner = (oppId: string, memberId: string) => {
    const member = members.find((m) => m.id === memberId);
    const ownerName = member ? member.name : 'Atanmadı';

    setOpps((prev) =>
      prev.map((o) => (o.id === oppId ? { ...o, ownerId: memberId, ownerName } : o))
    );

    startTransition(async () => {
      try {
        await assignOpportunityOwner({ opportunityId: oppId, ownerId: memberId, ownerName });
        showToast(`Fırsat ${ownerName} kişisine atandı!`, 'success');
      } catch (err) {
        console.error(err);
        showToast(errorText(err, 'Atama sırasında hata oluştu.'), 'error');
      }
    });
  };

  // Add Note to Card
  const handleAddNote = (oppId: string) => {
    const cardInput = noteInputs[oppId];
    if (!cardInput || !cardInput.text.trim()) return;

    const author = members.find((m) => m.id === cardInput.authorId) || members[0];
    if (!author) {
      showToast('Kullanıcı listesi henüz yüklenmedi, lütfen tekrar deneyin.', 'error');
      return;
    }
    const text = cardInput.text.trim();

    startTransition(async () => {
      try {
        const res = await addOpportunityNote({
          opportunityId: oppId,
          text,
          authorName: author.name,
          authorAvatar: author.avatar,
        });

        if (res.success && res.note) {
          setOpps((prev) =>
            prev.map((o) => {
              if (o.id === oppId) {
                const existingNotes = o.notesList || [];
                return { ...o, notesList: [...existingNotes, res.note] };
              }
              return o;
            })
          );

          // Clear note input text for this card
          setNoteInputs((prev) => clearNoteText(prev, oppId, author.id));

          showToast(`${author.name} kullanıcısının notu eklendi!`, 'success');
        }
      } catch (err) {
        console.error(err);
        showToast(errorText(err, 'Not eklenirken hata oluştu.'), 'error');
      }
    });
  };

  // Form Submit: Create Opportunity
  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    const targetStage = formData.stage || modalStage || 'G0';
    const member = members.find((m) => m.id === selectedOwnerId);

    startTransition(async () => {
      try {
        const res = await createOpportunity({
          workspaceSlug: workspace,
          title: formData.title.trim(),
          topicId: formData.topicId.trim() || undefined,
          intendedRole: formData.intendedRole,
          ownerId: selectedOwnerId || undefined,
          ownerName: member?.name || undefined,
          stage: targetStage,
          notes: formData.notes.trim() || undefined,
        });

        if (res.success && res.opportunity) {
          setOpps((prev) => [res.opportunity, ...prev]);
          setExpandedCardIds((prev) => ({ ...prev, [res.opportunity.id]: true }));
          setIsModalOpen(false);
          setFormData({
            title: '',
            topicId: '',
            intendedRole: 'coordinator',
            ownerId: '',
            stage: 'G0',
            notes: '',
          });
          showToast(`"${res.opportunity.title}" fırsatı ${member?.name || ''} üzerine atanarak oluşturuldu!`, 'success');
        } else if (!res.success) {
          // e.g. WORKSPACE_NOT_FOUND (TASK-MUO12A7NHANOT): a refusal is a value, not a throw.
          showToast(t('createRefused'), 'error');
        }
      } catch (err) {
        showToast(errorText(err, () => errorMessage(err, 'Fırsat oluşturulurken hata meydana geldi.')), 'error');
      }
    });
  };

  // Filtered list
  const filteredOpps = useMemo(() => {
    return opps.filter((opp) => {
      if (opp.id === fullscreenOppId) return true;

      const matchesSearch =
        opp.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (opp.topicId && opp.topicId.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (opp.ownerName && opp.ownerName.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (opp.notesList && opp.notesList.some((n) => n.text.toLowerCase().includes(searchQuery.toLowerCase())));

      if (!matchesSearch) return false;

      if (roleFilter !== 'all') {
        const role = (opp.intendedRole || 'coordinator').toLowerCase();
        if (roleFilter === 'coordinator' && role !== 'coordinator') return false;
        if (roleFilter === 'partner' && role !== 'partner') return false;
      }

      if (ownerFilter !== 'all') {
        if (opp.ownerId !== ownerFilter) return false;
      }

      return true;
    });
  }, [opps, searchQuery, roleFilter, ownerFilter, fullscreenOppId]);

  const openCreateModalForStage = (gate: Gate) => {
    setModalStage(gate);
    setFormData((prev) => ({ ...prev, stage: gate }));
    setIsModalOpen(true);
  };

  const renderFullscreenModal = (fullscreenOpp: OpportunityItem) => {
    return (
      <div
        data-testid="pipeline-fullscreen-modal"
        className="fixed inset-0 z-50 flex flex-col w-screen h-screen bg-background/95 backdrop-blur-2xl text-ink overflow-hidden animate-in fade-in duration-150 cursor-default"
        onClick={(e) => e.stopPropagation()}
      >
        {/* ─── Top Bar ─── */}
        <header className="h-16 border-b border-border bg-surface/80 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between gap-4 shrink-0 shadow-xs">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                closeFullscreen();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-border bg-ground hover:bg-surface text-ink text-xs font-semibold transition cursor-pointer shadow-2xs"
              title={t('fullscreen.escToClose')}
            >
              <X className="w-4 h-4 text-muted" />
              <span className="hidden sm:inline">{t('fullscreen.close')}</span>
              <kbd className="text-[10px] text-muted font-mono bg-border/40 px-1.5 py-0.5 rounded">
                ESC
              </kbd>
            </button>

            <div className="h-6 w-px bg-border hidden sm:block" />

            <div className="flex items-center gap-2 min-w-0">
              <span
                className={`text-xs font-bold px-2.5 py-0.5 rounded-lg flex items-center gap-1 shrink-0 ${
                  (fullscreenOpp.intendedRole || 'coordinator').toLowerCase() === 'coordinator'
                    ? 'bg-purple-500/15 text-purple-400 border border-purple-500/20'
                    : 'bg-accent/15 text-accent-ink border border-accent/20'
                }`}
              >
                <span>
                  {(fullscreenOpp.intendedRole || 'coordinator').toLowerCase() === 'coordinator'
                    ? '👑'
                    : '🤝'}
                </span>
                <span>
                  {(fullscreenOpp.intendedRole || 'coordinator').toLowerCase() === 'coordinator'
                    ? t('fullscreen.coordinator')
                    : t('fullscreen.partner')}
                </span>
              </span>

              <span className="text-xs font-mono font-bold bg-ground border border-border px-2 py-0.5 rounded-md text-ink-2 shrink-0">
                {fullscreenOpp.stage}
              </span>

              {fullscreenOpp.g0Score !== null && fullscreenOpp.g0Score !== undefined && (
                <span
                  className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full shrink-0 ${
                    fullscreenOpp.g0Score >= 80
                      ? 'bg-ok/15 text-ok border border-ok/30'
                      : 'bg-amber/15 text-amber border border-amber/30'
                  }`}
                >
                  ⭐ {fullscreenOpp.g0Score} / 100
                </span>
              )}

              <div
                className="text-sm sm:text-base font-bold font-heading text-ink truncate max-w-xs sm:max-w-md md:max-w-lg lg:max-w-xl"
                title={fullscreenOpp.title}
              >
                {fullscreenOpp.title}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <Link
              href={`/${locale}/${workspace}/pipeline/${fullscreenOpp.id}/consortium`}
              onClick={(e) => e.stopPropagation()}
              className="hidden md:flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl bg-ground border border-border hover:bg-surface text-ink transition shadow-2xs"
              title={t('fullscreen.consortium')}
            >
              <Users className="w-3.5 h-3.5 text-accent-ink" />
              <span>{t('fullscreen.consortium')}</span>
              <ArrowRight className="w-3 h-3 text-muted" />
            </Link>

            <Link
              href={`/${locale}/${workspace}/pipeline/${fullscreenOpp.id}`}
              onClick={(e) => e.stopPropagation()}
              className="flex items-center gap-1.5 text-xs font-semibold px-3.5 py-1.5 rounded-xl bg-accent hover:opacity-90 text-white transition shadow-2xs"
            >
              <span className="hidden sm:inline">{t('fullscreen.openDetail')}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </Link>
          </div>
        </header>

        {/* ─── Stage Stepper Progression Bar ─── */}
        <div className="border-b border-border bg-surface/50 px-4 sm:px-6 py-2.5 shrink-0 overflow-x-auto">
          <div className="flex items-center justify-between gap-2 min-w-[700px] max-w-6xl mx-auto">
            {GATES.map(({ key, subtitle, color }, index) => {
              const isCurrent = fullscreenOpp.stage === key;
              const gateOrder: Gate[] = ['G0', 'G1', 'G2', 'G3', 'G4'];
              const currentIndex = gateOrder.indexOf(fullscreenOpp.stage);
              const isPassed = index < currentIndex;

              return (
                <button
                  key={key}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleMoveStageFromModal(fullscreenOpp.id, key);
                  }}
                  className={`flex-1 flex items-center gap-2.5 p-2 rounded-xl border text-left transition-all cursor-pointer ${
                    isCurrent
                      ? `bg-surface border-accent shadow-xs ring-2 ring-accent/20 ${color}`
                      : isPassed
                      ? 'bg-ground/60 border-ok/30 text-ink hover:bg-surface'
                      : 'bg-ground/30 border-border text-muted hover:bg-surface/50 hover:text-ink'
                  }`}
                  title={`${key}: ${t('fullscreen.moveHere')}`}
                >
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-mono font-bold text-xs shrink-0 ${
                      isCurrent
                        ? 'bg-accent text-white shadow-xs'
                        : isPassed
                        ? 'bg-ok/20 text-ok border border-ok/40'
                        : 'bg-ground border border-border text-muted'
                    }`}
                  >
                    {isPassed ? '✓' : key}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-ink uppercase tracking-wider">
                        {key}
                      </span>
                      {isCurrent && (
                        <span className="text-[9px] font-bold bg-accent/15 text-accent-ink px-1.5 py-0.2 rounded">
                          {t('fullscreen.currentStage')}
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-muted truncate">{subtitle}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* ─── Scrollable Workspace Body ─── */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Main Column (8 Cols) */}
            <div className="lg:col-span-8 space-y-6">
              {/* 1. Opportunity & Call Header Card */}
              <div className="bg-surface border border-border rounded-2xl p-6 shadow-xs space-y-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1.5 flex-1">
                    <div className="text-xs font-bold text-muted uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-accent-ink" />
                      <span>{t('fullscreen.overview')}</span>
                    </div>
                    <div className="text-xl sm:text-2xl font-bold font-heading text-ink leading-tight">
                      {fullscreenOpp.title}
                    </div>
                  </div>
                </div>

                {/* Topic Call Box */}
                {fullscreenOpp.topicId ? (
                  <div className="bg-ground/80 border border-border rounded-xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div className="space-y-0.5 min-w-0">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-muted">
                        {t('fullscreen.topic')}
                      </div>
                      <div className="font-mono text-xs font-bold text-accent-ink flex items-center gap-2">
                        <span>{fullscreenOpp.topicId}</span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleCopyTopic(fullscreenOpp.topicId || '');
                          }}
                          className="text-muted hover:text-ink text-[11px] p-0.5 rounded transition cursor-pointer"
                          title={t('fullscreen.copyTooltip')}
                        >
                          {copiedTopic ? (
                            <Check className="w-3.5 h-3.5 text-ok" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                      {(() => {
                        const matched = suggestedTopics.find(
                          (st) => st.identifier === fullscreenOpp.topicId
                        );
                        return matched ? (
                          <div className="text-xs text-ink-2 font-medium line-clamp-1">
                            {matched.title}
                          </div>
                        ) : null;
                      })()}
                    </div>

                    <span className="text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2.5 py-1 rounded-lg shrink-0">
                      {t('fullscreen.callTypeHorizon')}
                    </span>
                  </div>
                ) : (
                  <div className="text-xs text-muted italic bg-ground/50 border border-dashed border-border rounded-xl p-3">
                    {t('fullscreen.topicNotAssigned')}
                  </div>
                )}
              </div>

              {/* 2. AI Gate G0 Triage Assessment Card */}
              <div className="bg-surface border border-border rounded-2xl p-6 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-accent-ink" />
                    <h3 className="text-sm font-bold font-heading text-ink">
                      {t('fullscreen.aiScore')}
                    </h3>
                  </div>
                  <span className="text-xs font-medium text-muted">
                    {t('fullscreen.thresholdLabel')}
                  </span>
                </div>

                <div className="bg-ground/70 border border-border rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div
                      className={`w-16 h-16 rounded-2xl flex flex-col items-center justify-center font-mono font-bold text-xl shadow-xs border ${
                        fullscreenOpp.g0Score !== null && fullscreenOpp.g0Score !== undefined
                          ? fullscreenOpp.g0Score >= 80
                            ? 'bg-ok/15 text-ok border-ok/30'
                            : 'bg-amber/15 text-amber border-amber/30'
                          : 'bg-surface text-muted border-border'
                      }`}
                    >
                      <span>
                        {fullscreenOpp.g0Score !== null && fullscreenOpp.g0Score !== undefined
                          ? fullscreenOpp.g0Score
                          : '—'}
                      </span>
                      <span className="text-[9px] font-normal text-muted">/100</span>
                    </div>

                    <div className="space-y-1">
                      <div className="text-sm font-bold text-ink">
                        {fullscreenOpp.g0Score !== null && fullscreenOpp.g0Score !== undefined
                          ? fullscreenOpp.g0Score >= 80
                            ? t('fullscreen.scoreHigh')
                            : t('fullscreen.scoreLow')
                          : t('fullscreen.scorePending')}
                      </div>
                      <p className="text-xs text-muted leading-relaxed">
                        {fullscreenOpp.g0Score !== null && fullscreenOpp.g0Score !== undefined
                          ? fullscreenOpp.g0Score >= 80
                            ? t('fullscreen.scoreHighDesc')
                            : t('fullscreen.scoreLowDesc')
                            : t('fullscreen.scorePendingDesc')}
                      </p>
                    </div>
                  </div>

                  <Link
                    href={`/${locale}/${workspace}/pipeline/${fullscreenOpp.id}`}
                    onClick={(e) => e.stopPropagation()}
                    className="text-xs font-semibold px-3 py-2 rounded-xl bg-surface border border-border hover:border-accent text-ink transition shrink-0 flex items-center gap-1.5"
                  >
                    <span>{t('fullscreen.analysisDetails')}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </Link>
                </div>

                {/* 4 Pillars Breakdown */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                  <div className="bg-ground border border-border rounded-xl p-3 text-center space-y-1">
                    <div className="text-[10px] font-bold text-muted uppercase">
                      {t('fullscreen.pillarFocus')}
                    </div>
                    <div className="text-xs font-bold text-ink">
                      {t('fullscreen.pillarFocusSub')}
                    </div>
                  </div>
                  <div className="bg-ground border border-border rounded-xl p-3 text-center space-y-1">
                    <div className="text-[10px] font-bold text-muted uppercase">
                      {t('fullscreen.pillarConsortium')}
                    </div>
                    <div className="text-xs font-bold text-ink">
                      {t('fullscreen.pillarConsortiumSub')}
                    </div>
                  </div>
                  <div className="bg-ground border border-border rounded-xl p-3 text-center space-y-1">
                    <div className="text-[10px] font-bold text-muted uppercase">
                      {t('fullscreen.pillarBudget')}
                    </div>
                    <div className="text-xs font-bold text-ink">
                      {t('fullscreen.pillarBudgetSub')}
                    </div>
                  </div>
                  <div className="bg-ground border border-border rounded-xl p-3 text-center space-y-1">
                    <div className="text-[10px] font-bold text-muted uppercase">
                      {t('fullscreen.pillarImpact')}
                    </div>
                    <div className="text-xs font-bold text-ink">
                      {t('fullscreen.pillarImpactSub')}
                    </div>
                  </div>
                </div>
              </div>

              {/* 3. Notes & Activity Feed Card */}
              <div className="bg-surface border border-border rounded-2xl p-6 shadow-xs space-y-5">
                <div className="flex items-center justify-between border-b border-border pb-3">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-accent-ink" />
                    <h3 className="text-sm font-bold font-heading text-ink">
                      {t('fullscreen.notesHeading')}
                    </h3>
                  </div>
                  <span className="text-xs font-semibold bg-ground text-ink-2 border border-border px-2.5 py-0.5 rounded-full">
                    {t('fullscreen.notesCount', { count: (fullscreenOpp.notesList || []).length })}
                  </span>
                </div>

                {/* Existing Notes Feed */}
                <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                  {(fullscreenOpp.notesList || []).length > 0 ? (
                    (fullscreenOpp.notesList || []).map((note) => (
                      <div
                        key={note.id}
                        data-testid={`pipeline-note-item-${fullscreenOpp.id}`}
                        className="bg-ground/70 border border-border rounded-xl p-3.5 space-y-1.5"
                      >
                        <div className="flex items-center justify-between text-xs text-muted">
                          <div className="flex items-center gap-2 font-bold text-ink">
                            <span className="text-base">{note.authorAvatar || '👤'}</span>
                            <span>{note.authorName}</span>
                          </div>
                          <span className="text-[10px] font-mono">{note.createdAt}</span>
                        </div>
                        <p className="text-xs sm:text-sm text-ink-2 leading-relaxed whitespace-pre-wrap pl-7">
                          {note.text}
                        </p>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-6 text-xs text-muted italic bg-ground/40 border border-dashed border-border rounded-xl">
                      {t('fullscreen.noNotes')}
                    </div>
                  )}
                </div>

                {/* Add Note Section */}
                <div className="bg-ground border border-border rounded-xl p-4 space-y-3 pt-3">
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-semibold text-muted">
                      {t('fullscreen.noteAuthor')}:
                    </span>
                    <select
                      data-testid={`pipeline-note-author-${fullscreenOpp.id}`}
                      value={fullscreenNoteAuthorId || members[0]?.id || ''}
                      onChange={(e) => setFullscreenNoteAuthorId(e.target.value)}
                      className="bg-surface border border-border rounded-lg px-2.5 py-1 text-xs font-bold text-ink focus:outline-none"
                    >
                      {members.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <textarea
                    data-testid={`pipeline-note-text-${fullscreenOpp.id}`}
                    rows={3}
                    placeholder={t('fullscreen.notePlaceholder')}
                    value={fullscreenNoteText}
                    onChange={(e) => setFullscreenNoteText(e.target.value)}
                    className="w-full text-xs sm:text-sm bg-surface border border-border rounded-xl p-3 text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent resize-none"
                  />

                  <div className="flex justify-end">
                    <button
                      type="button"
                      data-testid={`pipeline-note-add-${fullscreenOpp.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAddFullscreenNote(fullscreenOpp.id);
                      }}
                      disabled={!fullscreenNoteText.trim() || isPending}
                      className="bg-accent hover:opacity-90 disabled:opacity-40 text-white font-bold text-xs px-4 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{t('fullscreen.addNote')}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Sidebar Column (4 Cols) */}
            <div className="lg:col-span-4 space-y-6">
              {/* 1. Ownership & Responsible User Card */}
              <div className="bg-surface border border-border rounded-2xl p-6 shadow-xs space-y-4">
                <div className="text-xs font-bold text-muted uppercase tracking-wider flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-accent-ink" />
                  <span>{t('fullscreen.assignedTo')}</span>
                </div>

                {(() => {
                  const assigned = members.find((m) => m.id === fullscreenOpp.ownerId) || {
                    name: fullscreenOpp.ownerName || t('fullscreen.unassigned'),
                    avatar: '👤',
                  };

                  return (
                    <div className="bg-ground/70 border border-border rounded-xl p-3.5 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-surface border border-border flex items-center justify-center text-xl shrink-0">
                        {assigned.avatar}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="text-xs text-muted font-medium">
                          {t('fullscreen.assignedMember')}
                        </div>
                        <div className="text-sm font-bold text-ink truncate">
                          {assigned.name}
                        </div>
                      </div>
                    </div>
                  );
                })()}

                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-muted block">
                    {t('fullscreen.changeOwner')}
                  </label>
                  <select
                    value={fullscreenOpp.ownerId || ''}
                    onChange={(e) => handleAssignOwner(fullscreenOpp.id, e.target.value)}
                    title="Sorumlu kullanıcıyı değiştir"
                    className="w-full bg-ground border border-border rounded-xl px-3 py-2 text-xs font-bold text-ink focus:outline-none focus:ring-2 focus:ring-accent cursor-pointer"
                  >
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* 2. Consortium Desk Card */}
              <div className="bg-surface border border-border rounded-2xl p-6 shadow-xs space-y-3">
                <div className="text-xs font-bold text-muted uppercase tracking-wider flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-accent-ink" />
                  <span>{t('fullscreen.consortium')}</span>
                </div>

                <p className="text-xs text-muted leading-relaxed">
                  {t('fullscreen.consortiumDesc')}
                </p>

                <Link
                  href={`/${locale}/${workspace}/pipeline/${fullscreenOpp.id}/consortium`}
                  onClick={(e) => e.stopPropagation()}
                  className="w-full py-2.5 px-4 rounded-xl bg-ground border border-border hover:bg-surface text-ink text-xs font-bold transition flex items-center justify-center gap-2 shadow-2xs"
                >
                  <span>{t('fullscreen.goToConsortium')}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-muted" />
                </Link>
              </div>

              {/* 3. Stage Details & Timestamps Card */}
              <div className="bg-surface border border-border rounded-2xl p-6 shadow-xs space-y-3 text-xs">
                <div className="text-xs font-bold text-muted uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-accent-ink" />
                  <span>{t('fullscreen.timelineAndStatus')}</span>
                </div>

                <div className="space-y-2 pt-1">
                  <div className="flex items-center justify-between text-muted">
                    <span>{t('fullscreen.stage')}:</span>
                    <span className="font-bold text-ink">{fullscreenOpp.stage}</span>
                  </div>
                  <div className="flex items-center justify-between text-muted">
                    <span>{t('fullscreen.statusLabel')}</span>
                    <span className="font-semibold text-ink">
                      {fullscreenOpp.status || t('fullscreen.activeStatus')}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-muted">
                    <span>{t('fullscreen.lastUpdateLabel')}</span>
                    <span className="font-mono text-[11px] text-ink">
                      {new Date(fullscreenOpp.updatedAt).toLocaleDateString(locale === 'tr' ? 'tr-TR' : 'en-US')}
                    </span>
                  </div>
                </div>

                <div className="pt-2">
                  <Link
                    href={`/${locale}/${workspace}/pipeline/${fullscreenOpp.id}`}
                    onClick={(e) => e.stopPropagation()}
                    className="w-full py-2.5 px-4 rounded-xl bg-accent hover:opacity-90 text-white text-xs font-bold transition flex items-center justify-center gap-2 shadow-2xs"
                  >
                    <span>{t('fullscreen.openDetail')}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6" data-testid="pipeline-board">
      {/* Toast */}
      {toast && (
        <div className="fixed top-5 right-5 z-50 animate-in slide-in-from-top-2">
          <div
            className={`px-4 py-3 rounded-xl shadow-lg border text-sm font-semibold flex items-center gap-2 ${
              toast.type === 'success'
                ? 'bg-ok/15 text-ok border-ok/30'
                : toast.type === 'error'
                ? 'bg-bad/15 text-bad border-bad/30'
                : 'bg-surface text-ink border-border shadow-xl'
            }`}
          >
            <span>{toast.type === 'success' ? '✓' : toast.type === 'error' ? '✕' : 'ℹ'}</span>
            <span>{toast.text}</span>
          </div>
        </div>
      )}

      {/* Top Header & Action Bar */}
      <div className="bg-surface border border-border rounded-2xl p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium text-muted mb-1">
            <Link href={`/${locale}/${workspace}/dashboard`} className="hover:text-ink transition-colors">
              {t('breadcrumb.dashboard')}
            </Link>
            <span>/</span>
            <span className="text-accent-ink font-semibold">{t('breadcrumb.current')}</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold font-heading text-ink">{t('heading')}</h1>
          <p className="text-xs md:text-sm text-muted mt-0.5">{t('subtitle')}</p>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end flex-wrap">
          {/* Expand / Collapse All Toggle */}
          <button
            onClick={toggleAllExpand}
            className="text-xs bg-ground border border-border hover:bg-surface text-ink-2 font-medium px-3 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
            title="Tüm kartları genişlet veya küçült"
          >
            <span>{allExpanded ? '▲ Tümünü Küçült' : '▼ Tümünü Genişlet'}</span>
          </button>

          {/* Search Input */}
          <div className="relative w-44 sm:w-56">
            <input
              type="text"
              placeholder="Fırsat, not veya kişi ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs bg-ground border border-border rounded-xl px-3 py-2.5 pl-8 text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent"
            />
            <span className="absolute left-2.5 top-2.5 text-muted text-xs">🔍</span>
          </div>

          {/* User Filter */}
          <select
            value={ownerFilter}
            onChange={(e) => setOwnerFilter(e.target.value)}
            className="text-xs bg-ground border border-border rounded-xl px-3 py-2.5 font-medium text-ink focus:outline-none focus:ring-2 focus:ring-accent"
          >
            <option value="all">👥 Tüm Kullanıcılar</option>
            {members.map((m) => (
              <option key={m.id} value={m.id}>
                {m.avatar} {m.name}
              </option>
            ))}
          </select>

          {/* Role Filter */}
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value as RoleFilter)}
            className="text-xs bg-ground border border-border rounded-xl px-3 py-2.5 font-medium text-ink focus:outline-none focus:ring-2 focus:ring-accent"
          >
            <option value="all">Tüm Roller</option>
            <option value="coordinator">👑 Koordinatör</option>
            <option value="partner">🤝 Ortak</option>
          </select>

          {/* + New Opportunity Main Trigger Button */}
          <button
            onClick={() => openCreateModalForStage('G0')}
            className="bg-accent hover:opacity-90 text-white font-semibold text-xs md:text-sm px-4 py-2.5 rounded-xl shadow-2xs transition-all flex items-center gap-2 shrink-0 cursor-pointer"
          >
            <span className="text-base leading-none font-bold">+</span>
            <span>Yeni Fırsat Ekle</span>
          </button>
        </div>
      </div>

      {/* Kanban Board Column Container */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 overflow-x-auto pb-6 min-h-[calc(100vh-280px)]">
        {GATES.map(({ key, subtitle, color }) => {
          const stageOpps = filteredOpps.filter((o) => o.stage === key);

          return (
            <div
              key={key}
              className={`bg-ground/50 border border-border rounded-2xl flex flex-col border-t-4 ${color} transition-all shadow-2xs`}
              onDragOver={allowDrop}
              onDrop={(e) => handleDrop(e, key)}
            >
              {/* Column Header */}
              <div className="p-4 border-b border-border bg-surface/80 rounded-t-xl flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-xs text-ink uppercase tracking-wider">{key}</h3>
                    <span className="bg-ground text-ink-2 border border-border font-mono text-[11px] font-bold px-2 py-0.5 rounded-full">
                      {stageOpps.length}
                    </span>
                  </div>
                  <div className="text-[11px] text-muted font-medium mt-0.5">{subtitle}</div>
                </div>

                {/* Quick Add Button per Column */}
                <button
                  onClick={() => openCreateModalForStage(key)}
                  title={`${key} aşamasına yeni fırsat ekle`}
                  className="w-6 h-6 rounded-lg bg-ground hover:bg-accent/15 text-muted hover:text-accent-ink border border-border flex items-center justify-center font-bold text-sm transition"
                >
                  +
                </button>
              </div>

              {/* Column Cards Drop Area */}
              <div className="p-3 flex-1 overflow-y-auto space-y-3 min-h-[160px]">
                {stageOpps.map((opp) => {
                  const isCoord = (opp.intendedRole || 'coordinator').toLowerCase() === 'coordinator';
                  const currentMember = members.find((m) => m.id === opp.ownerId) || {
                    name: opp.ownerName || 'Atanmadı',
                    avatar: '👤',
                  };
                  const isExpanded = !!expandedCardIds[opp.id];

                  const notesList: NoteEntry[] = opp.notesList || [];
                  const cardNoteInput = noteInputs[opp.id] || { text: '', authorId: members[0]?.id ?? '' };

                  return (
                    <div
                      key={opp.id}
                      data-testid={`pipeline-card-${opp.id}`}
                      draggable
                      onDragStart={(e) => {
                        setIsDragging(true);
                        handleDragStart(e, opp.id);
                      }}
                      onDragEnd={() => {
                        setTimeout(() => setIsDragging(false), 80);
                      }}
                      onClick={() => {
                        if (!isDragging) {
                          openFullscreen(opp);
                        }
                      }}
                      className={`bg-surface rounded-xl shadow-2xs border border-border cursor-pointer active:cursor-grabbing hover:border-accent hover:shadow-md transition-all ${
                        isPending ? 'opacity-60' : ''
                      } ${isExpanded ? 'p-4 space-y-3' : 'p-3 space-y-2'}`}
                    >
                      {/* Top Bar / Header of Card (Always Visible & Clickable to Toggle Expand) */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 flex-wrap min-w-0">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 shrink-0 ${
                              isCoord
                                ? 'bg-purple-500/15 text-purple-400 border border-purple-500/20'
                                : 'bg-accent/15 text-accent-ink border border-accent/20'
                            }`}
                          >
                            <span>{isCoord ? '👑' : '🤝'}</span>
                            <span>{isCoord ? 'Koordinatör' : 'Ortak'}</span>
                          </span>

                          {/* Minimized User Badge */}
                          {!isExpanded && (
                            <span
                              className="text-[10px] font-semibold bg-ground border border-border text-ink-2 px-1.5 py-0.5 rounded flex items-center gap-1 truncate max-w-[90px]"
                              title={`Atanan: ${currentMember.name}`}
                            >
                              <span>{currentMember.avatar}</span>
                              <span className="truncate">{currentMember.name.split(' ')[0]}</span>
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          {/* Notes Count Badge */}
                          {notesList.length > 0 && (
                            <span
                              className="text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200 px-1.5 py-0.5 rounded-full flex items-center gap-0.5"
                              title={`${notesList.length} Not Var`}
                            >
                              <span>💬</span>
                              <span>{notesList.length}</span>
                            </span>
                          )}

                          {opp.g0Score !== null && opp.g0Score !== undefined && (
                            <span
                              data-testid={`pipeline-card-g0-${opp.id}`}
                              className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-full ${
                                opp.g0Score >= 80
                                  ? 'bg-ok/15 text-ok border border-ok/30'
                                  : 'bg-amber/15 text-amber border border-amber/30'
                              }`}
                              title="AI Gate Uyum Skoru"
                            >
                              ⭐ {opp.g0Score}
                            </span>
                          )}

                          {/* Dedicated Fullscreen Button */}
                          <button
                            type="button"
                            data-testid={`pipeline-card-fullscreen-${opp.id}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              openFullscreen(opp);
                            }}
                            className="text-[10px] bg-ground hover:bg-accent hover:text-white text-muted border border-border px-1.5 py-0.5 rounded font-bold transition cursor-pointer flex items-center gap-0.5"
                            title={t('fullscreen.open')}
                          >
                            <Maximize2 className="w-2.5 h-2.5" />
                          </button>

                          {/* Toggle Expand Arrow Button */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleExpand(opp.id);
                            }}
                            className="text-[10px] bg-ground hover:bg-accent/15 text-muted hover:text-accent-ink border border-border px-1.5 py-0.5 rounded font-bold transition cursor-pointer"
                            title={isExpanded ? 'Kartı Küçült' : 'Detaylar İçin Genişlet'}
                          >
                            {isExpanded ? '▲' : '▼'}
                          </button>
                        </div>
                      </div>

                      {/* Title (Clicking opens full-window modal workspace) */}
                      <h4
                        onClick={(e) => {
                          e.stopPropagation();
                          openFullscreen(opp);
                        }}
                        className="font-bold text-xs text-ink leading-snug cursor-pointer hover:text-accent transition-colors"
                        title={opp.title}
                      >
                        {opp.title}
                      </h4>

                      {/* ─── EXPANDED DETAILS CONTENT (Only when expanded AND not in fullscreen modal) ─── */}
                      {isExpanded && fullscreenOppId !== opp.id && (
                        <div className="space-y-3 pt-2 border-t border-border/60 animate-in fade-in duration-150">
                          {/* Topic Identifier */}
                          {opp.topicId && (
                            <div className="text-[10px] bg-ground border border-border text-muted px-2 py-1 rounded font-mono truncate max-w-full">
                              {opp.topicId}
                            </div>
                          )}

                          {/* Full Assigned User Dropdown Pill */}
                          <div className="flex items-center justify-between bg-ground/80 border border-border rounded-lg px-2.5 py-1 text-[11px] min-w-0 overflow-hidden">
                            <span className="text-muted text-[10px] font-semibold shrink-0">Atanan:</span>
                            <div className="flex items-center gap-1 min-w-0 overflow-hidden max-w-[170px]">
                              <span className="text-xs shrink-0">{currentMember.avatar}</span>
                              <select
                                value={opp.ownerId || ''}
                                onChange={(e) => handleAssignOwner(opp.id, e.target.value)}
                                className="bg-transparent font-bold text-ink text-[11px] focus:outline-none cursor-pointer hover:text-blue-600 truncate max-w-full"
                                title="Sorumlu kullanıcıyı değiştir"
                              >
                                {members.map((m) => (
                                  <option key={m.id} value={m.id}>
                                    {m.name}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>

                          {/* ─── USER-ATTRIBUTED NOTES LIST ─── */}
                          <div className="space-y-2 pt-1 border-t border-border/40">
                            <div className="flex items-center justify-between text-[11px] font-bold text-ink">
                              <span>💬 Notlar & Güncellemeler</span>
                              <span className="text-[10px] text-muted font-normal">
                                ({notesList.length} Not)
                              </span>
                            </div>

                            {notesList.length > 0 ? (
                              <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                                {notesList.map((note) => (
                                  <div
                                    key={note.id}
                                    data-testid={`pipeline-note-item-${opp.id}`}
                                    className="bg-ground/70 border border-border rounded-lg p-2 text-[11px] space-y-1"
                                  >
                                    <div className="flex items-center justify-between text-[10px] text-muted font-medium">
                                      <span className="font-bold text-ink flex items-center gap-1">
                                        <span>{note.authorAvatar || '👤'}</span>
                                        <span>{note.authorName}</span>
                                      </span>
                                      <span className="font-mono text-[9px]">{note.createdAt}</span>
                                    </div>
                                    <p className="text-ink-2 leading-tight">{note.text}</p>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-[10px] text-muted italic">
                                Henüz not eklenmedi.
                              </p>
                            )}

                            {/* Add New Note Inline Input */}
                            <div className="bg-ground border border-border rounded-xl p-2 space-y-2">
                              <div className="flex items-center justify-between gap-1 text-[10px]">
                                <span className="text-muted font-semibold">Not Yazan:</span>
                                <select
                                  data-testid={`pipeline-note-author-${opp.id}`}
                                  value={cardNoteInput.authorId}
                                  onChange={(e) =>
                                    setNoteInputs((prev) => ({
                                      ...prev,
                                      [opp.id]: {
                                        ...cardNoteInput,
                                        authorId: e.target.value,
                                      },
                                    }))
                                  }
                                  className="bg-surface border border-border rounded px-1.5 py-0.5 text-ink font-bold focus:outline-none"
                                >
                                  {members.map((m) => (
                                    <option key={m.id} value={m.id}>
                                      {m.avatar} {m.name}
                                    </option>
                                  ))}
                                </select>
                              </div>

                              <div className="flex items-center gap-1.5">
                                <input
                                  data-testid={`pipeline-note-text-${opp.id}`}
                                  type="text"
                                  placeholder="Not veya güncelleme yazın..."
                                  value={cardNoteInput.text}
                                  onChange={(e) =>
                                    setNoteInputs((prev) => ({
                                      ...prev,
                                      [opp.id]: {
                                        ...cardNoteInput,
                                        text: e.target.value,
                                      },
                                    }))
                                  }
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      handleAddNote(opp.id);
                                    }
                                  }}
                                  className="w-full text-[11px] bg-surface border border-border rounded-lg px-2.5 py-1.5 text-ink placeholder:text-muted focus:outline-none focus:ring-1 focus:ring-accent"
                                />
                                <button
                                  data-testid={`pipeline-note-add-${opp.id}`}
                                  type="button"
                                  onClick={() => handleAddNote(opp.id)}
                                  disabled={!cardNoteInput.text.trim()}
                                  className="bg-accent hover:opacity-90 disabled:opacity-40 text-white font-bold text-[10px] px-2.5 py-1.5 rounded-lg transition shrink-0 cursor-pointer"
                                >
                                  Ekle
                                </button>
                              </div>
                            </div>
                          </div>

                          {/* Card Bottom: Action Links */}
                          <div className="pt-2 border-t border-border flex items-center justify-between text-[11px]">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                openFullscreen(opp);
                              }}
                              className="text-accent hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                            >
                              <Maximize2 className="w-3 h-3" />
                              <span>{t('fullscreen.open')}</span>
                            </button>

                            <Link
                              href={`/${locale}/${workspace}/pipeline/${opp.id}`}
                              onClick={(e) => e.stopPropagation()}
                              className="text-muted hover:text-ink font-medium flex items-center gap-1"
                            >
                              <span>İncele</span>
                              <span>→</span>
                            </Link>

                            <Link
                              href={`/${locale}/${workspace}/pipeline/${opp.id}/consortium`}
                              onClick={(e) => e.stopPropagation()}
                              className="text-muted hover:text-ink font-medium flex items-center gap-1"
                              title="Konsorsiyum Masası"
                            >
                              <span>👥</span>
                              <span>Konsorsiyum</span>
                            </Link>
                          </div>
                        </div>
                      )}
                      {/* ─── FULLSCREEN MODAL (Rendered inside the card so card-scoped selectors & E2E tests locate it) ─── */}
                      {fullscreenOppId === opp.id && renderFullscreenModal(opp)}
                    </div>
                  );
                })}

                {stageOpps.length === 0 && (
                  <div
                    onClick={() => openCreateModalForStage(key)}
                    className="h-28 text-center text-xs text-muted flex flex-col items-center justify-center border-2 border-dashed border-border rounded-xl hover:border-accent hover:bg-surface/50 cursor-pointer transition"
                  >
                    <span className="text-base mb-1">+</span>
                    <span>Buraya sürükleyin veya ekleyin</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* ─── NEW OPPORTUNITY MODAL ─── */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-surface rounded-2xl max-w-lg w-full p-6 md:p-8 shadow-2xl space-y-6 border border-border">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-border pb-4">
              <div>
                <div className="text-xs font-bold text-accent uppercase tracking-wider mb-1">
                  Stage-Gate Yönetimi
                </div>
                <h2 className="text-xl font-bold font-heading text-ink">
                  Yeni Fonlama Fırsatı / Teklif Ekle
                </h2>
                <p className="text-xs text-muted mt-0.5">
                  Fırsatı boru hattına ekleyin, çalışma grubunuzdan bir kullanıcıya atayın ve G0 Triage sürecini başlatın.
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-muted hover:text-ink text-lg font-bold p-1 transition-colors"
              >
                ✕
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleCreateSubmit} className="space-y-4">
              {/* Title */}
              <div>
                <label className="block text-xs font-bold text-ink mb-1">
                  Proje / Teklif Başlığı <span className="text-bad">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Örn: AI-Optimized Battery Systems for Heavy Transport"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full text-xs bg-ground border border-border rounded-xl p-3 text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent"
                />
              </div>

              {/* Assigned Responsible User */}
              <div>
                <label className="block text-xs font-bold text-ink mb-1">
                  Sorumlu Kullanıcı / Atanan Kişi <span className="text-accent">*</span>
                </label>
                <select
                  value={selectedOwnerId}
                  onChange={(e) => setFormData({ ...formData, ownerId: e.target.value })}
                  className="w-full text-xs bg-ground border border-border rounded-xl p-3 text-ink font-semibold focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  {members.length === 0 && <option value="">Yükleniyor…</option>}
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.avatar} {m.name} — ({m.role})
                    </option>
                  ))}
                </select>
              </div>

              {/* Topic ID */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-ink">
                    Hedef Çağrı / Topic Kodu
                  </label>
                  <span className="text-[10px] text-muted">Opsiyonel</span>
                </div>
                <input
                  type="text"
                  placeholder="Örn: HORIZON-CL5-2026-D3-01-01"
                  value={formData.topicId}
                  onChange={(e) => setFormData({ ...formData, topicId: e.target.value })}
                  className="w-full text-xs bg-ground border border-border rounded-xl p-3 font-mono text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent"
                />

                {/* Quick Topic Chips — sourced live from `Topic` (open calls first); the
                    block renders nothing when there is nothing real to suggest. */}
                {suggestedTopics.length > 0 && (
                  <div className="mt-2 flex items-center gap-1.5 flex-wrap">
                    <span className="text-[10px] text-muted">Önerilenler:</span>
                    {suggestedTopics.map((t) => (
                      <button
                        key={t.identifier}
                        type="button"
                        onClick={() => setFormData({ ...formData, topicId: t.identifier })}
                        title={t.title}
                        className="text-[10px] bg-ground hover:bg-accent/15 hover:text-accent-ink text-ink-2 px-2 py-0.5 rounded border border-border transition"
                      >
                        {t.identifier}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Role & Stage selection grid */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-ink mb-1">
                    Hedeflenen Rol
                  </label>
                  <select
                    value={formData.intendedRole}
                    onChange={(e) => setFormData({ ...formData, intendedRole: e.target.value })}
                    className="w-full text-xs bg-ground border border-border rounded-xl p-3 text-ink focus:outline-none focus:ring-2 focus:ring-accent"
                  >
                    <option value="coordinator">👑 Koordinatör (Lead)</option>
                    <option value="partner">🤝 Konsorsiyum Ortağı</option>
                    <option value="tech_provider">🔬 Teknoloji Sağlayıcı</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-ink mb-1">
                    Başlangıç Kapısı
                  </label>
                  <select
                    value={formData.stage}
                    onChange={(e) => setFormData({ ...formData, stage: e.target.value as Gate })}
                    className="w-full text-xs bg-ground border border-border rounded-xl p-3 text-ink focus:outline-none focus:ring-2 focus:ring-accent font-mono"
                  >
                    <option value="G0">G0: Triage & Fizibilite</option>
                    <option value="G1">G1: Konsept & Mimari</option>
                    <option value="G2">G2: Konsorsiyum</option>
                    <option value="G3">G3: Tam Başvuru</option>
                    <option value="G4">G4: Nihai Teslim</option>
                  </select>
                </div>
              </div>

              {/* Initial Note */}
              <div>
                <label className="block text-xs font-bold text-ink mb-1">
                  İlk Not / Stratejiniz
                </label>
                <textarea
                  rows={2}
                  placeholder="Projenin temel amacı, hedef TRL aralığı veya ortak profili..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full text-xs bg-ground border border-border rounded-xl p-3 text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent"
                />
              </div>

              {/* Modal Footer Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-border">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 text-xs font-semibold border border-border rounded-xl hover:bg-surface-hover text-ink-2 transition"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  disabled={isPending || !formData.title.trim()}
                  className="px-5 py-2.5 text-xs font-bold bg-accent hover:opacity-90 text-white rounded-xl shadow-2xs transition disabled:opacity-50 flex items-center gap-2 cursor-pointer"
                >
                  {isPending ? (
                    <>
                      <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      <span>Oluşturuluyor...</span>
                    </>
                  ) : (
                    <span>Fırsatı Oluştur & Ata</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
