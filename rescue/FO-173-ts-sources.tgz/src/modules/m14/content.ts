import { TrainingLesson, TrainingStageInfo } from './types';

export const TRAINING_STAGES: TrainingStageInfo[] = [
  {
    id: 'stage1_platform',
    titleTr: 'Bölüm 1: FonBridge Sistem ve Modül Kılavuzu',
    titleEn: 'Stage 1: FonBridge Platform & Module Guide',
    subtitleTr: 'Platformu en yüksek verimle kullanmak için genel sistem ve modül bazında adım adım rehber.',
    subtitleEn: 'Step-by-step operational handbook for workspace navigation and each modular capability.',
    descriptionTr:
      'FonBridge çalışma alanı yönetimi, roller, 4-Eyes güvenlik mekanizması ve M1-M13 modüllerinin uçtan uca uygulamalı eğitimini içerir.',
    descriptionEn:
      'Covers FonBridge workspace management, role hierarchy, 4-Eyes security protocol, and detailed workflows for M1-M13 modules.',
    icon: '🖥️',
    badge: '14 Ders / Kılavuz',
    badgeColor: 'bg-accent/15 text-accent-ink border-accent/20',
  },
  {
    id: 'stage2_grants',
    titleTr: 'Bölüm 2: Genel Proje ve Hibe Yaşam Döngüsü Masterclass',
    titleEn: 'Stage 2: Grants & Project Lifecycle Masterclass',
    subtitleTr: 'Çağrı aramadan konsorsiyum kurmaya, teklif yazımından hibe yönetimine tam döngü eğitimi.',
    subtitleEn: 'Comprehensive methodology: call discovery, consortium building, proposal writing, and execution.',
    descriptionTr:
      'Horizon Europe, TÜBİTAK ve uluslararası hibe çağrılarının taranması, ideal konsorsiyum mimarisi, Excellence-Impact-Implementation kriterleri, bütçeleme ve denetim süreçleri.',
    descriptionEn:
      'Deep-dive into EU/National funding calls, partner search, consortium agreements (DESCA), proposal quality, and grant agreement preparation (GAP).',
    icon: '🌍',
    badge: '4 Kapsamlı Aşama',
    badgeColor: 'bg-ok/15 text-ok border-ok/20',
  },
];

export const TRAINING_LESSONS: TrainingLesson[] = [
  // ───────────────────────────────────────────────────────────────────────────
  // STAGE 1: SISTEM VE MODUL EGITIMLERI
  // ───────────────────────────────────────────────────────────────────────────
  {
    id: 'sys-overview',
    stage: 'stage1_platform',
    moduleRef: 'GENERAL',
    titleTr: 'FonBridge Platformuna Giriş & Temel Sistem Kullanımı',
    titleEn: 'Introduction to FonBridge & Core System Navigation',
    shortDescTr: 'Çalışma alanı (Workspace) mantığı, kullanıcı rolleri, 4-Eyes onay güvenlik standardı ve gösterge paneli.',
    shortDescEn: 'Workspace architecture, user role hierarchy, 4-Eyes dual approval, and dashboard navigation.',
    category: 'Genel Sistem',
    categoryEn: 'General System',
    durationMinutes: 15,
    level: 'beginner',
    icon: '🏢',
    actionRoute: 'dashboard',
    actionLabelTr: 'Ana Panele Git',
    actionLabelEn: 'Open Dashboard',
    sections: [
      {
        title: '1. Çok Kiracılı Çalışma Alanı (Workspace) Mimarisi',
        content:
          'FonBridge, çok kiracılı (multi-tenant) ve çalışma alanı odaklı bir kurumsal mimariye sahiptir. Kuruluşunuz adına açılan bir organizasyon hesabı altında birden fazla "Çalışma Alanı (Workspace)" tanımlayabilirsiniz. Örneğin; Ar-Ge Merkezi, TTO Departmanı veya Uluslararası Projeler Ofisi için ayrı ayrı çalışma alanları açılarak veri izolasyonu sağlanır.',
        tips: [
          'Her çalışma alanının kendi proje portföyü, ortak rehberi ve özel teklif akışı bağımsız olarak yönetilir.',
          'Üst menüden istediğiniz çalışma alanına tek tıkla geçiş yapabilirsiniz.',
        ],
        keyTakeaway:
          'Projelerinizi karışıklık olmadan yönetmek için departman veya birim bazında ayrı çalışma alanları oluşturun.',
      },
      {
        title: '2. Rol ve Yetki Hiyerarşisi (RBAC)',
        content:
          'Platform içerisinde 5 farklı kullanıcı rolü tanımlıdır: ADMIN (Yönetici), WRITER (Yazar/Araştırmacı), MEMBER (Ekip Üyesi), REVIEWER (Hakem/Denetçi) ve READER (Salt Okunur). Modül açma/kapama ve kritik kapı onayları rol bazında sınırlandırılmıştır.',
        tips: [
          'Teklif metinlerini sadece WRITER ve ADMIN rolleri düzenleyebilir.',
          'Harici danışmanlar veya stajyerler için READER rolü verilerek veri güvenliği garantiye alınır.',
        ],
        keyTakeaway: 'En az ayrıcalık (Least Privilege) ilkesi gereği her kullanıcıya yalnızca ihtiyacı olan rolü verin.',
      },
      {
        title: '3. 4-Eyes (Çift Onay) Güvenlik Prensibi',
        content:
          'FonBridge teklif üretim döngüsünde "4-Eyes" prensibi esastır. Bir teklifi hazırlayan yazar, kendi teklifinin kapı geçişini (Gate Approval) tek başına onaylayamaz. İkinci bir yetkili (Reviewer veya Admin) incelemeden teklif bir sonraki aşamaya geçirilemez. Bu mekanizma insan hatalarını ve eksik başvuruları %90 oranında engeller.',
        checkpoints: [
          'Teklif G1 Konsept aşamasından G2 Konsorsiyum aşamasına geçerken çift onay zorunludur.',
          'Onay kayıtları denetim günlüğünde (Audit Log) değiştirilemez şekilde saklanır.',
        ],
        keyTakeaway: 'Çift göz onayı, kurumsal hibe başvurularında kalite standardının temel güvencesidir.',
      },
    ],
    quiz: [
      {
        question: 'FonBridge 4-Eyes (Çift Onay) prensibinin temel amacı nedir?',
        options: [
          'Sadece yöneticilerin sisteme giriş yapmasını sağlamak',
          'Teklif yazarının kendi teklifini tek başına onaylamasını engelleyerek kalite kontrolü sağlamak',
          'Yapay zeka modellerini eğitmek',
          'Veri tabanını yedeklemek',
        ],
        correctIndex: 1,
        explanation:
          '4-Eyes mekanizması, bir yazarın kendi belgesini onaylamasını engelleyerek en az iki yetkilinin denetiminden geçmesini garanti eder.',
      },
    ],
  },
  {
    id: 'm1-cordis',
    stage: 'stage1_platform',
    moduleRef: 'M1',
    titleTr: 'M1: CORDIS Partner Ağı & Organizasyon İstihbaratı',
    titleEn: 'M1: CORDIS Partner Intelligence & Network Graphs',
    shortDescTr: 'Geçmiş AB projeleri, PIC numarası sorguları, ağ merkezilik analitiği ve stratejik partner profilleri.',
    shortDescEn: 'Past EU projects, PIC inquiries, network centrality analytics, and strategic partner dossiers.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 12,
    level: 'intermediate',
    icon: '🌐',
    actionRoute: 'partners',
    actionLabelTr: 'M1 Ortak Analizini Aç',
    actionLabelEn: 'Open M1 Partners',
    sections: [
      {
        title: '1. CORDIS Veritabanı Entegrasyonu Nasıl Çalışır?',
        content:
          'M1 modülü, Avrupa Komisyonu resmi CORDIS veritabanındaki 150.000+ proje ve 40.000+ faydalanıcı kurum verisini gerçek zamanlı işler. Arama çubuğuna bir kurum adı veya 9 haneli PIC (Participant Identification Code) numarası girerek kurumun geçmişte kazandığı hibe miktarını, koordinatörlük deneyimini ve en sık çalıştığı ülkeleri görebilirsiniz.',
        tips: [
          'Almanya, Fransa veya İspanya gibi yüksek başarı oranına sahip ülkelerdeki koordinatörleri PIC koduyla inceleyin.',
          'Kurumun son 3 yıldaki aktif proje trendini kontrol ederek "yorgun" veya "pasif" ortakları önceden eleyin.',
        ],
        keyTakeaway: 'Resmi CORDIS verisiyle doğrulanmamış kurumlarla konsorsiyum masasına oturmayın.',
      },
      {
        title: '2. Ağ Merkezilik (Network Centrality) Grafiği',
        content:
          'Bir kurumun AB hibe ekosistemindeki ağırlığı "Merkezilik Skoru" ile ölçülür. Degree Centrality (doğrudan bağlantı sayısı), Betweenness Centrality (köprü olma gücü) ve Eigenvector Centrality (nüfuzlu partnerlerle bağları) metrikleri görsel bir ağ grafiği olarak sunulur.',
        checkpoints: [
          'Betweenness skoru yüksek ortaklar, diğer iş paketi liderlerine ve hakemlere ulaşmada kilit rol oynar.',
          'Grafik üzerinden partnerin geçmiş konsorsiyum ortaklarına tek tıkla tıklayarak genişleme sağlayabilirsiniz.',
        ],
      },
    ],
    quiz: [
      {
        question: 'CORDIS PIC numarası kaç haneli resmi bir koddur?',
        options: ['6 haneli', '9 haneli', '12 haneli', '16 haneli'],
        correctIndex: 1,
        explanation: 'AB Participant Identification Code (PIC) 9 haneli benzersiz bir kurumsal kimlik numarasıdır.',
      },
    ],
  },
  {
    id: 'm2-concept-notes',
    stage: 'stage1_platform',
    moduleRef: 'M2',
    titleTr: 'M2: AI Destekli Konsept Notu Mimarı (G0-G1)',
    titleEn: 'M2: AI-Powered Concept Note Architecture (G0-G1)',
    shortDescTr: 'Çağrıya özel problem tanımı, yenilikçi yaklaşım, TRL sıçraması ve G0-G1 onay kapısı üretimi.',
    shortDescEn: 'Problem formulation, breakthrough innovation, TRL leap, and G0-G1 stage-gate drafting.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 14,
    level: 'intermediate',
    icon: '📝',
    actionRoute: 'conceptNotes',
    actionLabelTr: 'M2 Konsept Notlarını Aç',
    actionLabelEn: 'Open M2 Concept Notes',
    sections: [
      {
        title: '1. Konsept Notunun Anatomisi',
        content:
          'Konsept notu, 45 sayfalık tam teklif yazımına başlamadan önce hazırlanan 3-5 sayfalık stratejik özettir. M2 modülü; çağrı kodunu, projenin temel fikrini, TRL başlangıç/bitiş hedefini ve ortaklık vizyonunu alarak AB standartlarında yapılandırılmış bir konsept taslağı oluşturur.',
        tips: [
          'Giriş bölümünde hakemleri yakalayan güçlü bir "Hook (Kanca)" cümlesi kullanın.',
          'TRL (Teknoloji Hazırlık Seviyesi) artışını rakamlarla somutlaştırın (Örn: TRL 4 Laboratuvardan TRL 7 Endüstriyel Demoya).',
        ],
        keyTakeaway: 'Kötü bir konsept notunun üzerine iyi bir tam teklif inşa edilemez.',
      },
      {
        title: '2. G0 ve G1 Kapı Onayları',
        content:
          'Proje fikri doğduğunda G0 (Fikir Onayı), konsept notu tamamlandığında ise G1 (Konsept Onayı) kapısına iletilir. İkinci bir değerlendirici tarafından onaylanmadan konsorsiyum ortakları aranmaya başlanamaz.',
      },
    ],
    quiz: [
      {
        question: 'G1 kapısı FonBridge aşama-kapı döngüsünde neyi temsil eder?',
        options: ['Tam hibe anlaşmasını', 'Konsept notu onayını', 'Avans ödemesini', 'Son finansal denetimi'],
        correctIndex: 1,
        explanation: 'G1 kapısı, konsept notunun çift göz kontrolünden geçerek onaylanmasını ifade eder.',
      },
    ],
  },
  {
    id: 'm3-evidence',
    stage: 'stage1_platform',
    moduleRef: 'M3',
    titleTr: 'M3: Kanıt Paketi & AB Politika Deposu (Evidence Pack)',
    titleEn: 'M3: Evidence Pack & EU Policy Citations',
    shortDescTr: 'Green Deal, Digital Decade, SDG göstergeleri ve doğrulanabilir istatistiki kanıtlar.',
    shortDescEn: 'Green Deal, Digital Decade, SDG indicators, and verifiable EU statistical benchmarks.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 10,
    level: 'intermediate',
    icon: '📊',
    actionRoute: 'evidence',
    actionLabelTr: 'M3 Kanıt Deposunu Aç',
    actionLabelEn: 'Open M3 Evidence Pack',
    sections: [
      {
        title: '1. Teklifinizi Kanıtlara Dayandırma Zorunluluğu',
        content:
          'Avrupa Komisyonu hakemleri, dayanaksız iddiaları ("Projemiz karbon salınımını büyük oranda azaltacaktır" gibi) anında cezalandırır. Bunun yerine "Projemiz, AB Yeşil Mutabakat 2030 hedefleri doğrultusunda CO2 salınımını %37 oranında azaltacaktır (Kaynak: Eurostat 2025/C-14)" gibi doğrulanabilir veriler girilmelidir.',
        tips: [
          'M3 arama motorunu kullanarak teklif konunuzla ilgili AB direktiflerini ve istatistiklerini bulun.',
          'Seçtiğiniz kanıtları doğrudan projenizin Impact (Etki) bölümüne bağlayın.',
        ],
        keyTakeaway: 'Kanıtsız iddia red gerekçesidir; kanıtlı gerekçe tam hakem puanı kazandırır.',
      },
    ],
  },
  {
    id: 'm4-relationships',
    stage: 'stage1_platform',
    moduleRef: 'M4',
    titleTr: 'M4: Konsorsiyum CRM & Odak Noktası (Focal Point) Yönetimi',
    titleEn: 'M4: Consortium CRM & Focal Point Management',
    shortDescTr: 'Ortak kurumlar, irtibat kişileri, resmi iletişim geçmişi ve çıkar çatışması denetimi.',
    shortDescEn: 'Partner organizations, focal points, contact logs, and conflict-of-interest checks.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 10,
    level: 'beginner',
    icon: '👥',
    actionRoute: 'relationships',
    actionLabelTr: 'M4 CRM Panelini Aç',
    actionLabelEn: 'Open M4 CRM',
    sections: [
      {
        title: '1. Ortak Kurumlarla İletişim Geçmişi Tutma',
        content:
          'M4 modülü, konsorsiyum adaylarının temsilcilerini (Focal Points) kayıt altına alır. Hangi toplantının ne zaman yapıldığı, paylaşılan gizlilik anlaşmaları (NDA) ve taahhüt edilen iş paketleri kurumsal hafızada tutulur.',
      },
    ],
  },
  {
    id: 'm5-pipeline',
    stage: 'stage1_platform',
    moduleRef: 'M5',
    titleTr: 'M5: Teklif Üretim Döngüsü & Aşama-Kapı (Stage-Gate G0-G4)',
    titleEn: 'M5: Stage-Gate Proposal Lifecycle (G0-G4)',
    shortDescTr: 'G0 Fikir, G1 Konsept, G2 Konsorsiyum, G3 Tam Taslak ve G4 Teslim kapılarının yönetimi.',
    shortDescEn: 'Managing G0 Idea, G1 Concept, G2 Consortium, G3 Draft, and G4 Final Submission gates.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 15,
    level: 'advanced',
    icon: '🚦',
    actionRoute: 'pipeline',
    actionLabelTr: 'M5 Pipeline Akışını Aç',
    actionLabelEn: 'Open M5 Pipeline',
    sections: [
      {
        title: '1. G0-G4 Kapı Disiplini',
        content:
          'Hibe projelerinde en büyük risk, son haftaya kadar belirsiz kalan konsorsiyum ve bütçe ayrıntılarıdır. M5 modülü süreci 5 katı aşamaya böler:\n- G0 (Idea): Fırsatın çağrıya stratejik uygunluğu test edilir.\n- G1 (Concept Note): 3-5 sayfalık mimari onaylanır.\n- G2 (Consortium): Tüm ortaklar belirlenir ve iş paketleri paylaştırılır.\n- G3 (Full Draft): Part A ve Part B taslağı tamamlanır, ESR puanlaması yapılır.\n- G4 (Submission Gate): LEAR yetkilendirmesi, bütçe denetimi ve resmi sisteme yükleme.',
        keyTakeaway: 'Aşama kapısı disiplini, son gün paniklerini ve eksik dosya teslimlerini tamamen ortadan kaldırır.',
      },
    ],
  },
  {
    id: 'm6-evaluator',
    stage: 'stage1_platform',
    moduleRef: 'M6',
    titleTr: 'M6: Hakem Perspektifi & AI Puanlama Simülasyonu (Evaluator Lens)',
    titleEn: 'M6: Evaluator Lens & AI ESR Scoring Simulation',
    shortDescTr: 'Excellence, Impact, Implementation bölümlerinin 1-15 puan arası hakem simülasyonu.',
    shortDescEn: 'Deep AI evaluation simulating official ESR scoring across Excellence, Impact, Implementation.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 14,
    level: 'advanced',
    icon: '🔬',
    actionRoute: 'pipeline',
    actionLabelTr: 'M6 Değerlendirmeyi İncele',
    actionLabelEn: 'Explore M6 Evaluator',
    sections: [
      {
        title: '1. ESR (Evaluation Summary Report) Simülasyonu',
        content:
          'Teklifinizi resmi sisteme göndermeden önce M6 yapay zeka hakem simülasyonuna sokabilirsiniz. Sistem, Avrupa Komisyonu değerlendirme kılavuzlarını kullanarak teklifinizi 3 temel başlıkta (Excellence 5 puan, Impact 5 puan, Implementation 5 puan, toplam 15 puan) notlandırır. Eşik değer genelde 10/15 veya 12/15 puandır.',
        tips: [
          'Hakemin "Weaknesses (Zayıf Yönler)" olarak işaretlediği maddeleri tek tek ele alın.',
          'Yapay zekanın sunduğu alternatif düzeltme paragraflarını Part B taslağınıza ekleyin.',
        ],
        keyTakeaway: 'Hakem simülasyonundan 13.5 üstü alamayan teklifi resmi sisteme yüklemeyin.',
      },
    ],
  },
  {
    id: 'm7-tto',
    stage: 'stage1_platform',
    moduleRef: 'M7',
    titleTr: 'M7: Teknoloji Transferi & Patent Eşleştirme Motoru (TTO)',
    titleEn: 'M7: TTO Accelerator & Patent Matching Engine',
    shortDescTr: 'Üniversite patentleri ve teknoloji portföylerinin açık AB çağrılarına otomatik eşleştirilmesi.',
    shortDescEn: 'Automated semantic matching of university IP and technology portfolios to open EU calls.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 10,
    level: 'intermediate',
    icon: '🚀',
    actionRoute: 'tto',
    actionLabelTr: 'M7 TTO Modülünü Aç',
    actionLabelEn: 'Open M7 TTO',
    sections: [
      {
        title: '1. Patentleri Fonla Buluşturma',
        content:
          'TTO modülü, kurumunuzun patent özetlerini ve teknoloji envanterini tarar. Semantik yapay zeka ile güncel Horizon Europe çağrı başlıklarıyla eşleştirerek "Hangi patent hangi çağrıda konsorsiyum bileti olabilir?" sorusuna anında yanıt verir.',
      },
    ],
  },
  {
    id: 'm8-matching',
    stage: 'stage1_platform',
    moduleRef: 'M8',
    titleTr: 'M8: Akıllı Konsorsiyum Eşleştirici & Kazanma Skoru',
    titleEn: 'M8: Smart Consortium Matcher & Win-Score Optimization',
    shortDescTr: 'Çağrı isterlerine göre en yüksek kazanma olasılığına sahip partner ve koordinatör önerileri.',
    shortDescEn: 'AI matchmaking suggesting top-tier partners and coordinators maximizing win probability.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 12,
    level: 'advanced',
    icon: '🎯',
    actionRoute: 'partners',
    actionLabelTr: 'M8 Eşleştirmeyi Başlat',
    actionLabelEn: 'Open M8 Matching',
    sections: [
      {
        title: '1. Kazanma Skoru (Win Score) Hesaplama',
        content:
          'Bir konsorsiyum sadece iyi kurumlardan oluşmaz; dengeli dağılımdan oluşur. M8 modülü; coğrafi çeşitlilik (3+ farklı ülke), sektör dengesi (Akademi + KOBİ + End-User) ve geçmiş başarı oranlarını çarparak konsorsiyumunuzun tahmini kazanma skorunu hesaplar.',
      },
    ],
  },
  {
    id: 'm9-briefing',
    stage: 'stage1_platform',
    moduleRef: 'M9',
    titleTr: 'M9: Konsorsiyum Toplantı Brifingi & Müzakere Dosyası',
    titleEn: 'M9: Automated Meeting Briefing Packs',
    shortDescTr: 'Konsorsiyum hazırlık toplantıları öncesinde çağrı özeti, partner analizleri ve müzakere gündemi.',
    shortDescEn: 'Automated briefing packs synthesizing call topics, partner dossiers, and negotiation agendas.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 10,
    level: 'intermediate',
    icon: '📋',
    actionRoute: 'pipeline',
    actionLabelTr: 'M9 Brifingleri Gör',
    actionLabelEn: 'View M9 Briefs',
    sections: [
      {
        title: '1. Müzakere Masasında Üstünlük Sağlama',
        content:
          'Yeni bir partner adayıyla ilk çevrim içi toplantıya girmeden önce M9 brifing modülü çalıştırılır. Partnerin geçmişte aldığı AB bütçeleri, uzmanlık alanları ve çağrıya özel tartışılacak 5 kritik soru tek bir PDF brifinginde toplanır.',
      },
    ],
  },
  {
    id: 'm10-mom',
    stage: 'stage1_platform',
    moduleRef: 'M10',
    titleTr: 'M10: Otomatik Toplantı Tutanakları (MoM) & Görev Dağılımı',
    titleEn: 'M10: Automated Minutes of Meetings (MoM) & Action Logs',
    shortDescTr: 'Toplantı dökümlerinden mutabakat zabıtları, ikili NDA anlaşmaları ve aksiyon planları.',
    shortDescEn: 'Generates automated MoMs, bilateral NDAs, milestone schedules, and action assignment logs.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 10,
    level: 'beginner',
    icon: '📄',
    actionRoute: 'pipeline',
    actionLabelTr: 'M10 Aksiyonlarını Aç',
    actionLabelEn: 'Open M10 Tasks',
    sections: [
      {
        title: '1. Sözlü Kararları Yazılı Taahhüde Dönüştürme',
        content:
          'Konsorsiyum görüşmelerindeki en büyük problem, partnerlerin toplantı sonrası görevlerini unutmasıdır. M10 modülü, ham notlardan veya ses dökümünden resmi MoM (Minutes of Meeting) belgesi ve tarihli aksiyon tablosu çıkarır.',
      },
    ],
  },
  {
    id: 'm11-full-app',
    stage: 'stage1_platform',
    moduleRef: 'M11',
    titleTr: 'M11: Tam Başvuru Formu Üretici (Part A İdari & Part B Teknik)',
    titleEn: 'M11: Full Application Production Engine (Part A & Part B)',
    shortDescTr: 'Resmi AB standartlarında Part A idari formları ve Part B teknik metin taslak üretimi.',
    shortDescEn: 'Full drafting engine generating official Part A administrative & Part B technical narrative.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 15,
    level: 'advanced',
    icon: '⚡',
    actionRoute: 'pipeline',
    actionLabelTr: 'M11 Başvuru Üreticisini Aç',
    actionLabelEn: 'Open M11 Application',
    sections: [
      {
        title: '1. Part A ve Part B Derleme Süreci',
        content:
          'G3 aşamasına gelen bir projenin tüm girdileri (konsept notu, ortak profilleri, kanıtlar ve iş paketleri) birleştirilerek resmi Horizon Europe şablonuna dönüştürülür. Sayfa sınırı kontrolleri, Gantt şeması verileri ve bütçe tabloları otomatik oluşturulur.',
      },
    ],
  },
  {
    id: 'm12-outreach',
    stage: 'stage1_platform',
    moduleRef: 'M12',
    titleTr: 'M12: Uzman & Hakem Ulaşım Asistanı (24 Dil, Anti-Bot LinkedIn)',
    titleEn: 'M12: Expert Outreach Assistant (24 Languages, Anti-Bot Safe)',
    shortDescTr: '31.400+ AB hakemine 24 resmi dilde yerel ulaşım, LinkedIn güvenli pano ve kota yönetimi.',
    shortDescEn: 'Outreach to 31,400+ evaluators in 24 EU languages, 100% LinkedIn anti-bot clipboard sync.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 12,
    level: 'intermediate',
    icon: '✉️',
    actionRoute: 'outreach',
    actionLabelTr: 'M12 Uzman Ulaşımını Aç',
    actionLabelEn: 'Open M12 Outreach',
    sections: [
      {
        title: '1. Neden Uzmanlara Yerel Dillerinde Ulaşmalısınız?',
        content:
          'Avrupa Komisyonu hakem ve uzmanlarının %78\'i kendi ana dillerinde (Almanca, Fransızca, İtalyanca, İspanyolca vb.) gelen profesyonel mesajlara çok daha hızlı ve olumlu dönüş yapmaktadır. M12 modülü, uzmanın etnik ve akademik ontolojisini analiz ederek 24 AB dilinde kişiselleştirilmiş şablon üretir.',
        tips: [
          'LinkedIn botu veya scraping kullanmaz; banlanma riski sıfırdır.',
          'Tek tıkla güvenli panoya kopyalama ve doğrudan LinkedIn profil bağlantısı sağlar.',
        ],
        keyTakeaway: 'Uzmanlara kendi ana dilinde ulaşmak, konsorsiyuma dahil olma kabul oranını 4 kat artırır.',
      },
    ],
  },
  {
    id: 'm13-call-summary',
    stage: 'stage1_platform',
    moduleRef: 'M13',
    titleTr: 'M13: Akıllı Çağrı Özeti & Gereksinim Analizi (ProjecSum)',
    titleEn: 'M13: Strategic Call Summary & Requirement Analyzer',
    shortDescTr: 'PDF, DOCX ve web çağrılarından 12 bölümlü stratejik Türkçe analiz ve uygunluk matrisi.',
    shortDescEn: '12-section AI-powered strategic call brief, eligibility matrix, and requirement analyzer.',
    category: 'Modül Kılavuzu',
    categoryEn: 'Module Guide',
    durationMinutes: 14,
    level: 'intermediate',
    icon: '📑',
    actionRoute: 'callSummary',
    actionLabelTr: 'M13 Çağrı Özetini Aç',
    actionLabelEn: 'Open M13 Call Summary',
    sections: [
      {
        title: '1. 100 Sayfalık Şartnameleri 3 Dakikada Sentezleme',
        content:
          'M13 modülü; çağrı URL\'si veya PDF/DOCX şartname belgesini okuyarak 12 kritik başlıkta stratejik özet üretir:\n1. Çağrı Amacı ve Vizyonu\n2. Kapsam (Scope)\n3. Beklenen Çıktılar (Expected Outcomes)\n4. Uygunluk Kriterleri (Eligibility)\n5. Bütçe ve Fonlama Oranı (%100 / %70)\n6. Hedef TRL Düzeyi\n7. Konsorsiyum Şartları\n8. Puanlama & Hakem Stratejisi\n9. İklim & Green Deal Uyumu\n10. Fikri Mülkiyet (IPR)\n11. Risk Faktörleri\n12. Son Başvuru Takvimi',
        tips: [
          'Başvuruya uygun olmayan çağrıları haftalarca vakit kaybetmeden ilk dakikada eleyin.',
          'Özeti yazdırılabilir brifing olarak toplantı ekibinize dağıtın.',
        ],
        keyTakeaway: 'Çağrının şartname dilini tam çözmeden teklif yazmaya başlamayın.',
      },
    ],
  },

  // ───────────────────────────────────────────────────────────────────────────
  // STAGE 2: GENEL PROJE VE HIBE YASAM DONGUSU MASTERCLASS
  // ───────────────────────────────────────────────────────────────────────────
  {
    id: 'grant-step1-calls',
    stage: 'stage2_grants',
    titleTr: 'Aşama 1: Fon & Çağrı Arama / Stratejik Hibe Eşleştirmesi',
    titleEn: 'Stage 1: Call Discovery & Strategic Grant Matching',
    shortDescTr: 'Horizon Europe, TÜBİTAK ve ulusal fonların taranması, TRL seviyeleri ve uygunluk matrisi.',
    shortDescEn: 'Scanning Horizon Europe, national grants, TRL readiness mapping, and eligibility matrices.',
    category: 'Çağrı & Fon',
    categoryEn: 'Calls & Grants',
    durationMinutes: 20,
    level: 'intermediate',
    icon: '🔍',
    actionRoute: 'calls',
    actionLabelTr: 'Açık Çağrıları Keşfet',
    actionLabelEn: 'Discover Open Calls',
    sections: [
      {
        title: '1. Hibe Programlarının Haritası',
        content:
          'Proje yolculuğu doğru hibe programını seçmekle başlar. Ekosistem temelde 3 seviyeden oluşur:\n- **Avrupa Birliği Programları**: Horizon Europe (Pillar 2 Kümelenmeleri: Sağlık, Dijital, İklim/Enerji, Gıda/Biyoekonomi vb.), Digital Europe, LIFE (Çevre), Innovation Fund ve Erasmus+.\n- **Uluslararası İkili & Çoklu İşbirlikleri**: Eurostars/Eureka, PRIMA, COST aksiyonları.\n- **Ulusal Hibeler (Türkiye)**: TÜBİTAK 1001 (Temel Bilimler), 1501 (Sanayi Ar-Ge), 1507 (KOBİ Başlangıç), 1071 (Uluslararası Ortaklık Destekleri) ve Kalkınma Ajansı Bölgesel Fonları.',
        tips: [
          'Ar-Ge yoğunluğunuz yüksekse Horizon Europe ve TÜBİTAK 1501/1071 programlarına odaklanın.',
          'Pazara yakın ticarileşme hedefiniz varsa Eurostars veya Innovation Fund çağrılarını tercih edin.',
        ],
        keyTakeaway: 'Yanlış fon programına yapılan mükemmel bir başvuru, baştan elenmeye mahkûmdur.',
      },
      {
        title: '2. Şartname Analizi: Scope vs. Expected Outcomes',
        content:
          'Bir AB çağrı metninde en kritik iki bölüm vardır:\n1. **Scope (Kapsam)**: Projenin hangi teknik ve metodolojik sınırları kapsamak zorunda olduğunu belirtir. Buradaki maddelerden birini bile atlamak hakemlerden sıfır puan almanıza neden olur.\n2. **Expected Outcomes (Beklenen Çıktılar)**: Proje bittiğinde sektörde ve Avrupa genelinde hangi somut değişimlerin (patent, açık kaynak kod, standart, politika önerisi) gerçekleşmesi gerektiğini listeler.',
        tips: [
          'Teklifinizin her bir iş paketini doğrudan çağrı metnindeki "Expected Outcome" maddeleriyle bire bir eşleştirin.',
        ],
      },
      {
        title: '3. Teknoloji Hazırlık Seviyesi (TRL) Dengesi',
        content:
          'TRL 1 (Temel İlkeler) ile TRL 9 (Pazarda Kanıtlanmış Sistem) arasındaki skala projeler için hayati göstergedir:\n- **RIA (Research & Innovation Action)**: TRL 3-4 seviyesinden başlar, TRL 5-6 seviyesinde tamamlanır. Fonlama oranı %100\'dür.\n- **IA (Innovation Action)**: TRL 5-6 seviyesinden başlar, TRL 7-8 prototip/demo seviyesinde biter. Sanayi için fonlama oranı %70\'tir (kâr amacı gütmeyenler için %100).\n- **CSA (Coordination & Support Action)**: Ar-Ge içermez; ağ kurma, standart geliştirme ve politika desteği sağlar (%100 hibe).',
        codeOrFormula: 'TRL 1-3: Temel Araştırma | TRL 4-6: Laboratuvar & Pilot Demo | TRL 7-9: Ticarileşme & Saha',
        keyTakeaway: 'Çağrının istediği TRL seviyesinin altında veya üstünde teklif vermek doğrudan red sebebidir.',
      },
    ],
    quiz: [
      {
        question: 'Innovation Action (IA) projelerinde kâr amaçlı özel şirketlerin standart AB fonlama oranı kaçtır?',
        options: ['%50', '%70', '%100', '%120'],
        correctIndex: 1,
        explanation: 'Horizon Europe Innovation Action (IA) projelerinde kâr amacı güden kuruluşlar için hibe oranı %70\'tir.',
      },
    ],
  },
  {
    id: 'grant-step2-consortium',
    stage: 'stage2_grants',
    titleTr: 'Aşama 2: Proje Ortağı Bulma & Konsorsiyum Mimarisi',
    titleEn: 'Stage 2: Partner Search & Consortium Architecture',
    shortDescTr: 'İdeal konsorsiyum dengesi, coğrafi şartlar, EoI davetleri ve DESCA konsorsiyum anlaşması.',
    shortDescEn: 'Consortium balance, geographic rules, EoI outreach, and DESCA consortium agreements.',
    category: 'Konsorsiyum',
    categoryEn: 'Consortium',
    durationMinutes: 22,
    level: 'advanced',
    icon: '🤝',
    actionRoute: 'partners',
    actionLabelTr: 'Partner Arama Motoru',
    actionLabelEn: 'Partner Search Engine',
    sections: [
      {
        title: '1. İdeal Konsorsiyumun Üçgen Modeli',
        content:
          'Kazanan bir Horizon Europe konsorsiyumu genellikle 8 ila 15 ortaktan oluşur ve şu üçgen dengesini kurar:\n1. **Akademi / Araştırma Enstitüleri (RTO)**: Bilimsel mükemmeliyet, simülasyon ve teorik modellemeyi üstlenir (Örn: Fraunhofer, CNRS, TÜBİTAK MAM).\n2. **Sanayi & KOBİ\'ler (Industry & SMEs)**: Geliştirilen teknolojiyi endüstriyel prototipe dönüştürür ve ticari sömürü (Exploitation) planını yürütür.\n3. **Kamu / Son Kullanıcı / STK (End-Users & Pilots)**: Teknolojiyi gerçek sahada test eder (Örn: Belediyeler, hastaneler, çiftçi birlikleri).',
        tips: [
          'Teknik iş ortaklarının yanı sıra mutlaka bir "İletişim ve Yaygınlaştırma (Dissemination)" uzmanı ortak dahil edin.',
        ],
        keyTakeaway: 'Sadece üniversitelerden veya sadece şirketlerden oluşan bir konsorsiyum AB hakemlerinden geçemez.',
      },
      {
        title: '2. Resmi Coğrafi Dağılım Kuralı (Eligibility)',
        content:
          'Horizon Europe çok ortaklı çağrılarında temel kural: En az 3 bağımsız tüzel kişilik, en az 3 farklı AB Üye Ülkesi (EU Member State) veya İlişkili Ülke (Associated Country - Örn: Türkiye, Norveç, İsviçre vb.) sınırları içinde yerleşik olmalıdır. Bu şartlardan en az 1 tanesi kesinlikle bir AB Üye Ülkesinde bulunmalıdır.',
        checkpoints: [
          'İngiltere (UK), Horizon Europe ortaklıklarına tam haklarla yeniden katılmıştır.',
          'Türkiye merkezli kurumlar AB üyesi ülkelerle eşit haklarla hibe alabilir ve koordinatör olabilir.',
        ],
      },
      {
        title: '3. Etkili İlgi Beyanı (Expression of Interest - EoI)',
        content:
          'Büyük koordinatörlere e-posta atarken 50 sayfalık şirket tanıtım kataloğu göndermeyin! 1 sayfalık odaklanmış bir EoI hazırlayın:\n- Proje çağrı kodu ve başlığı\n- Kurumun çağrıyla örtüşen en kritik 2 laboratuvar altyapısı veya patenti\n- Hangi iş paketine (WP) talip olduğunuz ve sunacağınız somut çıktı (Deliverable)\n- Kısa ekip profili ve CORDIS PIC numarası.',
        tips: ['FonBridge M12 modülünü kullanarak koordinatörün ana dilinde kişiselleştirilmiş EoI iletin.'],
      },
      {
        title: '4. Konsorsiyum Anlaşması (Consortium Agreement - DESCA)',
        content:
          'Proje kabul edildikten sonra ortaklar arasında imzalanan en kritik hukuki belge DESCA Konsorsiyum Anlaşmasıdır. Bu anlaşma şunları düzenler:\n- **Background IP (Arka Plan Mülkiyeti)**: Projeye girmeden önce sahip olduğunuz patent ve ticari sırların korunması.\n- **Results IP (Sonuç Hakları)**: Projede ortaya çıkan buluşların ortak mülkiyeti ve lisanslama hakları.\n- **Defaulting Partner (Temerrüt)**: İşini yapmayan ortağın konsorsiyumdan atılması ve bütçesinin diğer ortaklara devri kuralları.',
        keyTakeaway: 'Fikri mülkiyet haklarınızı korumak için DESCA standart modelinden taviz vermeyin.',
      },
    ],
    quiz: [
      {
        question: 'Horizon Europe çok ortaklı konsorsiyumlarında minimum ülke kuralı nedir?',
        options: [
          'En az 2 ülke (biri AB üyesi)',
          'En az 3 bağımsız kuruluş, en az 3 farklı AB/İlişkili ülke (en az 1 AB üyesi)',
          'En az 5 AB üye ülkesi',
          'Sadece tek bir ülke yeterlidir',
        ],
        correctIndex: 1,
        explanation: 'Kural gereği en az 3 farklı ülkeden 3 bağımsız tüzel kişilik olmalı ve en az biri AB üyesi olmalıdır.',
      },
    ],
  },
  {
    id: 'grant-step3-proposal',
    stage: 'stage2_grants',
    titleTr: 'Aşama 3: Proje Hazırlama, Teklif Yazımı & Kalite Mühendisliği',
    titleEn: 'Stage 3: Proposal Drafting & Value Engineering',
    shortDescTr: 'Excellence, Impact ve Implementation bölümlerinin hakem dostu formatta yazılması ve bütçeleme.',
    shortDescEn: 'Drafting Excellence, Impact, Implementation narrative, Logframe, and cost budgeting.',
    category: 'Teklif Yazımı',
    categoryEn: 'Proposal Writing',
    durationMinutes: 25,
    level: 'advanced',
    icon: '✍️',
    actionRoute: 'pipeline',
    actionLabelTr: 'Teklif Üretimini Başlat',
    actionLabelEn: 'Start Proposal Production',
    sections: [
      {
        title: '1. Hakem Değerlendirmesinin 3 Kutsal Kriteri',
        content:
          'Tüm AB teklifleri 3 ana bölümde değerlendirilir (Her biri 5 puan, toplam 15 puan):\n\n' +
          '### 1. Excellence (Mükemmeliyet)\n' +
          '- **Proje Hedefleri (Objectives)**: SMART olmalıdır (Spesifik, Ölçülebilir, Ulaşılabilir, İlgili, Zamanlı).\n' +
          '- **Devletin En İleri Seviyesi (State-of-the-Art)**: Mevcut literatür ve patentlerin nerede tıkandığı ve projenizin bu engeli nasıl aşacağı.\n' +
          '- **Metodoloji**: Açık bilim (Open Science), araştırma verisi yönetimi (FAIR prensipleri) ve cinsiyet boyutu (Gender Dimension).\n\n' +
          '### 2. Impact (Etki)\n' +
          '- **Etki Patikası (Pathway to Impact)**: Çıktı (Project Results) -> Sonuç (Outcomes) -> Geniş Etki (Scientific, Economic, Societal Impacts).\n' +
          '- **Ölçek ve Önemi (Scale & Significance)**: Etkinin ne kadar büyük bir nüfusu veya pazarı kapsadığı.\n' +
          '- **Yaygınlaştırma, İletişim ve Ticarileştirme Planı (D&E Plan)**.\n' +
          '- **Do No Significant Harm (DNSH)**: 6 çevresel hedefe zarar vermeme taahhüdü.\n\n' +
          '### 3. Quality and Efficiency of Implementation (Uygulama)\n' +
          '- **İş Paketleri (Work Packages - WPs)**: Genellikle WP1 Yönetim, WP2-5 Teknik Geliştirme, WP6 Pilot Demo, WP7 İletişim & Ticarileştirme.\n' +
          '- **Çıktılar (Deliverables) ve Kilometre Taşları (Milestones)**.\n' +
          '- **Risk Yönetim Matrisi**: Teknik, finansal ve konsorsiyum riskleri ile somut B planları.',
        tips: [
          'Sayfa sınırına kesinlikle uyun (RIA/IA için 45 sayfa). Sınırı aşan sayfalar hakem sisteminde grileşir ve okunmaz!',
          'Metin blokları yerine diyagramlar, özet tablolar ve akış şemaları kullanarak hakemin yorulmasını engelleyin.',
        ],
        keyTakeaway: 'Hakem bir projeyi ortalama 3-4 saatte okur; görsel ve anlaşılır tablolar puan kazandırır.',
      },
      {
        title: '2. Bütçe Planlaması ve Kişi-Ay (Person-Month) Hesabı',
        content:
          'Proje bütçesi kalem bazında gerçekçi olarak hesaplanmalıdır:\n' +
          '- **Doğrudan Personel Maliyeti (Direct Personnel Costs)**: Kişi-Ay (PM) x Aylık brüt maliyet.\n' +
          '- **Alt Yüklenici (Subcontracting)**: Çekirdek Ar-Ge alt yükleniciye verilemez; sadece özel test, sertifikasyon veya denetim gibi kalemler verilebilir.\n' +
          '- **Seyahat ve Gündelikler (Travel & Subsistence)**: Konsorsiyum toplantıları ve konferans katılımları.\n' +
          '- **Ekipman Amortismanı (Equipment)**: Ekipmanın tam bedeli değil, yalnızca projedeki kullanım süresi amortismanı yazılır.\n' +
          '- **Dolaylı Maliyetler (Indirect Costs / Overhead)**: Doğrudan uygun maliyetlerin otomatik %25\'i oranında eklenir.',
        codeOrFormula: 'Toplam Bütçe = (Personel + Seyahat + Ekipman Amortismanı + Diğer Mal/Hizmet) x 1.25 + Alt Yüklenici',
        keyTakeaway: 'Personel kişi-ay hesabını iş paketlerinin karmaşıklığıyla doğru orantılı kurgulayın.',
      },
    ],
    quiz: [
      {
        question: 'Horizon Europe standart RIA/IA tam teklif Part B teknik metninin sayfa sınırı kaçtır?',
        options: ['20 sayfa', '45 sayfa', '70 sayfa', '100 sayfa'],
        correctIndex: 1,
        explanation: 'Horizon Europe standart RIA/IA başvurularında Part B için sayfa sınırı katı biçimde 45 sayfadır.',
      },
    ],
  },
  {
    id: 'grant-step4-submission',
    stage: 'stage2_grants',
    titleTr: 'Aşama 4: Başvuru, Hakem Değerlendirmesi & Proje Yönetimi',
    titleEn: 'Stage 4: Submission, Evaluation, GAP & Project Execution',
    shortDescTr: 'Funding & Tenders Portal yüklemesi, konsensüs toplantıları, ESR raporu analizi ve GAP sözleşmesi.',
    shortDescEn: 'EU Funding Portal upload, consensus meetings, ESR analysis, GAP phase, and periodic reporting.',
    category: 'Yönetim & Hakem',
    categoryEn: 'Management & Review',
    durationMinutes: 18,
    level: 'advanced',
    icon: '🏆',
    actionRoute: 'approvals',
    actionLabelTr: 'Onay Merkezini İncele',
    actionLabelEn: 'Open Approval Center',
    sections: [
      {
        title: '1. Son Başvuru Günü (Submission Deadline) Yönetimi',
        content:
          'Resmi son teslim saati Brüksel saatiyle 17:00\'dir. Son 4 saatte Avrupa genelinde binlerce teklif aynı anda yüklendiği için Funding & Tenders Portal sunucuları aşırı yavaşlar.\n' +
          '- Teklifin tam taslağını son teslim tarihinden en az 48 saat önce portala yükleyin.\n' +
          '- Son ana kadar sistemde revize PDF yüklemeye devam edebilirsiniz; son yüklenen dosya geçerli olur.',
        tips: [
          'Part A formlarındaki kurum bütçelerinin Part B\'deki tablolarla kuruşu kuruşuna eşleştiğinden emin olun.',
        ],
        keyTakeaway: 'Son gün yükleme yapmak teknik arıza nedeniyle elenme riskini %20 artırır.',
      },
      {
        title: '2. Hakem Süreci ve Değerlendirme Özet Raporu (ESR)',
        content:
          'Başvurudan sonra süreç şu aşamalardan geçer:\n1. **Uygunluk Kontrolü (Eligibility Check)**: Komisyon görevlileri evrakları denetler.\n2. **Bireysel Değerlendirme (Individual Review)**: Birbirinden bağımsız en az 3 uzman hakem teklifi okur.\n3. **Konsensüs Toplantısı (Consensus Meeting)**: Hakemler bir araya gelerek ortak bir uzlaşı notu ve puanı belirler.\n4. **ESR (Evaluation Summary Report)**: Koordinatöre resmi sonuç bildirilir.',
      },
      {
        title: '3. Hibe Sözleşmesi Hazırlığı (GAP - Grant Agreement Preparation)',
        content:
          'Tebrikler! Projeniz fonlanmaya değer bulunduysa yaklaşık 3 aylık GAP süreci başlar:\n- Komisyonun teknik ve etik inceleme yorumları iş paketlerine yansıtılır.\n- Koordinatör ve tüm ortaklar resmi e-imza ile Grant Agreement imzalar.\n- Avrupa Komisyonu ilk avans ödemesini (Pre-financing, genellikle bütçenin %50-%70\'i) koordinatörün hesabına aktarır.\n- Koordinatör konsorsiyum anlaşmasındaki şartlara göre payları ortaklara dağıtır.',
        keyTakeaway: 'GAP aşamasında sözleşme imzalanana kadar hiçbir harcama yapmayın.',
      },
    ],
    quiz: [
      {
        question: 'Avrupa Komisyonu çağrı kapanış saatleri genelde hangi saat diliminde ve kaçtadır?',
        options: [
          'İstanbul saatiyle 23:59',
          'Brüksel saatiyle 17:00',
          'Londra saatiyle 12:00',
          'Brüksel saatiyle 24:00',
        ],
        correctIndex: 1,
        explanation: 'Resmi Avrupa Komisyonu Funding & Tenders Portal son başvuru saati kesin olarak Brüksel saatiyle 17:00\'dir.',
      },
    ],
  },
];

export const ACADEMY_TEMPLATES = [
  {
    id: 'tpl-proposal-checklist',
    titleTr: 'Horizon Europe Teklif Hazırlık Kontrol Listesi',
    titleEn: 'Horizon Europe Proposal Preparation Checklist',
    categoryTr: 'Teklif & Kalite',
    categoryEn: 'Proposal Quality',
    format: 'Checklist (.md / .docx)',
    content: `# Horizon Europe Teklif Hazırlık Kontrol Listesi

## 1. İdari ve Uygunluk Kontrolleri
- [ ] Çağrı Kodu ve TRL Başlangıç/Bitiş seviyesi doğrulandı.
- [ ] En az 3 farklı AB / İlişkili ülkeden 3 bağımsız tüzel kişilik konsorsiyumda mevcut.
- [ ] En az 1 ortak AB Üyesi Ülke sınırlarında yerleşik.
- [ ] Tüm ortakların 9 haneli PIC kodları ve LEAR onayları aktif.
- [ ] Sayfa sınırı kontrol edildi (Part B teknik metni maksimum 45 sayfa).

## 2. Excellence (Mükemmeliyet) Bölümü
- [ ] 3-5 adet SMART (Ölçülebilir) proje hedefi tanımlandı.
- [ ] Mevcut durum (State-of-the-Art) ve projenin getirdiği inovasyon net yazıldı.
- [ ] Açık Bilim (Open Science) ve FAIR veri prensipleri açıklandı.
- [ ] Cinsiyet boyutu (Gender dimension) araştırma metodolojisine dahil edildi.

## 3. Impact (Etki) Bölümü
- [ ] Etki Patikası (Pathway to Impact): Çıktı -> Sonuç -> Stratejik Etki tablosu oluşturuldu.
- [ ] İletişim, Yaygınlaştırma ve Ticarileştirme (D&E) planı hazırlandı.
- [ ] Do No Significant Harm (DNSH) çevre beyanı yapıldı.
- [ ] Fikri Mülkiyet (IPR) ve arka plan hakları netleştirildi.

## 4. Implementation (Uygulama) Bölümü
- [ ] İş Paketleri (WP), Görevler (Tasks) ve Liderler atandı.
- [ ] Deliverables (Çıktılar) ve Milestones (Kilometre Taşları) takvime bağlandı.
- [ ] Risk matrisi ve somut B planları (Mitigation measures) yazıldı.
- [ ] Kişi-Ay (Person-Months) tablosu ve bütçe tutarları kuruşu kuruşuna eşitlendi.`,
  },
  {
    id: 'tpl-eoi-template',
    titleTr: 'Konsorsiyum İlgi Beyanı (Expression of Interest - EoI)',
    titleEn: 'Expression of Interest (EoI) Template',
    categoryTr: 'Konsorsiyum',
    categoryEn: 'Consortium',
    format: 'Şablon (.md / .docx)',
    content: `# EXPRESSION OF INTEREST (EoI)

**Target Call ID:** HORIZON-CL...-202X-...
**Call Title:** [Çağrı Başlığı]
**Organization Name:** [Kurum / Şirket Adı]
**PIC Number:** [9 Haneli PIC Kodu]
**Country / Organization Type:** [Ülke / KOBİ, Üniversite, RTO, Kamu]

---

### 1. Executive Summary & Value Proposition
[Kurumunuzun bu çağrıya katacağı temel inovasyon ve uzmanlık özeti. Maksimum 150 kelime.]

### 2. Relevant Infrastructure & Core Competences
- **Key Asset 1:** [Örn: Akredite test laboratuvarı, temiz oda, 10.000+ kullanıcı verisi]
- **Key Asset 2:** [Örn: Patentli TRL 5 batarya yönetim algoritması]
- **Key Asset 3:** [Örn: CORDIS geçmişinde tamamlanmış 4 Horizon projesi deneyimi]

### 3. Targeted Work Package & Proposed Deliverables
- **Work Package Contribution:** WP3 (Teknik Geliştirme) veya WP5 (Pilot Uygulama)
- **Concrete Deliverables:**
  - D3.2: [Spesifik Çıktı Başlığı]
  - D5.1: [Saha Doğrulama Raporu]

### 4. Key Personnel & Contact Person
- **Lead Researcher / Focal Point:** Dr. [Ad Soyad], [Unvan]
- **Email:** contact@organization.com
- **Phone / LinkedIn:** +90 ... / linkedin.com/in/...`,
  },
  {
    id: 'tpl-desca-summary',
    titleTr: 'DESCA Konsorsiyum Anlaşması Temel Hükümleri',
    titleEn: 'DESCA Consortium Agreement Core Provisions',
    categoryTr: 'Hukuk & Sözleşme',
    categoryEn: 'Legal & Agreement',
    format: 'Özet Kılavuz (.md)',
    content: `# DESCA 2021 Konsorsiyum Anlaşması Kilit Maddeleri

1. **Yönetim Organları**:
   - **General Assembly (Genel Kurul)**: Tüm ortakların 1 oy hakkı olduğu nihai karar organı.
   - **Executive Board (Yürütme Kurulu)**: İş paketi liderlerinden oluşan operasyonel kurul.
   - Kararlar kural olarak 2/3 veya 3/4 çoğunlukla alınır; bütçe değişikliklerinde veto hakkı kısıtlıdır.

2. **Fikri Mülkiyet (IPR)**:
   - **Background IP**: Sözleşme ekine yazılmayan hiçbir önceki patent ortakların kullanımına açık sayılmaz.
   - **Results IP**: Bir buluşu yapan ortak o buluşun tek sahibidir. Birlikte yapıldıysa ortak mülkiyet (Joint Ownership) uygulanır.

3. **Ödeme Takvimi**:
   - Koordinatör, Komisyon'dan aldığı avansı en geç 30 gün içinde ortakların paylarına aktarmakla yükümlüdür.

4. **Temerrüt (Default)**:
   - Görevini yerine getirmeyen ortağa 30 gün resmi ihtar verilir. Düzelmezse Genel Kurul kararıyla ortaklıktan çıkarılır.`,
  },
];
