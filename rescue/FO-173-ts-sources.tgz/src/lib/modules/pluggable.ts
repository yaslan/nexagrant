/**
 * Pluggable Modules Registry for FonBridge.
 * Represents standalone, extensible modules found in `/modules/`
 * that integrate into the FonBridge ecosystem.
 */

export interface PluggableCapability {
  title: string;
  desc: string;
  icon: string;
}

export interface PluggableModule {
  id: string;
  slug: string;
  name: string;
  nameEn: string;
  version: string;
  icon: string;
  category: 'outreach' | 'ai' | 'tools';
  categoryLabel: string;
  categoryLabelEn: string;
  folderPath: string;
  descriptionTr: string;
  descriptionEn: string;
  badge: string;
  runtime: string;
  status: 'ACTIVE' | 'INTEGRATED' | 'STANDALONE';
  statusLabel: string;
  price?: string;
  allowedPlans: string[];
  capabilities: PluggableCapability[];
  technicalSpecs: {
    entrypoint: string;
    endpoints: string[];
    supportedFormats?: string[];
    architecture: string;
    security: string[];
  };
  sampleIntegrationSnippet: string;
}

export const PLUGGABLE_MODULES: PluggableModule[] = [
  {
    id: 'expert_outreach',
    slug: 'expert_outreach',
    name: 'Uzman Ulaşım Asistanı (Expert Outreach Assistant)',
    nameEn: 'Expert Outreach Assistant',
    version: '1.0.0',
    icon: '✉️',
    category: 'outreach',
    categoryLabel: 'Ağ & Uzman Ulaşım',
    categoryLabelEn: 'Networking & Outreach',
    folderPath: '/modules/ExpertOutreach',
    descriptionTr:
      '31.400+ Avrupa fonlama hakemi ve uzmanının etnik/dil ontolojisiyle 24 AB resmi dilinde ana dil tespiti, %100 anti-bot LinkedIn güvenliği, ekip içi kotalar ve 7 günlük takip mekanizması.',
    descriptionEn:
      'Automated native language detection in 24 EU languages + TR for 31,400+ EU evaluators, 100% anti-bot safe LinkedIn outreach, team quotas, and automated 7-day follow-up engine.',
    badge: 'Pluggable Python Modülü',
    runtime: 'Python 3.12 / Flask / SQLite & PostgreSQL / requests',
    status: 'INTEGRATED',
    statusLabel: 'Entegre Edilebilir',
    price: '₺4.990 / ay (veya Pro/Enterprise Paketi)',
    allowedPlans: ['Pro', 'Enterprise', 'Outreach Add-on'],
    capabilities: [
      {
        icon: '🇪🇺',
        title: '24 AB Resmi Dili + Türkçe',
        desc: '31.400+ Avrupa fonlama hakemi ve uzmanının etnik/dil ontolojisiyle ana dilini otomatik tespit eder ve yerel dilde kişiselleştirir.',
      },
      {
        icon: '🛡️',
        title: '%100 LinkedIn Güvenli (Anti-Bot)',
        desc: 'Otomasyon botu veya web scraping riski olmadan, 1 tıkla LinkedIn arama bağlantısı ve güvenli panoya kopyalama sağlar.',
      },
      {
        icon: '👥',
        title: 'Ekip İçi Dağıtım ve Kotalar',
        desc: 'Günlük kullanıcı başı limitler (10-50/gün), uzmanlık segment atamaları ve 7 günlük takip (follow-up) mekanizması yönetir.',
      },
      {
        icon: '🔒',
        title: 'GDPR & KVKK Uyumlu Veri Modeli',
        desc: 'Bireysel veri silme (unutulma hakkı) ve güvenli SQLite/PostgreSQL veri tabanı yedeği ile tam regülasyon uyumu sağlar.',
      },
    ],
    technicalSpecs: {
      entrypoint: 'modules/ExpertOutreach/fonbridge_module.py',
      endpoints: [
        'app.py (Etkileşimli Web Paneli)',
        'src/tracker.py (İletişim & Takip Kuyruğu)',
        'src/importer.py (Uzman Verisi & Ontoloji)',
        'src/templates.py (24 Dil Şablon Deposu)',
        'src/exporter.py (Raporlama & CSV Aktarımı)',
      ],
      architecture:
        'Universal Pluggable Integration Entrypoint (FonBridgeOutreachModule sınıfı), SQLite / PostgreSQL çift veri katmanı.',
      security: [
        'Sıfır Scraping: LinkedIn API veya bot kullanmaz, ban riski yoktur',
        'Kullanıcı Başı Günlük Hız Limiti & Kota Kontrolü',
        'GDPR Madde 17 Unutulma Hakkı Entegrasyonu',
      ],
    },
    sampleIntegrationSnippet: `from fonbridge_module import FonBridgeOutreachModule
import sqlite3

# 1. Ana platform veri tabanı bağlantısı ile başlatın
conn = sqlite3.connect("data/fonbridge.db")
outreach_mod = FonBridgeOutreachModule(conn)

# 2. Giriş yapan kullanıcının erişimini denetleyin
has_access, reason = outreach_mod.check_access(current_user)
if has_access:
    # Modül arayüzü ve şablon kuyruğu açılır
    print("Modül aktif, yetki onaylandı")
else:
    # Satış vitrini / upsell gösterilir
    print("Erişim kısıtlı:", reason)`,
  },
  {
    id: 'projec_sum',
    slug: 'projec_sum',
    name: 'Çağrı Özeti Motoru (Project Call Summary Generator)',
    nameEn: 'Project Call Summary Generator',
    version: '1.0.0',
    icon: '📑',
    category: 'ai',
    categoryLabel: 'Yapay Zeka & Analiz',
    categoryLabelEn: 'AI & Call Briefs',
    folderPath: '/modules/ProjecSum',
    descriptionTr:
      'Proje çağrısı belgelerinden (URL, PDF, DOCX, HTML, TXT, MD) 12 bölümlü Türkçe ve İngilizce kapsamlı çağrı özeti, stratejik etki ve gereksinim analizi üreten yapay zeka brifing motoru.',
    descriptionEn:
      'Automated 12-section comprehensive call brief and requirement analyzer from URLs, PDFs, DOCXs, and HTML documents using Claude AI.',
    badge: 'Pluggable AI Blueprint',
    runtime: 'Python 3.12 / Flask / Anthropic Claude / python-docx / pypdf',
    status: 'ACTIVE',
    statusLabel: 'Kullanıma Hazır Servis',
    allowedPlans: ['Basic', 'Pro', 'Ultra', 'Public Sector'],
    capabilities: [
      {
        icon: '⚡',
        title: '12 Bölümlü Stratejik Özet',
        desc: 'Çağrı Amacı, Kapsam, Beklenen Etkiler, Uygunluk Kriterleri, Bütçe & Fonlama Oranları, TRL Düzeyi, Konsorsiyum Şartları ve Puanlama Stratejisi.',
      },
      {
        icon: '📄',
        title: 'Çoklu Belge & URL İşleme',
        desc: 'PDF, DOCX, HTML, TXT, MD veya canlı URL bağlantılarından tek tıkla metin çıkarma, birleştirme ve sentezleme desteği.',
      },
      {
        icon: '🤖',
        title: 'Anthropic Claude LLM Motoru',
        desc: 'Doğrudan şartname kaynak belgelerine dayalı, halüsinasyonu minimize eden derin AB hibe şartname analizi.',
      },
      {
        icon: '🖨️',
        title: 'Yazdır & PDF Dışa Aktarım',
        desc: 'Tek tıkla resmi konsorsiyum toplantı brifingi veya sunum eki olarak yazdırılabilir ve PDF olarak indirilebilir çıktı.',
      },
    ],
    technicalSpecs: {
      entrypoint: 'modules/ProjecSum/cagri_ozet_modulu/__init__.py',
      endpoints: [
        '/ozet/ (Ana Özet Giriş Formu)',
        '/ozet/gonder (Çoklu Belge Yükleme & POST İşleme)',
        'cagri_ozet_modulu.cekirdek (Metin Çıkarıcı & Model Çağrısı)',
        'cagri_ozet.py (Terminal / CLI Arayüzü)',
      ],
      supportedFormats: ['.pdf', '.docx', '.html', '.htm', '.txt', '.md', 'Canlı Web URL'],
      architecture:
        'Flask Blueprint (Kapsamlı .co-ozet stilleri, sayfa parçası / fragment üretimi, sıfır CSS çakışması).',
      security: [
        'Genel IP Filtresi: Yerel ve özel ağ adreslerine bağlantı reddedilir (Anti-SSRF)',
        'Dosya Başına 25 MB ve Toplam 450.000 Karakter Güvenlik Sınırı',
        'Model Çıktısı Doğrulama ve Kaynak Karşılaştırma Mekanizması',
      ],
    },
    sampleIntegrationSnippet: `from cagri_ozet_modulu import ozet_blueprint

# 1. Ana web uygulamasına tek satırla Blueprint ekleyin
app.register_blueprint(ozet_blueprint(url_prefix="/ozet"))

# Sayfa /ozet/ adresinde sitenizin oturum sistemi altında açılır.
# İsteğe bağlı olarak ANTHROPIC_API_KEY ortam değişkeni ile çalışır.`,
  },
  {
    id: 'fonbridge_academy',
    slug: 'academy',
    name: 'Eğitim & Akademi Modülü (Academy & Training)',
    nameEn: 'Grant Lifecycle & Platform Academy',
    version: '1.0.0',
    icon: '🎓',
    category: 'tools',
    categoryLabel: 'Eğitim & Bilgi Deposu',
    categoryLabelEn: 'Academy & Knowledge Base',
    folderPath: '/src/modules/m14',
    descriptionTr:
      'FonBridge sistem ve modül rehberleri ile fon/çağrı arama, ortak bulma, konsorsiyum yönetimi ve hibe teklifi yazımını kapsayan 2 aşamalı interaktif eğitim akademisi.',
    descriptionEn:
      'Interactive 2-stage academy covering platform and module guides, plus end-to-end grant lifecycle from call search to partner networking and proposal writing.',
    badge: 'Yerleşik İnteraktif Akademi',
    runtime: 'Next.js 15 / TypeScript / React / Tailwind CSS',
    status: 'ACTIVE',
    statusLabel: 'Kullanıma Hazır Servis',
    allowedPlans: ['Discover', 'Basic', 'Pro', 'Ultra', 'Public Sector'],
    capabilities: [
      {
        icon: '🖥️',
        title: 'Bölüm 1: Sistem & Modül Kılavuzu',
        desc: 'Genel çalışma alanı yönetimi, roller, 4-Eyes onay mekanizmaları ve M1-M13 modüllerinin adım adım uygulamalı kullanım rehberi.',
      },
      {
        icon: '🌍',
        title: 'Bölüm 2: Proje Yaşam Döngüsü',
        desc: 'Horizon Europe, TÜBİTAK ve ulusal fon çağrı arama, ideal konsorsiyum kurma, Excellence/Impact/Implementation teklif yazımı.',
      },
      {
        icon: '📊',
        title: 'İlerleme & Mini Sınav Takibi',
        desc: 'Yerel depolamada saklanan bölüm tamamlama yüzdesi, her aşama sonu interaktif bilgi kontrol testleri.',
      },
      {
        icon: '📥',
        title: 'Hazır Şablonlar & Kontrol Listeleri',
        desc: 'İndirilebilir AB hibe kontrol listesi, DESCA konsorsiyum sözleşmesi kılavuzu, bütçe & kişi-ay hesaplama rehberi.',
      },
    ],
    technicalSpecs: {
      entrypoint: 'src/modules/m14/manifest.ts',
      endpoints: [
        '/[locale]/[workspace]/training (İngilizce Kanonik Rota)',
        '/[locale]/[workspace]/egitim (Türkçe Yerelleştirilmiş Rota)',
        '/[locale]/[workspace]/akademi (Kısa Takma Ad)',
        'src/modules/m14/content.ts (Müfredat Veri Kaynağı)',
      ],
      supportedFormats: ['Interactive UI', 'Checklistler', 'PDF/Yazdırılabilir Şablonlar', 'Mini Quizler'],
      architecture:
        'Client-side stateful LMS engine with localStorage persistence, filterable course navigation, and zero database bloat.',
      security: [
        'Tenant İzolasyonu: Kullanıcı ilerlemesi tarayıcı tabanlı korunur',
        'RBAC: Member ve üstü roller için eğitim erişimi',
        'Sıfır Dış Bağımlılık: Harici video veya telemetri izleyicisi içermez',
      ],
    },
    sampleIntegrationSnippet: `import { m14Manifest } from '@/modules/m14/manifest';
import { ACADEMY_CURRICULUM } from '@/modules/m14/content';

// 1. Modülün durumunu ve müfredatını çekin
const manifest = m14Manifest;
const totalLessons = ACADEMY_CURRICULUM.flatMap(s => s.lessons).length;

console.log(\`Akademi aktif: \${manifest.name}, Toplam Ders: \${totalLessons}\`);`,
  },
];
