import React from 'react';
import { requireTenantPage } from '@/lib/tenant';
import { moduleGate } from '@/lib/modules/guard';
import { TrainingClient } from './client';

export default async function TrainingPage({
  params,
}: {
  params: Promise<{ locale: string; workspace: string }>;
}) {
  const { locale, workspace } = await params;
  const locked = await moduleGate('M14', locale);
  if (locked) return locked;
  await requireTenantPage(locale);

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 space-y-6">
      <TrainingClient locale={locale} workspace={workspace} />
    </div>
  );
}
