import CallSummaryPage from '../call-summary/page';
export default CallSummaryPage;
