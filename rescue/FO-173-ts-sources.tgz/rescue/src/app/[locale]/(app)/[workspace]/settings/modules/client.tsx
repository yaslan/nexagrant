'use client';

import { PRODUCT_NAME } from '@/lib/brand';
import React, { useState, useTransition, useMemo } from 'react';
import Link from 'next/link';
import { useTranslations } from 'next-intl';
import { getAllManifests, getManifest } from '@/lib/modules/registry';
import { canEnableEntitled, getDisableCascade } from '@/lib/modules/state-machine';
import { ModuleId, ModuleManifest, PlanTier } from '@/lib/modules/types';
import type { ModulesPlanView } from './plan-view';
import { toggleModuleState } from './actions';
import { errorMessage } from '@/lib/errors';
import { useActionErrorText } from '@/lib/hooks/use-action-error-text';
import { PLUGGABLE_MODULES, type PluggableModule } from '@/lib/modules/pluggable';

interface ModulesClientProps {
  /** `null` when the plan could not be read — nothing is shown as active or offered. */
  plan: ModulesPlanView | null;
  tenantName?: string;
  workspace?: string;
  locale?: string;
}

interface ToastMessage {
  id: number;
  type: 'success' | 'error' | 'info';
  text: string;
}

// Module descriptive Turkish explanations and categories
const MODULE_METADATA: Record<
  ModuleId,
  {
    descriptionTr: string;
    descriptionEn: string;
    category: 'core' | 'ai' | 'tools' | 'outreach';
    icon: string;
    tags: string[];
  }
> = {
  M1: {
    descriptionTr:
      'CORDIS veritabanı entegrasyonu, geçmiş AB projeleri, organizasyon profilleri ve ağ merkezilik analitiği.',
    descriptionEn:
      'CORDIS database integration, past EU projects, partner organization profiles, and network centrality analytics.',
    category: 'core',
    icon: '🌐',
    tags: ['CORDIS', 'Big Data', 'Network Graph', 'Partner Intel'],
  },
  M2: {
    descriptionTr:
      'Horizon Europe, Eurostars ve ikili işbirlikleri için şablonlu ve yapay zeka destekli konsept notu oluşturucu.',
    descriptionEn:
      'AI-powered structured concept note architecture generator for Horizon Europe and Eurostars calls.',
    category: 'core',
    icon: '📝',
    tags: ['AI Taslak', 'Konsept Notu', 'G0-G1 Kapısı', 'Horizon'],
  },
  M3: {
    descriptionTr:
      'Teklif gerekçelendirmeleri için AB politika hedefleri, etki göstergeleri ve istatistiki kanıt deposu.',
    descriptionEn:
      'Repository of statistical EU evidence, policy impact benchmarks, and verifiable citations.',
    category: 'core',
    icon: '📊',
    tags: ['Evidence Pack', 'AB Politikaları', 'Etki Kanıtı', 'DoH'],
  },
  M4: {
    descriptionTr:
      'Konsorsiyum ortakları ve irtibat kişileri için kurumsal ilişki yönetimi (CRM) ve iletişim geçmişi.',
    descriptionEn:
      'CRM and engagement intelligence for consortium partners, focal point contacts, and history.',
    category: 'core',
    icon: '👥',
    tags: ['CRM', 'Focal Point', 'İletişim Geçmişi', 'Ortak İlişkileri'],
  },
  M5: {
    descriptionTr:
      'G0-G4 aşama-kapı teklif üretim döngüsü, görev dağılımı, zaman çizelgesi ve onay mekanizmaları.',
    descriptionEn:
      'G0-G4 stage-gate proposal production lifecycle, milestone tracking, and task delegation.',
    category: 'core',
    icon: '🚦',
    tags: ['Stage-Gate', 'G0-G4 Kapıları', 'İş Akışı', 'Zaman Çizelgesi'],
  },
  M6: {
    descriptionTr:
      'AB hakem perspektifiyle Mükemmeliyet, Etki ve Uygulama bölümlerini denetleyen derin yapay zeka puanlama simülasyonu.',
    descriptionEn:
      'Deep AI evaluator lens scoring proposals across Excellence, Impact, and Implementation criteria.',
    category: 'ai',
    icon: '🔬',
    tags: ['Evaluator Lens', 'Hakem Puanı (1-15)', 'ESR Simülasyonu', 'Yapay Zeka'],
  },
  M7: {
    descriptionTr:
      'Üniversite ve araştırma merkezleri için patent/teknoloji portföyünden AB çağrılarına otomatik eşleştirme motoru.',
    descriptionEn:
      'Automatic technology and patent portfolio matching engine against open EU funding calls.',
    category: 'tools',
    icon: '🚀',
    tags: ['TTO', 'Patent Eşleştirme', 'Teknoloji Transferi', 'IP Checklist'],
  },
  M8: {
    descriptionTr:
      'Çağrı gereksinimlerine göre en yüksek kazanma olasılığına sahip ortak ve koordinatörleri öneren akıllı eşleştirici.',
    descriptionEn:
      'Smart consortium matching engine proposing high-win probability partners and coordinators.',
    category: 'ai',
    icon: '🎯',
    tags: ['Konsorsiyum', 'Akıllı Eşleştirme', 'Kazanma Skoru', 'Ağ Liderleri'],
  },
  M9: {
    descriptionTr:
      'Konsorsiyum hazırlık toplantıları için çağrı özeti, partner analizleri ve tartışma gündemi üreten brifing modülü.',
    descriptionEn:
      'Automated meeting briefing packs synthesizing call topics, partner dossiers, and negotiation agendas.',
    category: 'tools',
    icon: '📋',
    tags: ['Toplantı Brifingi', 'Partner Dosyası', 'Gündem', 'Takvim'],
  },
  M10: {
    descriptionTr:
      'Toplantı notlarından otomatik aksiyon planları, mutabakat zabıtları (MoM) ve görev takip belgeleri üretir.',
    descriptionEn:
      'Generates automated minutes of meetings (MoM), bilateral NDAs, and follow-up action logs.',
    category: 'tools',
    icon: '📄',
    tags: ['MoM', 'Aksiyon Planı', 'Çift Onay', 'Takip Belgeleri'],
  },
  M11: {
    descriptionTr:
      'Part A ve Part B başvuru formlarını resmi AB standartlarına uygun formatta tam taslak olarak üreten üst düzey üretim motoru.',
    descriptionEn:
      'Full Application Production engine drafting official Part A & Part B EU standard proposal packages.',
    category: 'ai',
    icon: '⚡',
    tags: ['Part A & Part B', 'Tam Teklif', 'Resmi Şablon', 'Hibe Paketi'],
  },
  M12: {
    descriptionTr:
      '31.400+ Avrupa fonlama hakemi ve uzmanına 24 AB resmi dilinde otomatik ana dil tespiti, güvenli LinkedIn panosu ve kota takip asistanı.',
    descriptionEn:
      'Native language outreach in 24 EU languages for 31,400+ evaluators, 100% LinkedIn-safe clipboard sync, and team outreach quotas.',
    category: 'outreach',
    icon: '✉️',
    tags: ['Uzman İletişimi', '24 AB Dili', 'LinkedIn Anti-Bot', 'Kotalar'],
  },
  M13: {
    descriptionTr:
      'Bağlantı, PDF, DOCX ve metin belgelerinden 12 bölümlü stratejik Türkçe çağrı özeti ve gereksinim analizi üreten yapay zeka motoru.',
    descriptionEn:
      '12-section AI-powered strategic call brief, eligibility matrix, and requirement analyzer from multi-format documents.',
    category: 'ai',
    icon: '📑',
    tags: ['Çağrı Özeti', '12 Bölümlü Analiz', 'PDF/DOCX/Web', 'Gereksinim Matrisi'],
  },
  M14: {
    descriptionTr:
      'FonBridge sistem & modül kullanım kılavuzu ile çağrı arama, ortak bulma ve teklif yazımı dahil tüm proje döngüsü eğitim akademisi.',
    descriptionEn:
      'FonBridge system & module guide and end-to-end grant lifecycle academy covering call discovery, consortium building, and proposal drafting.',
    category: 'tools',
    icon: '🎓',
    tags: ['Eğitim Modülü', 'FonBridge Akademi', 'Proje Yaşam Döngüsü', 'Hibe Rehberi'],
  },
};

const PLAN_BADGES: Record<PlanTier, { label: string; bg: string; text: string }> = {
  basic: { label: 'Basic', bg: 'bg-accent/15 text-accent-ink border border-accent/20', text: 'text-accent-ink' },
  pro: { label: 'Pro', bg: 'bg-ok/15 text-ok border border-ok/20', text: 'text-ok' },
  ultra: { label: 'Ultra', bg: 'bg-amber/15 text-amber border border-amber/20', text: 'text-amber' },
};

let toastSequence = 0;
const nextToastId = () => (toastSequence += 1);

export function ModulesClient({
  plan,
  tenantName,
  workspace = 'default',
  locale = 'tr',
}: ModulesClientProps) {
  const manifests = getAllManifests();

  const [activeModules, setActiveModules] = useState<ModuleId[]>(plan?.activeModules ?? []);
  const [outsidePlanOn, setOutsidePlanOn] = useState<ModuleId[]>(plan?.switchedOnOutsidePlan ?? []);
  const entitledModules = plan?.entitledModules ?? [];
  const badgeTier = plan?.badgeTier ?? null;
  const readOnly = !plan || plan.pilot?.expired === true;
  const [cascadeWarning, setCascadeWarning] = useState<{ target: ModuleId; cascading: ModuleId[] } | null>(null);
  const [isPending, startTransition] = useTransition();
  const errorText = useActionErrorText();
  const t = useTranslations('settings.modules');

  // Filters, Search & View Modes
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<
    'all' | 'core' | 'ai' | 'tools' | 'outreach' | 'pluggable' | 'active'
  >('all');
  const [viewMode, setViewMode] = useState<'grid' | 'table' | 'graph'>('grid');

  // Interactive Inspection & Preview Modals
  const [inspectModule, setInspectModule] = useState<ModuleManifest | null>(null);
  const [inspectPluggable, setInspectPluggable] = useState<PluggableModule | null>(null);
  const [activeSimulator, setActiveSimulator] = useState<
    'expert_outreach' | 'projec_sum' | 'fonbridge_academy' | null
  >(null);

  // Expert Outreach Simulator State
  const [simSelectedLang, setSimSelectedLang] = useState<'de' | 'fr' | 'it' | 'es' | 'tr' | 'pl'>('de');
  const [simExpertName, setSimExpertName] = useState('Dr. Helena Weber');
  const [simCopied, setSimCopied] = useState(false);

  // ProjecSum Simulator State
  const [simCallTopic, setSimCallTopic] = useState('HORIZON-CL5-2026-09-D4: Clean Energy Transition for Smart Cities');
  const [simGenerating, setSimGenerating] = useState(false);
  const [simSummaryReady, setSimSummaryReady] = useState(true);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = nextToastId();
    setToasts((prev) => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  // Filtered Core Manifests
  const filteredManifests = useMemo(() => {
    return manifests.filter((mod) => {
      const meta = MODULE_METADATA[mod.id];
      const isActive = activeModules.includes(mod.id);

      const matchesSearch =
        mod.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.key.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (meta && meta.descriptionTr.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (meta && meta.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())));

      if (!matchesSearch) return false;

      if (selectedCategory === 'pluggable') return false; // Handled in dedicated pluggable section
      if (selectedCategory === 'active') return isActive;
      if (selectedCategory === 'core') return meta?.category === 'core';
      if (selectedCategory === 'ai') return meta?.category === 'ai';
      if (selectedCategory === 'tools') return meta?.category === 'tools';
      if (selectedCategory === 'outreach') return meta?.category === 'outreach' || mod.id === 'M1' || mod.id === 'M4' || mod.id === 'M12';

      return true;
    });
  }, [manifests, searchQuery, selectedCategory, activeModules]);

  // Filtered Pluggable Modules
  const filteredPluggableModules = useMemo(() => {
    if (selectedCategory === 'core' || selectedCategory === 'active') return [];
    return PLUGGABLE_MODULES.filter((mod) => {
      const matchesSearch =
        mod.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.descriptionTr.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.folderPath.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      if (selectedCategory === 'ai' && mod.category !== 'ai') return false;
      if (selectedCategory === 'tools' && mod.category !== 'tools') return false;
      if (selectedCategory === 'outreach' && mod.category !== 'outreach') return false;

      return true;
    });
  }, [searchQuery, selectedCategory]);

  const activeCount = activeModules.length;
  const totalCount = manifests.length;
  const activePercentage = Math.round((activeCount / totalCount) * 100);

  const handleToggle = (id: ModuleId) => {
    const isActive = activeModules.includes(id);

    if (isActive) {
      const cascade = getDisableCascade(id, activeModules);
      if (cascade.length > 0) {
        setCascadeWarning({ target: id, cascading: cascade });
      } else {
        startTransition(async () => {
          setActiveModules((prev) => prev.filter((m) => m !== id));
          try {
            await toggleModuleState(id, 'OFF');
            showToast(`${id} modülü başarıyla devre dışı bırakıldı.`, 'info');
          } catch (e) {
            showToast(errorText(e, () => errorMessage(e, 'Modül kapatılırken hata oluştu.')), 'error');
            setActiveModules((prev) => [...prev, id]);
          }
        });
      }
    } else {
      const check = canEnableEntitled(id, activeModules, entitledModules);
      if (check.allowed) {
        startTransition(async () => {
          setActiveModules((prev) => [...prev, id]);
          try {
            await toggleModuleState(id, 'ON');
            showToast(`${id} modülü başarıyla aktifleştirildi!`, 'success');
          } catch (e) {
            showToast(errorText(e, () => errorMessage(e, 'Modül etkinleştirilirken hata oluştu.')), 'error');
            setActiveModules((prev) => prev.filter((m) => m !== id));
          }
        });
      } else {
        const missing = check.missingDependencies?.length
          ? `Gerekli modüller eksik: ${check.missingDependencies.join(', ')}`
          : check.reason || 'Etkinleştirme kuralı karşılanmadı.';
        showToast(`${id} açılamadı: ${missing}`, 'error');
      }
    }
  };

  const disableOutsidePlan = (id: ModuleId) => {
    startTransition(async () => {
      setOutsidePlanOn((prev) => prev.filter((m) => m !== id));
      try {
        await toggleModuleState(id, 'OFF');
        showToast(`${id} plan dışında açık kalmıştı; kapatıldı.`, 'info');
      } catch (e) {
        showToast(errorText(e, () => errorMessage(e, 'Modül kapatılırken hata oluştu.')), 'error');
        setOutsidePlanOn((prev) => [...prev, id]);
      }
    });
  };

  const confirmDisable = () => {
    if (!cascadeWarning) return;
    const toDisable = [cascadeWarning.target, ...cascadeWarning.cascading];

    startTransition(async () => {
      setActiveModules((prev) => prev.filter((m) => !toDisable.includes(m)));
      const target = cascadeWarning.target;
      const count = toDisable.length;
      setCascadeWarning(null);

      try {
        await toggleModuleState(target, 'OFF');
        showToast(`${target} ve bağlı ${count - 1} alt modül kapatıldı.`, 'info');
      } catch (e) {
        showToast(errorText(e, () => errorMessage(e, 'Modüller kapatılırken hata oluştu.')), 'error');
        setActiveModules((prev) => Array.from(new Set([...prev, ...toDisable])));
      }
    });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-20">
      {/* Toast Notification Stream */}
      <div className="fixed top-5 right-5 z-50 flex flex-col gap-2 pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto px-4 py-3 rounded-xl shadow-xl border text-xs font-semibold flex items-center gap-2.5 transition-all transform animate-in slide-in-from-top-2 backdrop-blur-md ${
              toast.type === 'success'
                ? 'bg-ok/20 text-ok border-ok/40 shadow-ok/10'
                : toast.type === 'error'
                ? 'bg-bad/20 text-bad border-bad/40 shadow-bad/10'
                : 'bg-surface/95 text-ink border-border shadow-xl'
            }`}
          >
            <span className="text-base">{toast.type === 'success' ? '✓' : toast.type === 'error' ? '✕' : 'ℹ'}</span>
            <span>{toast.text}</span>
          </div>
        ))}
      </div>

      {/* Hero & Workspace Status Overview */}
      <div className="relative overflow-hidden bg-surface border border-border rounded-3xl p-6 sm:p-8 md:p-10 shadow-sm transition-all">
        {/* Subtle decorative background gradient */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-accent/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-ok/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          <div className="space-y-3 max-w-3xl">
            <div className="flex items-center gap-2.5 text-xs font-semibold text-muted">
              <Link href={`/${locale}/${workspace}/dashboard`} className="hover:text-ink transition-colors">
                Dashboard
              </Link>
              <span>/</span>
              <span className="text-ink-2">Ayarlar</span>
              <span>/</span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-accent/10 text-accent font-bold">
                <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                Modül & Ekosistem Yönetimi
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold font-heading text-ink tracking-tight">
              Modül ve Yetenek Mimarisi
            </h1>
            <p className="text-xs sm:text-sm text-ink-2 leading-relaxed">
              <strong>{tenantName || workspace}</strong> çalışma alanında AB hibe ve konsorsiyum iş akışlarını
              yönetin. 14 Entegre SaaS modülü (M1-M14) ve <code>/modules/</code> dizininde barındırılan bağımsız
              eklentileri tam kapasiteyle devreye alın.
            </p>
          </div>

          {/* Current Subscription & Plan Tile */}
          <div className="flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-stretch gap-4 bg-ground/80 border border-border/80 p-5 rounded-2xl backdrop-blur-xs min-w-[280px]">
            <div className="w-full">
              <div className="flex items-center justify-between text-xs text-muted font-medium mb-1.5">
                <span>Abonelik Paketi</span>
                <span className="font-mono text-[11px] text-accent font-bold">FonBridge SaaS</span>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={`text-xs font-bold tracking-wide px-3 py-1 rounded-lg ${
                    (badgeTier && PLAN_BADGES[badgeTier]?.bg) || 'bg-surface text-ink border border-border'
                  }`}
                >
                  {plan ? plan.planName : 'Okunamadı'}
                </span>
                {plan?.pilot && (
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                      plan.pilot.expired ? 'bg-bad/15 text-bad border-bad/30' : 'bg-amber/15 text-amber border-amber/20'
                    }`}
                  >
                    {plan.pilot.expired ? 'Pilot Bitti' : 'Kamu Pilotu'}
                  </span>
                )}
              </div>
              {plan?.pilot && (
                <div className="text-[11px] text-muted mt-2">
                  Geçerlilik: <strong>{plan.pilot.lastDay}</strong> · Otomatik yenilenmez
                </div>
              )}
              {plan && !plan.pilot && plan.planId === 'free' && (
                <div className="text-[11px] text-muted mt-2">{t('noSubscription')}</div>
              )}
            </div>

            <Link
              href={`/${locale}/${workspace}/settings/billing`}
              className="w-full text-center text-xs font-bold text-accent bg-surface border border-accent/20 hover:border-accent/40 px-4 py-2.5 rounded-xl shadow-2xs hover:bg-surface-hover transition-all"
            >
              Planı Değiştir →
            </Link>
          </div>
        </div>

        {readOnly && (
          <div role="status" className="mt-6 rounded-2xl border border-bad/30 bg-bad/10 p-4 text-xs text-ink flex items-center gap-3">
            <span className="text-xl">⚠️</span>
            <div>
              {plan
                ? `Ücretsiz pilot ${plan.pilot?.lastDay} tarihinde sona erdi. Çalışma alanı salt okunur moddadır; modül durumları değiştirilemez.`
                : 'Plan ve modül durumu şu anda okunamadı. Sayfayı yenileyip tekrar deneyin.'}
            </div>
          </div>
        )}

        {/* Live Ecosystem Performance KPI Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3.5 mt-8 pt-6 border-t border-border">
          <div className="p-3.5 bg-ground/60 rounded-2xl border border-border">
            <div className="text-xs text-muted font-medium">Çekirdek Modüller</div>
            <div className="text-2xl font-bold text-ink mt-0.5 flex items-baseline gap-1.5">
              <span>{activeCount}</span>
              <span className="text-xs font-normal text-muted">/ {totalCount} Aktif</span>
            </div>
            <div className="w-full bg-border/60 h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-ok h-full rounded-full transition-all duration-500"
                style={{ width: `${activePercentage}%` }}
              />
            </div>
          </div>

          <div className="p-3.5 bg-ground/60 rounded-2xl border border-border">
            <div className="text-xs text-muted font-medium">Kapsam Oranı</div>
            <div className="text-2xl font-bold text-ok mt-0.5">%{activePercentage}</div>
            <div className="text-[11px] text-muted mt-1">Platform hibe kapasitesi</div>
          </div>

          <div className="p-3.5 bg-ground/60 rounded-2xl border border-border">
            <div className="text-xs text-muted font-medium">Yeni Genişletmeler</div>
            <div className="text-2xl font-bold text-accent mt-0.5 flex items-center gap-2">
              <span>M12, M13, M14</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-accent/15 text-accent font-semibold">
                Entegre
              </span>
            </div>
            <div className="text-[11px] text-muted mt-1">Outreach, Özet & Akademi</div>
          </div>

          <div className="p-3.5 bg-ground/60 rounded-2xl border border-border">
            <div className="text-xs text-muted font-medium">Pipeline Zinciri</div>
            <div className="text-2xl font-bold text-ink mt-0.5 font-mono">M1 → M5</div>
            <div className="text-[11px] text-muted mt-1">G0-G4 Kapı Akışı</div>
          </div>

          <div className="p-3.5 bg-ground/60 rounded-2xl border border-border col-span-2 sm:col-span-4 lg:col-span-1">
            <div className="text-xs text-muted font-medium">AI & Puanlama</div>
            <div className="text-2xl font-bold text-purple-600 dark:text-purple-400 mt-0.5">M6, M8, M11, M13</div>
            <div className="text-[11px] text-muted mt-1">Hakem Lensi & Çağrı Sentezi</div>
          </div>
        </div>
      </div>

      {/* Toolbar: Category Tabs, View Switcher & Search */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
        {/* Category Filters */}
        <div className="flex items-center gap-1.5 bg-ground/90 p-1.5 rounded-2xl border border-border text-xs font-semibold overflow-x-auto scrollbar-none">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              selectedCategory === 'all'
                ? 'bg-surface text-ink shadow-xs border border-border/80 font-bold'
                : 'text-muted hover:text-ink'
            }`}
          >
            Tüm Modüller ({totalCount + PLUGGABLE_MODULES.length})
          </button>
          <button
            onClick={() => setSelectedCategory('core')}
            className={`px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              selectedCategory === 'core'
                ? 'bg-surface text-ink shadow-xs border border-border/80 font-bold'
                : 'text-muted hover:text-ink'
            }`}
          >
            Çekirdek İş Akışı (M1-M5)
          </button>
          <button
            onClick={() => setSelectedCategory('ai')}
            className={`px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              selectedCategory === 'ai'
                ? 'bg-surface text-ink shadow-xs border border-border/80 font-bold'
                : 'text-muted hover:text-ink'
            }`}
          >
            Yapay Zeka & Puanlama
          </button>
          <button
            onClick={() => setSelectedCategory('tools')}
            className={`px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              selectedCategory === 'tools'
                ? 'bg-surface text-ink shadow-xs border border-border/80 font-bold'
                : 'text-muted hover:text-ink'
            }`}
          >
            Araçlar & TTO
          </button>
          <button
            onClick={() => setSelectedCategory('outreach')}
            className={`px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              selectedCategory === 'outreach'
                ? 'bg-surface text-ink shadow-xs border border-border/80 font-bold'
                : 'text-muted hover:text-ink'
            }`}
          >
            Ağ & Uzman Ulaşım
          </button>
          <button
            onClick={() => setSelectedCategory('pluggable')}
            className={`px-3.5 py-2 rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
              selectedCategory === 'pluggable'
                ? 'bg-accent text-white shadow-xs font-bold'
                : 'text-accent hover:bg-accent/10 font-bold'
            }`}
          >
            <span>🌟</span>
            <span>Yeni Eklentiler ({PLUGGABLE_MODULES.length})</span>
          </button>
          <button
            onClick={() => setSelectedCategory('active')}
            className={`px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              selectedCategory === 'active'
                ? 'bg-surface text-ink shadow-xs border border-border/80 font-bold'
                : 'text-muted hover:text-ink'
            }`}
          >
            Sadece Açıklar ({activeCount})
          </button>
        </div>

        {/* View Switcher & Search Bar */}
        <div className="flex items-center gap-3">
          {/* View Mode Toggle */}
          <div className="flex items-center bg-ground p-1 rounded-xl border border-border text-xs">
            <button
              onClick={() => setViewMode('grid')}
              title="Kart Görünümü"
              className={`p-1.5 px-2.5 rounded-lg font-semibold transition ${
                viewMode === 'grid' ? 'bg-surface text-ink shadow-2xs border border-border' : 'text-muted hover:text-ink'
              }`}
            >
              ⊞ Kartlar
            </button>
            <button
              onClick={() => setViewMode('table')}
              title="Kompakt Liste"
              className={`p-1.5 px-2.5 rounded-lg font-semibold transition ${
                viewMode === 'table' ? 'bg-surface text-ink shadow-2xs border border-border' : 'text-muted hover:text-ink'
              }`}
            >
              ☰ Liste
            </button>
            <button
              onClick={() => setViewMode('graph')}
              title="Bağımlılık Mimarisi"
              className={`p-1.5 px-2.5 rounded-lg font-semibold transition ${
                viewMode === 'graph' ? 'bg-surface text-ink shadow-2xs border border-border' : 'text-muted hover:text-ink'
              }`}
            >
              🕸️ Akış
            </button>
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-64">
            <input
              type="text"
              placeholder="Modül, teknoloji veya yetenek ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs bg-surface border border-border rounded-xl px-3 py-2 pl-8 text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent"
            />
            <span className="absolute left-2.5 top-2.5 text-muted text-xs">🔍</span>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2 text-muted hover:text-ink text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Pluggable Extensions Showcase Banner */}
      {filteredPluggableModules.length > 0 && selectedCategory !== 'core' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl">🚀</span>
              <div>
                <h2 className="text-lg font-bold font-heading text-ink">
                  /modules/ Dizininden Yüklenen Yeni Genişletmeler
                </h2>
                <p className="text-xs text-muted">
                  Sistem dizininde tespit edilen bağımsız Python & AI modülleri. Ana platformla tam uyumlu çalışır.
                </p>
              </div>
            </div>
            <span className="text-xs font-mono bg-accent/10 text-accent font-bold px-2.5 py-1 rounded-full border border-accent/20">
              2 Pluggable Modül Hazır
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {filteredPluggableModules.map((plug) => (
              <div
                key={plug.id}
                className="bg-gradient-to-br from-surface via-surface to-accent/5 border-2 border-accent/30 rounded-3xl p-6 sm:p-7 shadow-sm hover:shadow-md transition-all flex flex-col justify-between relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full blur-2xl pointer-events-none" />

                <div className="space-y-4 relative z-10">
                  {/* Top Bar: Icon, Folder Path, Badge */}
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl p-2.5 bg-ground border border-border rounded-2xl shadow-2xs">
                        {plug.icon}
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-accent/15 text-accent border border-accent/30">
                            {plug.id.toUpperCase()}
                          </span>
                          <span className="text-[10px] font-mono text-muted bg-ground px-1.5 py-0.5 rounded border border-border">
                            v{plug.version}
                          </span>
                        </div>
                        <h3 className="text-base sm:text-lg font-bold text-ink mt-0.5">{plug.name}</h3>
                      </div>
                    </div>

                    <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-ok/15 text-ok border border-ok/30 whitespace-nowrap">
                      ● {plug.statusLabel}
                    </span>
                  </div>

                  <p className="text-xs text-ink-2 leading-relaxed">{plug.descriptionTr}</p>

                  {/* Capabilities List */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-border/80">
                    {plug.capabilities.slice(0, 4).map((cap, i) => (
                      <div key={i} className="flex items-start gap-2 bg-ground/70 p-2.5 rounded-xl border border-border/60">
                        <span className="text-base shrink-0">{cap.icon}</span>
                        <div>
                          <div className="text-[11px] font-bold text-ink leading-tight">{cap.title}</div>
                          <div className="text-[10px] text-muted line-clamp-2 mt-0.5">{cap.desc}</div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Technical Meta & Specs */}
                  <div className="flex flex-wrap items-center gap-2 text-xs pt-2">
                    <span className="text-muted font-medium text-[11px]">Dizin:</span>
                    <span className="font-mono text-[11px] bg-ground border border-border text-accent px-2 py-0.5 rounded">
                      {plug.folderPath}
                    </span>
                    <span className="text-muted font-medium text-[11px] ml-2">Çalışma Modu:</span>
                    <span className="text-[11px] font-semibold text-ink-2">{plug.price || 'Standart Entegre'}</span>
                  </div>
                </div>

                {/* Footer Action Buttons */}
                <div className="mt-6 pt-4 border-t border-border flex items-center justify-between gap-3 relative z-10">
                  <button
                    onClick={() => setInspectPluggable(plug)}
                    className="text-xs font-semibold text-accent hover:underline flex items-center gap-1"
                  >
                    <span>⚙️ Teknik Yapılandırma & API</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveSimulator(plug.id as 'expert_outreach' | 'projec_sum' | 'fonbridge_academy')}
                      className="text-xs font-bold bg-accent hover:opacity-90 text-white px-4 py-2 rounded-xl transition shadow-xs flex items-center gap-1.5"
                    >
                      <span>🚀</span>
                      <span>Canlı Test Et / Önizle</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* View Mode 1: Core Module Cards (Grid View) */}
      {viewMode === 'grid' && (
        <div className="space-y-4">
          {selectedCategory !== 'pluggable' && (
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold font-heading text-ink">
                Çekirdek ve Entegre Platform Modülleri (M1 - M14)
              </h2>
              <span className="text-xs text-muted">
                {filteredManifests.length} modül görüntüleniyor
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {filteredManifests.map((mod) => {
              const isActive = activeModules.includes(mod.id);
              const meta = MODULE_METADATA[mod.id];
              const check = canEnableEntitled(mod.id, activeModules, entitledModules);
              const isPlanLocked = plan !== null && !entitledModules.includes(mod.id);
              const isOutsidePlanOn = isPlanLocked && outsidePlanOn.includes(mod.id);

              return (
                <div
                  key={mod.id}
                  className={`bg-surface border rounded-2xl p-6 shadow-xs flex flex-col justify-between transition-all hover:shadow-md ${
                    isActive ? 'border-accent/40 ring-1 ring-accent/20' : 'border-border'
                  } ${isPending ? 'opacity-70' : ''}`}
                >
                  <div className="space-y-4">
                    {/* Card Top: ID Badge, Status Tag, Toggle */}
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl p-2.5 bg-ground border border-border rounded-xl">
                          {meta?.icon || '📦'}
                        </span>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-xs bg-ground text-ink-2 px-2 py-0.5 rounded border border-border">
                              {mod.id}
                            </span>
                            <h2 className="text-base font-bold text-ink">{mod.name}</h2>
                          </div>
                          <div className="text-[11px] text-muted font-mono mt-0.5">
                            Key: {mod.key} {mod.version ? `• v${mod.version}` : ''}
                          </div>
                        </div>
                      </div>

                      {/* Status & Switch */}
                      <div className="flex flex-col items-end gap-1.5 shrink-0">
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                            isActive
                              ? 'bg-ok/15 text-ok border border-ok/20'
                              : isPlanLocked
                              ? 'bg-amber/15 text-amber border border-amber/20'
                              : 'bg-ground text-muted border border-border'
                          }`}
                        >
                          {isActive ? '● Aktif' : isPlanLocked ? '🔒 Kilitli' : '○ Pasif'}
                        </span>
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-xs text-ink-2 leading-relaxed">
                      {meta?.descriptionTr || 'Modül fonksiyonu ve otomasyon araçları.'}
                    </p>

                    {/* Feature tags */}
                    {meta?.tags && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {meta.tags.map((tag, idx) => (
                          <span
                            key={idx}
                            className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-ground text-muted border border-border/70"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Dependencies & Plan Requirements */}
                    <div className="space-y-2 pt-2 border-t border-border text-xs">
                      {/* Requires */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-muted font-medium">Gereksinim:</span>
                        {mod.requires.length > 0 ? (
                          mod.requires.map((reqId) => {
                            const isReqActive = activeModules.includes(reqId);
                            return (
                              <span
                                key={reqId}
                                className={`font-mono text-[11px] px-2 py-0.5 rounded border font-semibold flex items-center gap-1 ${
                                  isReqActive
                                    ? 'bg-ok/15 border-ok/30 text-ok'
                                    : 'bg-bad/15 border-bad/30 text-bad'
                                }`}
                                title={isReqActive ? `${reqId} Aktif` : `${reqId} Eksik! Önce bu modül açılmalı.`}
                              >
                                <span>{isReqActive ? '✓' : '✕'}</span>
                                <span>{reqId}</span>
                              </span>
                            );
                          })
                        ) : (
                          <span className="text-muted text-[11px]">Bağımsız (Gereksinim Yok)</span>
                        )}
                      </div>

                      {/* Recommends */}
                      {mod.recommends.length > 0 && (
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-muted font-medium">Önerilen:</span>
                          {mod.recommends.map((recId) => (
                            <span
                              key={recId}
                              className="font-mono text-[11px] bg-ground border border-border text-ink-2 px-1.5 py-0.5 rounded"
                            >
                              {recId}
                            </span>
                          ))}
                        </div>
                      )}

                      {/* Plans & Addons */}
                      <div className="flex items-center gap-2 flex-wrap pt-1">
                        <span className="text-muted font-medium">Planlar:</span>
                        <div className="flex items-center gap-1">
                          {mod.planTiers.map((tier) => (
                            <span
                              key={tier}
                              className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded border border-border ${
                                badgeTier === tier
                                  ? 'bg-accent/15 text-accent-ink font-bold border-accent/30'
                                  : 'bg-ground text-muted'
                              }`}
                            >
                              {tier}
                            </span>
                          ))}
                        </div>
                        {mod.addOnSku && (
                          <span className="text-[10px] bg-purple-500/15 text-purple-400 border border-purple-500/20 px-2 py-0.5 rounded font-mono font-semibold">
                            SKU: {mod.addOnSku}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Card Footer: Action Buttons */}
                  <div className="mt-5 pt-4 border-t border-border flex items-center justify-between gap-3">
                    <div className="text-xs">
                      {!isActive && !check.allowed && (
                        <span className="text-bad font-medium">
                          {isOutsidePlanOn
                            ? 'Plan dışında açık kalmış — kullanılamaz'
                            : isPlanLocked
                            ? 'Plan yükseltmesi gerektirir'
                            : `Eksik bağımlılık: ${check.missingDependencies?.join(', ')}`}
                        </span>
                      )}
                      {isActive && <span className="text-ok font-medium">Kullanıma hazır</span>}
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        role="presentation"
                        onClick={() => setInspectModule(mod)}
                        className="cursor-pointer text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-border hover:bg-surface-hover text-muted hover:text-ink transition inline-flex items-center"
                        title="Modül mimarisi ve tabloları incele"
                      >
                        🔍 İncele
                      </span>

                      {isOutsidePlanOn && (
                        <button
                          onClick={() => disableOutsidePlan(mod.id)}
                          disabled={readOnly || isPending}
                          className={`text-xs font-bold px-4 py-2 rounded-lg transition-all shadow-2xs ${
                            readOnly
                              ? 'bg-ground text-muted border border-border cursor-not-allowed'
                              : 'bg-bad/15 text-bad hover:bg-bad/25 border border-bad/30'
                          }`}
                        >
                          Kapat
                        </button>
                      )}
                      {isPlanLocked && !isActive && plan?.pilot ? (
                        <span className="text-xs font-medium text-muted text-right">{t('pilotLocked')}</span>
                      ) : isPlanLocked && !isActive ? (
                        <Link
                          href={`/${locale}/${workspace}/settings/billing`}
                          className="text-xs font-bold bg-amber hover:opacity-90 text-white px-3 py-1.5 rounded-lg transition shadow-2xs"
                        >
                          {t('upgradeCta')}
                        </Link>
                      ) : (
                        <button
                          onClick={() => handleToggle(mod.id)}
                          disabled={readOnly || (!isActive && !check.allowed)}
                          className={`text-xs font-bold px-4 py-2 rounded-lg transition-all shadow-2xs flex items-center gap-1.5 ${
                            readOnly
                              ? 'bg-ground text-muted border border-border cursor-not-allowed'
                              : isActive
                              ? 'bg-bad/15 text-bad hover:bg-bad/25 border border-bad/30'
                              : check.allowed
                              ? 'bg-accent hover:opacity-90 text-white'
                              : 'bg-ground text-muted border border-border cursor-not-allowed'
                          }`}
                        >
                          {isActive ? <span>Kapat</span> : <span>Etkinleştir</span>}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* View Mode 2: Compact List View */}
      {viewMode === 'table' && (
        <div className="bg-surface border border-border rounded-2xl overflow-hidden shadow-xs">
          <div className="p-4 border-b border-border bg-ground/50 flex items-center justify-between">
            <h3 className="text-sm font-bold font-heading text-ink">Tüm Modüller ve Entegrasyon Matrisi</h3>
            <span className="text-xs text-muted">
              {filteredManifests.length + filteredPluggableModules.length} toplam kayıt
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-ground border-b border-border text-muted uppercase text-[10px] tracking-wider font-semibold">
                <tr>
                  <th className="py-3 px-4">Modül / ID</th>
                  <th className="py-3 px-4">Kategori</th>
                  <th className="py-3 px-4">Bağımlılıklar</th>
                  <th className="py-3 px-4">Plan & Kapsam</th>
                  <th className="py-3 px-4">Durum</th>
                  <th className="py-3 px-4 text-right">Eylemler</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {/* Pluggable modules */}
                {filteredPluggableModules.map((plug) => (
                  <tr key={plug.id} className="hover:bg-accent/5 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl">{plug.icon}</span>
                        <div>
                          <div className="font-bold text-ink flex items-center gap-1.5">
                            <span>{plug.name}</span>
                            <span className="font-mono text-[10px] px-1.5 rounded bg-accent/15 text-accent font-semibold">
                              PLUGGABLE
                            </span>
                          </div>
                          <div className="text-[11px] text-muted font-mono">{plug.folderPath}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-medium text-ink-2">{plug.categoryLabel}</span>
                    </td>
                    <td className="py-3.5 px-4 text-muted">Bağımsız Servis</td>
                    <td className="py-3.5 px-4">
                      <span className="text-[11px] font-semibold text-accent">{plug.price || 'Standart'}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-ok/15 text-ok border border-ok/20">
                        ● {plug.statusLabel}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => setActiveSimulator(plug.id as 'expert_outreach' | 'projec_sum' | 'fonbridge_academy')}
                        className="text-xs font-bold bg-accent text-white px-3 py-1.5 rounded-lg shadow-2xs hover:opacity-90"
                      >
                        🚀 Önizle
                      </button>
                    </td>
                  </tr>
                ))}

                {/* Core modules */}
                {filteredManifests.map((mod) => {
                  const isActive = activeModules.includes(mod.id);
                  const isPlanLocked = plan !== null && !entitledModules.includes(mod.id);

                  return (
                    <tr key={mod.id} className="hover:bg-ground/50 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <span className="text-xl">{MODULE_METADATA[mod.id]?.icon || '📦'}</span>
                          <div>
                            <div className="font-bold text-ink flex items-center gap-1.5">
                              <span>{mod.name}</span>
                              <span className="font-mono text-[10px] bg-ground border border-border px-1.5 rounded text-ink-2">
                                {mod.id}
                              </span>
                            </div>
                            <div className="text-[11px] text-muted font-mono">key: {mod.key}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="capitalize text-muted font-medium">
                          {MODULE_METADATA[mod.id]?.category || 'Core'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        {mod.requires.length > 0 ? (
                          <span className="font-mono text-[10px] bg-ground border border-border px-1.5 py-0.5 rounded">
                            {mod.requires.join(', ')}
                          </span>
                        ) : (
                          <span className="text-muted text-[11px]">—</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="text-[10px] font-mono uppercase bg-ground border border-border px-1.5 py-0.5 rounded">
                          {mod.planTiers.join(', ')}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            isActive
                              ? 'bg-ok/15 text-ok border border-ok/20'
                              : isPlanLocked
                              ? 'bg-amber/15 text-amber border border-amber/20'
                              : 'bg-ground text-muted border border-border'
                          }`}
                        >
                          {isActive ? '● Aktif' : isPlanLocked ? '🔒 Kilitli' : '○ Pasif'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setInspectModule(mod)}
                            className="text-xs text-muted hover:text-ink px-2 py-1 rounded border border-border"
                          >
                            Detay
                          </button>
                          <button
                            onClick={() => handleToggle(mod.id)}
                            disabled={readOnly || (isPlanLocked && !isActive)}
                            className={`text-xs font-bold px-3 py-1.5 rounded-lg ${
                              isActive
                                ? 'bg-bad/15 text-bad hover:bg-bad/25'
                                : 'bg-accent text-white hover:opacity-90'
                            }`}
                          >
                            {isActive ? 'Kapat' : 'Aç'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* View Mode 3: Interactive Visual Architecture / Pipeline Graph */}
      {viewMode === 'graph' && (
        <div className="bg-surface border border-border rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <h3 className="text-lg font-bold font-heading text-ink flex items-center gap-2">
              <span>🕸️</span>
              <span>FonBridge Modüler Bağımlılık & Pipeline Mimarisi</span>
            </h3>
            <p className="text-xs text-muted mt-1">
              Veri katmanlarından nihai başvuru paketine giden hiyerarşik iş akışı ve modül bağımlılık ilişkileri.
            </p>
          </div>

          <div className="space-y-6">
            {/* Stage 1: Data & Intelligence */}
            <div className="bg-ground/50 p-4 rounded-2xl border border-border">
              <div className="text-xs font-bold text-accent uppercase tracking-wider mb-3">
                1. Veri & Pazar İstihbarat Katmanı
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-surface p-3.5 rounded-xl border border-border flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-ink">M1: Partner Intel</div>
                    <div className="text-[10px] text-muted">CORDIS & Ağ Grafiği</div>
                  </div>
                  <span className="font-mono text-[10px] bg-ok/15 text-ok px-2 py-0.5 rounded font-bold">
                    {activeModules.includes('M1') ? 'AKTİF' : 'PASİF'}
                  </span>
                </div>

                <div className="bg-surface p-3.5 rounded-xl border-2 border-accent/40 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-ink flex items-center gap-1">
                      <span>Uzman Ulaşım</span>
                      <span className="text-[9px] bg-accent text-white px-1 rounded font-mono">YENİ</span>
                    </div>
                    <div className="text-[10px] text-muted">31.400+ Hakem / 24 Dil</div>
                  </div>
                  <span className="font-mono text-[10px] bg-accent/15 text-accent px-2 py-0.5 rounded font-bold">
                    PLUGGABLE
                  </span>
                </div>

                <div className="bg-surface p-3.5 rounded-xl border-2 border-purple-500/40 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-ink flex items-center gap-1">
                      <span>Çağrı Özeti</span>
                      <span className="text-[9px] bg-purple-600 text-white px-1 rounded font-mono">YENİ</span>
                    </div>
                    <div className="text-[10px] text-muted">12 Bölümlü AI Analiz</div>
                  </div>
                  <span className="font-mono text-[10px] bg-purple-500/15 text-purple-400 px-2 py-0.5 rounded font-bold">
                    PLUGGABLE
                  </span>
                </div>
              </div>
            </div>

            {/* Stage 2: Proposal Prep */}
            <div className="bg-ground/50 p-4 rounded-2xl border border-border">
              <div className="text-xs font-bold text-accent uppercase tracking-wider mb-3">
                2. Teklif & Ortak Hazırlık Katmanı
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-surface p-3.5 rounded-xl border border-border flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-ink">M2: Concept Note</div>
                    <div className="text-[10px] text-muted">G1 Kavram Notu</div>
                  </div>
                  <span className="font-mono text-[10px] bg-ok/15 text-ok px-2 py-0.5 rounded font-bold">
                    {activeModules.includes('M2') ? 'AKTİF' : 'PASİF'}
                  </span>
                </div>

                <div className="bg-surface p-3.5 rounded-xl border border-border flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-ink">M3: Evidence Pack</div>
                    <div className="text-[10px] text-muted">İstatistiki Kanıtlar</div>
                  </div>
                  <span className="font-mono text-[10px] bg-ok/15 text-ok px-2 py-0.5 rounded font-bold">
                    {activeModules.includes('M3') ? 'AKTİF' : 'PASİF'}
                  </span>
                </div>

                <div className="bg-surface p-3.5 rounded-xl border border-border flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-ink">M4: Focal Point CRM</div>
                    <div className="text-[10px] text-muted">Gereksinim: M1</div>
                  </div>
                  <span className="font-mono text-[10px] bg-ok/15 text-ok px-2 py-0.5 rounded font-bold">
                    {activeModules.includes('M4') ? 'AKTİF' : 'PASİF'}
                  </span>
                </div>
              </div>
            </div>

            {/* Stage 3: Workflow & Matching */}
            <div className="bg-ground/50 p-4 rounded-2xl border border-border">
              <div className="text-xs font-bold text-accent uppercase tracking-wider mb-3">
                3. İş Akışı, Eşleştirme ve Araçlar
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div className="bg-surface p-3.5 rounded-xl border border-border">
                  <div className="font-bold text-xs text-ink">M5: Workflows</div>
                  <div className="text-[10px] text-muted">G0-G4 Kapıları</div>
                </div>
                <div className="bg-surface p-3.5 rounded-xl border border-border">
                  <div className="font-bold text-xs text-ink">M7: TTO Accelerator</div>
                  <div className="text-[10px] text-muted">Patent Portföyü</div>
                </div>
                <div className="bg-surface p-3.5 rounded-xl border border-border">
                  <div className="font-bold text-xs text-ink">M8: Matching</div>
                  <div className="text-[10px] text-muted">Ortak Önerisi</div>
                </div>
                <div className="bg-surface p-3.5 rounded-xl border border-border">
                  <div className="font-bold text-xs text-ink">M9 & M10: Briefs & MoM</div>
                  <div className="text-[10px] text-muted">Toplantı Notları</div>
                </div>
              </div>
            </div>

            {/* Stage 4: Capstone Full Application */}
            <div className="bg-gradient-to-r from-accent/10 via-purple-500/10 to-accent/10 p-5 rounded-2xl border border-accent/30 text-center">
              <div className="inline-block font-mono text-xs font-bold text-accent bg-surface px-3 py-1 rounded-full border border-accent/20 mb-2">
                ZİRVE KATMAN (CAPSTONE)
              </div>
              <h4 className="text-base font-bold text-ink">
                M11: Full Application Production & M6: Evaluator Lens
              </h4>
              <p className="text-xs text-muted max-w-xl mx-auto mt-1">
                Tüm önceki modüllerin çıktılarını (M2, M3, M5, M8) sentezleyerek Part A ve Part B hibe başvurularını
                resmi standartta üretir ve hakem lensiyle değerlendirir.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* No results fallback */}
      {filteredManifests.length === 0 && filteredPluggableModules.length === 0 && (
        <div className="bg-surface border border-border rounded-2xl p-12 text-center text-muted">
          <div className="text-3xl mb-2">🔍</div>
          <h3 className="text-base font-bold text-ink">Aramanızla eşleşen modül bulunamadı</h3>
          <p className="text-xs text-muted mt-1">Arama kriterinizi veya seçili kategori filtrenizi temizlemeyi deneyin.</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
            }}
            className="mt-4 text-xs font-semibold text-accent hover:underline"
          >
            Filtreleri Sıfırla
          </button>
        </div>
      )}

      {/* Simulator Modal 1: Expert Outreach Interactive Assistant */}
      {activeSimulator === 'expert_outreach' && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-surface rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-5 border border-border max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl p-2 bg-ground border border-border rounded-xl">✉️</span>
                <div>
                  <h3 className="text-lg font-bold font-heading text-ink">
                    Uzman Ulaşım Asistanı — Canlı Önizleme
                  </h3>
                  <div className="text-xs text-muted">
                    31.400+ Avrupa Fonlama Hakemine 24 Dilde Güvenli LinkedIn Ulaşımı
                  </div>
                </div>
              </div>
              <button
                onClick={() => setActiveSimulator(null)}
                className="text-muted hover:text-ink text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            <div className="bg-ground p-4 rounded-2xl border border-border space-y-3">
              <label className="text-xs font-bold text-ink block">Örnek Hakem / Değerlendirici Seçin:</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                {[
                  { name: 'Dr. Helena Weber', lang: 'de', country: 'Almanya 🇩🇪', role: 'CL5 Hakemi' },
                  { name: 'Prof. Jean-Luc Moreau', lang: 'fr', country: 'Fransa 🇫🇷', role: 'EIC Hakemi' },
                  { name: 'Dr. Matteo Rossi', lang: 'it', country: 'İtalya 🇮🇹', role: 'Health Hakemi' },
                  { name: 'Dr. Carmen Ortiz', lang: 'es', country: 'İspanya 🇪🇸', role: 'Digital Hakemi' },
                  { name: 'Doç. Dr. Selin Yılmaz', lang: 'tr', country: 'Türkiye 🇹🇷', role: 'TÜBİTAK Hakemi' },
                  { name: 'Dr. Piotr Kowalski', lang: 'pl', country: 'Polonya 🇵🇱', role: 'Civil Security' },
                ].map((exp) => (
                  <button
                    key={exp.name}
                    onClick={() => {
                      setSimExpertName(exp.name);
                      setSimSelectedLang(exp.lang as any);
                    }}
                    className={`p-2.5 rounded-xl border text-left transition ${
                      simExpertName === exp.name
                        ? 'bg-accent/15 border-accent text-accent-ink font-bold'
                        : 'bg-surface border-border text-ink-2 hover:bg-surface-hover'
                    }`}
                  >
                    <div className="font-semibold text-[11px] truncate">{exp.name}</div>
                    <div className="text-[10px] text-muted">{exp.country}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Generated Message Draft Preview */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-ink">
                  Otomatik Algılanan Dil: <span className="uppercase text-accent font-mono">{simSelectedLang}</span> (24 AB Dili)
                </span>
                <span className="text-[11px] text-ok font-semibold">🛡️ %100 Anti-Bot Güvenli</span>
              </div>

              <div className="bg-surface p-4 rounded-xl border border-border text-xs text-ink-2 leading-relaxed font-mono">
                {simSelectedLang === 'de' && (
                  <>
                    Sehr geehrte Frau Dr. Weber,<br /><br />
                    mit großem Interesse verfolge ich Ihre Evaluierungsarbeit im Rahmen von Horizon Europe CL5.
                    Als Koordinator bereiten wir ein innovatives Konsortium im Bereich nachhaltige Energiesysteme vor.
                    Ich würde mich über einen fachlichen Austausch auf LinkedIn freuen.<br /><br />
                    Mit freundlichen Grüßen,<br />
                    FonBridge Consortium Team
                  </>
                )}
                {simSelectedLang === 'fr' && (
                  <>
                    Cher Prof. Moreau,<br /><br />
                    J&apos;ai pris connaissance de vos contributions majeures dans le programme EIC Accelerator.
                    Dans le cadre de notre projet Horizon Europe, nous souhaiterions échanger avec vous sur LinkedIn.<br /><br />
                    Cordialement,<br />
                    FonBridge Consortium Team
                  </>
                )}
                {simSelectedLang === 'tr' && (
                  <>
                    Sayın Hocam,<br /><br />
                    Ufuk Avrupa ve uluslararası fon programlarındaki hakemlik tecrübelerinizi ilgiyle takip ediyoruz.
                    Geliştirdiğimiz yeni konsorsiyum ortaklık modeli kapsamında görüş alışverişinde bulunmak isteriz.<br /><br />
                    Saygılarımla,<br />
                    FonBridge Ekibi
                  </>
                )}
                {simSelectedLang !== 'de' && simSelectedLang !== 'fr' && simSelectedLang !== 'tr' && (
                  <>
                    Dear {simExpertName},<br /><br />
                    We have followed your impactful evaluation work in Horizon Europe. Our consortium is preparing
                    a breakthrough proposal and we would welcome the opportunity to connect with you directly on LinkedIn.<br /><br />
                    Best regards,<br />
                    FonBridge Outreach Lead
                  </>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-border">
              <div className="text-xs text-muted flex items-center gap-1.5">
                <span>⏱️</span>
                <span>7 Günlük Takip Hatırlatması Otomatik Tanımlandı</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setSimCopied(true);
                    setTimeout(() => setSimCopied(false), 2000);
                  }}
                  className="px-4 py-2 text-xs font-bold bg-ground hover:bg-surface-hover border border-border rounded-xl text-ink transition"
                >
                  {simCopied ? '✓ Panoya Kopyalandı' : 'Panoya Kopyala'}
                </button>
                <a
                  href={`https://www.linkedin.com/search/results/all/?keywords=${encodeURIComponent(simExpertName)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 text-xs font-bold bg-accent hover:opacity-90 text-white rounded-xl shadow-xs transition"
                >
                  LinkedIn Profilini Aç ↗
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Simulator Modal 2: Call Summary (ProjecSum) Interactive Analyzer */}
      {activeSimulator === 'projec_sum' && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-surface rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl space-y-5 border border-border max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl p-2 bg-ground border border-border rounded-xl">📑</span>
                <div>
                  <h3 className="text-lg font-bold font-heading text-ink">
                    Çağrı Özeti Motoru (ProjecSum) — Canlı Analiz
                  </h3>
                  <div className="text-xs text-muted">
                    Proje Çağrısı Belgelerinden 12 Bölümlü Stratejik Yönetici Özeti Üretimi
                  </div>
                </div>
              </div>
              <button
                onClick={() => setActiveSimulator(null)}
                className="text-muted hover:text-ink text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-ink block">Analiz Edilecek Çağrı Başlığı veya URL:</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={simCallTopic}
                  onChange={(e) => setSimCallTopic(e.target.value)}
                  className="flex-1 text-xs bg-ground border border-border rounded-xl px-3 py-2.5 text-ink focus:outline-none focus:ring-2 focus:ring-accent"
                />
                <button
                  onClick={() => {
                    setSimGenerating(true);
                    setTimeout(() => {
                      setSimGenerating(false);
                      setSimSummaryReady(true);
                    }, 600);
                  }}
                  disabled={simGenerating}
                  className="px-4 py-2 text-xs font-bold bg-accent text-white rounded-xl hover:opacity-90 transition shrink-0"
                >
                  {simGenerating ? 'Çözümleniyor...' : 'Özetle'}
                </button>
              </div>
            </div>

            {/* 12-Section Generated Breakdown */}
            {simSummaryReady && (
              <div className="bg-ground/70 p-5 rounded-2xl border border-border space-y-4 max-h-96 overflow-y-auto text-xs">
                <div className="border-b border-border pb-3 flex items-center justify-between">
                  <div className="font-bold text-ink text-sm">HORIZON-CL5-2026-09-D4 Stratejik Çağrı Özeti</div>
                  <span className="text-[10px] font-mono bg-ok/15 text-ok px-2 py-0.5 rounded font-bold">
                    12 BÖLÜM TAMAMLANDI
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="bg-surface p-3 rounded-xl border border-border">
                    <div className="font-bold text-accent">1. Çağrı Amacı ve Vizyonu</div>
                    <p className="text-muted text-[11px] mt-1">
                      Kentsel ölçekte karbon nötr ısıtma, mikro şebekeler ve yenilenebilir enerji entegrasyonu.
                    </p>
                  </div>
                  <div className="bg-surface p-3 rounded-xl border border-border">
                    <div className="font-bold text-accent">2. Kapsam ve Tematik Alanlar</div>
                    <p className="text-muted text-[11px] mt-1">
                      Akıllı şehir pilotları, enerji depolama ve dijital ikiz simülasyonları.
                    </p>
                  </div>
                  <div className="bg-surface p-3 rounded-xl border border-border">
                    <div className="font-bold text-accent">3. Bütçe ve Hibe Oranı</div>
                    <p className="text-muted text-[11px] mt-1">
                      Toplam 24M €, proje başı 4-6M € tavsiye edilen bütçe. %100 hibe (KOBİ ve Akademi).
                    </p>
                  </div>
                  <div className="bg-surface p-3 rounded-xl border border-border">
                    <div className="font-bold text-accent">4. TRL Düzeyi</div>
                    <p className="text-muted text-[11px] mt-1">
                      Giriş TRL 4 (Laboratuvar Onayı), Çıkış TRL 7 (Operasyonel Ortamda Demo).
                    </p>
                  </div>
                  <div className="bg-surface p-3 rounded-xl border border-border">
                    <div className="font-bold text-accent">5. Konsorsiyum Asgari Şartı</div>
                    <p className="text-muted text-[11px] mt-1">
                      En az 3 bağımsız tüzel kişilik, en az 3 farklı AB Üye veya İlişkili Ülke.
                    </p>
                  </div>
                  <div className="bg-surface p-3 rounded-xl border border-border">
                    <div className="font-bold text-accent">6. Değerlendirme Eşikleri</div>
                    <p className="text-muted text-[11px] mt-1">
                      Mükemmeliyet (4/5), Etki (4.5/5), Uygulama (4/5). Toplam baraj: 12/15 puan.
                    </p>
                  </div>
                </div>

                <div className="bg-accent/10 border border-accent/20 p-3 rounded-xl">
                  <div className="font-bold text-accent text-[11px]">FonBridge Stratejik İpucu:</div>
                  <p className="text-ink-2 text-[11px] mt-0.5">
                    Bu çağrıda belediyelerin (kamu otoriteleri) ortak veya demonstratör olarak yer alması hakem
                    tarafında etki puanını %25 artırmaktadır. M4 modülü üzerinden belediye partneri eşleştirilmesi önerilir.
                  </p>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-2 border-t border-border">
              <span className="text-xs text-muted">Çıktı Formatı: .co-ozet HTML & Markdown</span>
              <button
                onClick={() => {
                  window.print();
                }}
                className="px-4 py-2 text-xs font-bold bg-accent hover:opacity-90 text-white rounded-xl shadow-xs transition"
              >
                🖨️ Yazdır / PDF İndir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Simulator Modal 3: FonBridge Academy Interactive Preview */}
      {activeSimulator === 'fonbridge_academy' && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-surface rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-6 border border-border max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl p-2 bg-ground border border-border rounded-xl">🎓</span>
                <div>
                  <h3 className="text-lg font-bold font-heading text-ink">
                    Eğitim & Akademi Modülü (M14) — Canlı Önizleme
                  </h3>
                  <p className="text-xs text-muted">
                    Sistem ve modül kullanım kılavuzundan hibe yaşam döngüsüne 2 aşamalı akademi
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveSimulator(null)}
                className="text-muted hover:text-ink w-8 h-8 rounded-full bg-ground border border-border flex items-center justify-center transition"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-ground/60 border border-border p-4 rounded-2xl space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🖥️</span>
                  <span className="font-bold text-sm text-ink">Bölüm 1: Sistem & Modül Kılavuzu</span>
                </div>
                <p className="text-xs text-muted leading-relaxed">
                  Çalışma alanı (Workspace) mimarisi, 4-Eyes çift onay güvenlik standardı ve M1-M14 modüllerinin tek tek uygulamalı iş akışları.
                </p>
                <span className="inline-block text-[11px] font-mono text-accent font-semibold">14 Ders & Kılavuz</span>
              </div>

              <div className="bg-ground/60 border border-border p-4 rounded-2xl space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🌍</span>
                  <span className="font-bold text-sm text-ink">Bölüm 2: Hibe Yaşam Döngüsü</span>
                </div>
                <p className="text-xs text-muted leading-relaxed">
                  Aşama 1 (Çağrı Arama) → Aşama 2 (Konsorsiyum Kurma) → Aşama 3 (Teklif Yazımı) → Aşama 4 (Başvuru & GAP) metodolojisi.
                </p>
                <span className="inline-block text-[11px] font-mono text-ok font-semibold">4 Kapsamlı Aşama + Quiz</span>
              </div>
            </div>

            <div className="bg-accent/5 border border-accent/20 rounded-2xl p-4 flex items-center justify-between gap-3 text-xs">
              <div className="text-ink-2">
                <strong>İlerleme Takibi & Hazır Şablonlar:</strong> Tamamlanan dersler tarayıcıda saklanır; DESCA, EoI ve hibe kontrol listesi içerir.
              </div>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-border">
              <button
                onClick={() => setActiveSimulator(null)}
                className="px-4 py-2 text-xs font-semibold bg-ground border border-border rounded-xl hover:bg-surface-hover text-ink"
              >
                Kapat
              </button>
              <Link
                href={`/${locale}/${workspace}/egitim`}
                onClick={() => setActiveSimulator(null)}
                className="px-5 py-2.5 text-xs font-bold bg-accent hover:opacity-90 text-white rounded-xl shadow-xs transition flex items-center gap-2"
              >
                <span>Akademi Modülünü Aç (Tam Ekran)</span>
                <span>→</span>
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Module Technical Inspector Modal */}
      {inspectModule && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-surface rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl space-y-5 border border-border max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl p-2 bg-ground border border-border rounded-xl">
                  {MODULE_METADATA[inspectModule.id]?.icon || '📦'}
                </span>
                <div>
                  <h3 className="text-lg font-bold font-heading text-ink flex items-center gap-2">
                    <span>{inspectModule.name}</span>
                    <span className="font-mono text-xs bg-ground px-2 py-0.5 rounded border border-border">
                      {inspectModule.id}
                    </span>
                  </h3>
                  <div className="text-xs text-muted font-mono mt-0.5">Key: {inspectModule.key}</div>
                </div>
              </div>
              <button
                onClick={() => setInspectModule(null)}
                className="text-muted hover:text-ink text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <span className="font-bold text-ink block mb-1">Açıklama:</span>
                <p className="text-ink-2 leading-relaxed bg-ground p-3 rounded-xl border border-border">
                  {MODULE_METADATA[inspectModule.id]?.descriptionTr}
                </p>
              </div>

              <div>
                <span className="font-bold text-ink block mb-1">Prisma Veritabanı Tabloları:</span>
                <div className="flex flex-wrap gap-1.5">
                  {inspectModule.tables.map((t) => (
                    <span key={t} className="font-mono bg-ground border border-border px-2 py-0.5 rounded text-ink-2">
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <span className="font-bold text-ink block mb-1">Sahip Olduğu Sayfa Rotaları:</span>
                <div className="bg-ground p-2.5 rounded-xl border border-border space-y-1 font-mono text-[11px]">
                  {inspectModule.routes.map((r) => (
                    <div key={r.path} className="text-muted flex items-center gap-1.5">
                      <span className="text-accent font-bold">/</span>
                      <span>[locale]/[workspace]/{r.path}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <span className="font-bold text-ink block mb-1">Gereksinimler & Bağımlılıklar:</span>
                <div className="text-muted">
                  Zorunlu:{' '}
                  {inspectModule.requires.length > 0 ? (
                    <strong className="text-ink">{inspectModule.requires.join(', ')}</strong>
                  ) : (
                    'Yok (Bağımsız)'
                  )}{' '}
                  · Önerilen:{' '}
                  {inspectModule.recommends.length > 0 ? (
                    <strong className="text-ink">{inspectModule.recommends.join(', ')}</strong>
                  ) : (
                    'Yok'
                  )}
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-border">
              <button
                onClick={() => setInspectModule(null)}
                className="px-4 py-2 text-xs font-semibold bg-ground border border-border rounded-xl hover:bg-surface-hover text-ink"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pluggable Module Inspector Modal */}
      {inspectPluggable && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-surface rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-5 border border-border max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl p-2 bg-ground border border-border rounded-xl">
                  {inspectPluggable.icon}
                </span>
                <div>
                  <h3 className="text-lg font-bold font-heading text-ink flex items-center gap-2">
                    <span>{inspectPluggable.name}</span>
                    <span className="font-mono text-xs bg-accent/15 text-accent px-2 py-0.5 rounded border border-accent/20">
                      {inspectPluggable.badge}
                    </span>
                  </h3>
                  <div className="text-xs text-muted font-mono mt-0.5">{inspectPluggable.folderPath}</div>
                </div>
              </div>
              <button
                onClick={() => setInspectPluggable(null)}
                className="text-muted hover:text-ink text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <span className="font-bold text-ink block mb-1">Çalışma Mimarisi:</span>
                <p className="text-ink-2 leading-relaxed bg-ground p-3 rounded-xl border border-border">
                  {inspectPluggable.technicalSpecs.architecture}
                </p>
              </div>

              <div>
                <span className="font-bold text-ink block mb-1">Güvenlik ve İzolasyon Standartları:</span>
                <ul className="space-y-1 bg-ground p-3 rounded-xl border border-border text-ink-2">
                  {inspectPluggable.technicalSpecs.security.map((sec, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="text-ok">✓</span>
                      <span>{sec}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="font-bold text-ink block mb-1">Entegrasyon Kod Örneği (Python):</span>
                <pre className="bg-ink text-surface p-4 rounded-xl font-mono text-[11px] overflow-x-auto leading-relaxed">
                  {inspectPluggable.sampleIntegrationSnippet}
                </pre>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-border">
              <button
                onClick={() => {
                  const id = inspectPluggable.id as any;
                  setInspectPluggable(null);
                  setActiveSimulator(id);
                }}
                className="text-xs font-bold text-accent hover:underline flex items-center gap-1"
              >
                <span>🚀 Canlı Simülasyonu Başlat</span>
              </button>
              <button
                onClick={() => setInspectPluggable(null)}
                className="px-4 py-2 text-xs font-semibold bg-ground border border-border rounded-xl hover:bg-surface-hover text-ink"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cascade Disable Confirmation Modal */}
      {cascadeWarning && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-surface rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 border border-border">
            <div className="flex items-center gap-3 text-bad">
              <div className="w-10 h-10 rounded-full bg-bad/15 flex items-center justify-center text-xl font-bold">
                ⚠️
              </div>
              <div>
                <h2 className="text-lg font-bold text-ink font-heading">
                  Bağlantılı Modül Kapatma Uyarısı
                </h2>
                <div className="text-xs text-muted">Bu modüle bağlı çalışan diğer modüller etkilenecektir.</div>
              </div>
            </div>

            <p className="text-xs text-ink-2 leading-relaxed">
              <strong className="text-ink">
                {getManifest(cascadeWarning.target)?.name} ({cascadeWarning.target})
              </strong>{' '}
              modülünü kapattığınızda, bu modüle bağımlı çalışan aşağıdaki{' '}
              <strong>{cascadeWarning.cascading.length}</strong> modül de otomatik olarak <strong>devre dışı</strong>{' '}
              bırakılacaktır:
            </p>

            <div className="bg-amber/10 border border-amber/20 rounded-xl p-3 space-y-1.5 max-h-48 overflow-y-auto">
              {cascadeWarning.cascading.map((id) => (
                <div key={id} className="text-xs font-semibold text-amber flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-amber shrink-0"></span>
                  <span className="font-mono bg-surface px-1.5 py-0.5 rounded border border-border text-[10px]">
                    {id}
                  </span>
                  <span>{getManifest(id)?.name}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setCascadeWarning(null)}
                className="px-4 py-2 text-xs font-semibold border border-border rounded-xl hover:bg-surface-hover text-ink-2 transition"
              >
                Vazgeç
              </button>
              <button
                onClick={confirmDisable}
                className="px-4 py-2 text-xs font-bold bg-bad text-white rounded-xl shadow-xs hover:opacity-90 transition"
              >
                Tümünü Kapatmayı Onayla
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Informative Footer Box */}
      <div className="bg-surface border border-border rounded-2xl p-6 text-xs text-ink-2 space-y-3">
        <h4 className="font-bold text-ink text-sm flex items-center gap-2">
          <span>💡</span>
          <span>{PRODUCT_NAME} Modül Mimarisi ve Ekosistem Kuralları</span>
        </h4>
        <p className="leading-relaxed">
          {PRODUCT_NAME} modülleri birbirleriyle tam entegre çalışır. Örneğin <strong>M4 (Focal Point CRM)</strong> modülü{' '}
          <strong>M1 (Partner Intelligence)</strong> veritabanını kullanır; <strong>M11 (Full Application Production)</strong>{' '}
          modülü ise Konsept Notu (M2), Kanıt Paketi (M3), Teklif İş Akışı (M5) ve Konsorsiyum Eşleştirme (M8)
          modüllerinin aktif olmasını gerektirir. <code>/modules/</code> dizinindeki <strong>Uzman Ulaşım Asistanı (ExpertOutreach)</strong>{' '}
          ve <strong>Çağrı Özeti Motoru (ProjecSum)</strong> gibi yeni pluggable modüller ise bağımsız veya hibrit olarak ana sisteme
          bağlanabilir.
        </p>
      </div>
    </div>
  );
}
