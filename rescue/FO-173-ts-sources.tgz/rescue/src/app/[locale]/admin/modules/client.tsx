'use client';

import React, { useState, useTransition, useMemo } from 'react';
import { getAllManifests, getManifest } from '@/lib/modules/registry';
import { ModuleId, ModuleStatus } from '@/lib/modules/types';
import { updateTenantModuleStatus } from './actions';
import { getDisableCascade } from '@/lib/modules/state-machine';
import { errorMessage as toErrorMessage } from '@/lib/errors';
import { PLUGGABLE_MODULES } from '@/lib/modules/pluggable';

interface TenantSummary {
  id: string;
  name: string;
  slug: string;
}

interface AdminModulesClientProps {
  tenants: TenantSummary[];
  initialTenantId: string;
  initialStates: Record<string, Record<string, ModuleStatus>>; // tenantId -> moduleId -> ModuleStatus
}

export function AdminModulesClient({ tenants, initialTenantId, initialStates }: AdminModulesClientProps) {
  const manifests = getAllManifests();

  const [selectedTenantId, setSelectedTenantId] = useState<string>(initialTenantId || tenants[0]?.id || '');
  const [moduleStates, setModuleStates] = useState<Record<string, Record<string, ModuleStatus>>>(initialStates);
  const [cascadeModal, setCascadeModal] = useState<{ target: ModuleId; cascading: ModuleId[] } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'active' | 'dev' | 'pilot' | 'off'>('all');
  const [isPending, startTransition] = useTransition();

  const tenantStates = moduleStates[selectedTenantId] || {};
  const selectedTenant = tenants.find((t) => t.id === selectedTenantId);

  const getModuleStatus = (modId: string): ModuleStatus => {
    return tenantStates[modId] || 'OFF';
  };

  const getActiveModuleIds = (): ModuleId[] => {
    return Object.entries(tenantStates)
      .filter(([_, status]) => status === 'ON' || status === 'PILOT')
      .map(([id, _]) => id as ModuleId);
  };

  const counts = useMemo(() => {
    let on = 0;
    let pilot = 0;
    let dev = 0;
    let off = 0;

    for (const m of manifests) {
      const st = getModuleStatus(m.id);
      if (st === 'ON') on++;
      else if (st === 'PILOT') pilot++;
      else if (st === 'DEV') dev++;
      else off++;
    }

    return { on, pilot, dev, off };
  }, [manifests, tenantStates]);

  const filteredManifests = useMemo(() => {
    return manifests.filter((mod) => {
      const status = getModuleStatus(mod.id);
      const matchesSearch =
        mod.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.key.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      if (selectedFilter === 'active') return status === 'ON';
      if (selectedFilter === 'pilot') return status === 'PILOT';
      if (selectedFilter === 'dev') return status === 'DEV';
      if (selectedFilter === 'off') return status === 'OFF';

      return true;
    });
  }, [manifests, searchQuery, selectedFilter, tenantStates]);

  const handleStatusChange = (modId: ModuleId, targetStatus: ModuleStatus) => {
    setErrorMessage(null);
    setSuccessMessage(null);
    const currentStatus = getModuleStatus(modId);
    if (currentStatus === targetStatus) return;

    const activeMods = getActiveModuleIds();

    if (targetStatus === 'OFF') {
      const cascade = getDisableCascade(modId, activeMods);
      if (cascade.length > 0) {
        setCascadeModal({ target: modId, cascading: cascade });
        return;
      }
    }

    applyStatusChange(modId, targetStatus);
  };

  const applyStatusChange = (modId: ModuleId, targetStatus: ModuleStatus) => {
    const modulesToOff = targetStatus === 'OFF' ? [modId, ...(cascadeModal?.cascading || [])] : [modId];
    setCascadeModal(null);

    startTransition(async () => {
      // Optimistic update
      setModuleStates((prev) => {
        const tenantCopy = { ...(prev[selectedTenantId] || {}) };
        if (targetStatus === 'OFF') {
          for (const m of modulesToOff) {
            tenantCopy[m] = 'OFF';
          }
        } else {
          tenantCopy[modId] = targetStatus;
        }
        return { ...prev, [selectedTenantId]: tenantCopy };
      });

      try {
        await updateTenantModuleStatus(selectedTenantId, modId, targetStatus);
        setSuccessMessage(`${modId} durumu başarıyla "${targetStatus}" olarak güncellendi.`);
        setTimeout(() => setSuccessMessage(null), 3500);
      } catch (e) {
        setErrorMessage(toErrorMessage(e) || 'Modül durumu güncellenemedi.');
        // Revert optimistic update
        setModuleStates(initialStates);
      }
    });
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto py-8 sm:px-4 pb-20">
      {/* Top Header Card */}
      <div className="bg-surface p-6 sm:p-8 rounded-3xl border border-border shadow-xs flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative overflow-hidden">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs px-2.5 py-0.5 rounded-full bg-accent/15 text-accent font-bold">
              PLATFORM YÖNETİCİSİ
            </span>
            <span className="text-xs text-muted">· Tenant Modül Matrisi</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading text-ink">
            Kiracı Modül Durum Yöneticisi
          </h1>
          <p className="text-xs sm:text-sm text-ink-2 max-w-2xl leading-relaxed">
            Seçili kiracı hesabı için 11 çekirdek modülün erişilebilirlik durumunu (OFF, DEV, PILOT, ON) yapılandırın
            ve <code>/modules/</code> dizinindeki bağımsız eklentileri denetleyin.
          </p>
        </div>

        {/* Tenant Selector Box */}
        <div className="flex flex-col sm:flex-row lg:flex-col items-start lg:items-end gap-2 bg-ground p-4 rounded-2xl border border-border w-full lg:w-auto shrink-0">
          <label className="text-xs font-bold text-ink flex items-center gap-1.5">
            <span>🏢</span>
            <span>Yönetilen Kiracı (Tenant):</span>
          </label>
          <select
            value={selectedTenantId}
            onChange={(e) => {
              setSelectedTenantId(e.target.value);
              setErrorMessage(null);
              setSuccessMessage(null);
            }}
            className="border border-border rounded-xl px-3.5 py-2 text-xs bg-surface text-ink shadow-xs focus:outline-none focus:ring-2 focus:ring-accent w-full sm:w-72 font-semibold"
          >
            {tenants.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} ({t.slug})
              </option>
            ))}
          </select>
          {selectedTenant && (
            <div className="text-[11px] text-muted font-mono mt-0.5">
              ID: {selectedTenant.id.slice(0, 16)}...
            </div>
          )}
        </div>
      </div>

      {/* KPI Status Strip for Selected Tenant */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-surface p-4 rounded-2xl border border-border flex items-center justify-between">
          <div>
            <div className="text-xs text-muted font-medium">ON (Tam Açık)</div>
            <div className="text-2xl font-bold text-ok mt-0.5">{counts.on} Modül</div>
          </div>
          <span className="w-3 h-3 rounded-full bg-ok animate-pulse" />
        </div>

        <div className="bg-surface p-4 rounded-2xl border border-border flex items-center justify-between">
          <div>
            <div className="text-xs text-muted font-medium">PILOT (Test)</div>
            <div className="text-2xl font-bold text-amber mt-0.5">{counts.pilot} Modül</div>
          </div>
          <span className="w-3 h-3 rounded-full bg-amber" />
        </div>

        <div className="bg-surface p-4 rounded-2xl border border-border flex items-center justify-between">
          <div>
            <div className="text-xs text-muted font-medium">DEV (Geliştirme)</div>
            <div className="text-2xl font-bold text-accent mt-0.5">{counts.dev} Modül</div>
          </div>
          <span className="w-3 h-3 rounded-full bg-accent" />
        </div>

        <div className="bg-surface p-4 rounded-2xl border border-border flex items-center justify-between">
          <div>
            <div className="text-xs text-muted font-medium">OFF (Kapalı)</div>
            <div className="text-2xl font-bold text-muted mt-0.5">{counts.off} Modül</div>
          </div>
          <span className="w-3 h-3 rounded-full bg-border" />
        </div>
      </div>

      {/* Alerts */}
      {errorMessage && (
        <div className="bg-bad/15 border border-bad/30 p-4 rounded-2xl text-bad text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <span>⚠️</span>
            <span>{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="font-bold text-bad ml-4 text-base">
            &times;
          </button>
        </div>
      )}

      {successMessage && (
        <div className="bg-ok/15 border border-ok/30 p-4 rounded-2xl text-ok text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <span>✓</span>
            <span>{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage(null)} className="font-bold text-ok ml-4 text-base">
            &times;
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 bg-ground p-1.5 rounded-2xl border border-border text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setSelectedFilter('all')}
            className={`px-3 py-1.5 rounded-xl transition ${
              selectedFilter === 'all' ? 'bg-surface text-ink shadow-xs border border-border font-bold' : 'text-muted hover:text-ink'
            }`}
          >
            Tümü ({manifests.length})
          </button>
          <button
            onClick={() => setSelectedFilter('active')}
            className={`px-3 py-1.5 rounded-xl transition ${
              selectedFilter === 'active' ? 'bg-surface text-ink shadow-xs border border-border font-bold' : 'text-muted hover:text-ink'
            }`}
          >
            Aktif / ON ({counts.on})
          </button>
          <button
            onClick={() => setSelectedFilter('pilot')}
            className={`px-3 py-1.5 rounded-xl transition ${
              selectedFilter === 'pilot' ? 'bg-surface text-ink shadow-xs border border-border font-bold' : 'text-muted hover:text-ink'
            }`}
          >
            Pilot ({counts.pilot})
          </button>
          <button
            onClick={() => setSelectedFilter('dev')}
            className={`px-3 py-1.5 rounded-xl transition ${
              selectedFilter === 'dev' ? 'bg-surface text-ink shadow-xs border border-border font-bold' : 'text-muted hover:text-ink'
            }`}
          >
            Dev ({counts.dev})
          </button>
          <button
            onClick={() => setSelectedFilter('off')}
            className={`px-3 py-1.5 rounded-xl transition ${
              selectedFilter === 'off' ? 'bg-surface text-ink shadow-xs border border-border font-bold' : 'text-muted hover:text-ink'
            }`}
          >
            Kapalı / OFF ({counts.off})
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <input
            type="text"
            placeholder="Modül ara (örn: M6, Evaluator)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full text-xs bg-surface border border-border rounded-xl px-3 py-2 pl-8 text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent"
          />
          <span className="absolute left-2.5 top-2.5 text-muted text-xs">🔍</span>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-2 text-muted hover:text-ink text-xs font-bold"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Pluggable Extensions Info Card */}
      <div className="bg-gradient-to-r from-accent/10 via-surface to-accent/5 border border-accent/20 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="text-2xl p-2 bg-surface rounded-xl border border-border">🚀</span>
          <div>
            <h3 className="text-sm font-bold text-ink">Pluggable Modüller (/modules/)</h3>
            <p className="text-xs text-muted">
              {PLUGGABLE_MODULES.length} bağımsız eklenti tespit edildi:{' '}
              {PLUGGABLE_MODULES.map((p) => p.name).join(', ')}.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {PLUGGABLE_MODULES.map((p) => (
            <span
              key={p.id}
              className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-surface border border-border text-accent font-semibold"
            >
              {p.icon} {p.id} ({p.status})
            </span>
          ))}
        </div>
      </div>

      {/* Modules List Grid */}
      <div className="grid gap-4">
        {filteredManifests.map((mod) => {
          const currentStatus = getModuleStatus(mod.id);

          return (
            <div
              key={mod.id}
              className={`bg-surface border border-border rounded-2xl p-5 sm:p-6 shadow-xs transition-all flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 ${
                isPending ? 'opacity-60 pointer-events-none' : ''
              }`}
            >
              <div className="space-y-1.5 max-w-2xl">
                <div className="flex items-center space-x-3">
                  <span className="font-mono text-xs font-bold bg-ground text-ink px-2.5 py-0.5 rounded border border-border">
                    {mod.id}
                  </span>
                  <h3 className="text-base font-bold text-ink">{mod.name}</h3>
                  <span className="text-[11px] text-muted font-mono">v{mod.version}</span>
                </div>

                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-ink-2 pt-1">
                  <div>
                    <span className="font-semibold text-muted">Requires: </span>
                    {mod.requires.length > 0 ? (
                      mod.requires.map((r) => (
                        <span
                          key={r}
                          className="inline-block bg-ground border border-border px-1.5 py-0.5 rounded mr-1 font-mono text-[10px]"
                        >
                          {r}
                        </span>
                      ))
                    ) : (
                      <span className="text-muted">None</span>
                    )}
                  </div>
                  <div>
                    <span className="font-semibold text-muted">Recommends: </span>
                    {mod.recommends.length > 0 ? (
                      mod.recommends.map((r) => (
                        <span
                          key={r}
                          className="inline-block bg-ground border border-border px-1.5 py-0.5 rounded mr-1 font-mono text-[10px]"
                        >
                          {r}
                        </span>
                      ))
                    ) : (
                      <span className="text-muted">None</span>
                    )}
                  </div>
                </div>

                <div className="flex items-center space-x-2 text-xs text-muted pt-0.5">
                  <span className="font-semibold">Plans:</span>
                  {mod.planTiers.map((tier) => (
                    <span
                      key={tier}
                      className="uppercase text-[10px] bg-ground border border-border px-1.5 py-0.5 rounded font-mono"
                    >
                      {tier}
                    </span>
                  ))}
                  {mod.addOnSku && (
                    <span className="text-purple-400 font-semibold bg-purple-500/10 border border-purple-500/20 px-2 py-0.5 rounded text-[10px]">
                      SKU: {mod.addOnSku}
                    </span>
                  )}
                </div>
              </div>

              {/* Status Selector Segmented Buttons */}
              <div className="flex items-center space-x-1.5 bg-ground p-1.5 rounded-xl border border-border w-full lg:w-auto justify-stretch lg:justify-end">
                {(['OFF', 'DEV', 'PILOT', 'ON'] as ModuleStatus[]).map((st) => {
                  const isCurrent = currentStatus === st;

                  let activeStyle = '';
                  if (isCurrent) {
                    switch (st) {
                      case 'OFF':
                        activeStyle = 'bg-ink text-surface shadow-2xs font-bold';
                        break;
                      case 'DEV':
                        activeStyle = 'bg-accent text-white shadow-2xs font-bold';
                        break;
                      case 'PILOT':
                        activeStyle = 'bg-amber text-white shadow-2xs font-bold';
                        break;
                      case 'ON':
                        activeStyle = 'bg-ok text-white shadow-2xs font-bold';
                        break;
                    }
                  } else {
                    activeStyle = 'text-muted hover:bg-surface hover:text-ink';
                  }

                  return (
                    <button
                      key={st}
                      onClick={() => handleStatusChange(mod.id as ModuleId, st)}
                      className={`flex-1 lg:flex-none px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${activeStyle}`}
                    >
                      {st}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Cascade Confirmation Modal */}
      {cascadeModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-surface rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-border">
            <h2 className="text-lg font-bold text-ink flex items-center font-heading">
              ⚠️ Confirm Cascade Disable
            </h2>
            <p className="text-xs text-ink-2">
              Disabling{' '}
              <strong className="text-ink">
                {getManifest(cascadeModal.target)?.name} ({cascadeModal.target})
              </strong>{' '}
              will automatically disable the following dependent modules:
            </p>

            <div className="bg-amber/10 border border-amber/20 rounded-2xl p-3 space-y-1">
              {cascadeModal.cascading.map((id) => (
                <div key={id} className="text-xs font-semibold text-amber flex items-center">
                  <span className="w-2 h-2 rounded-full bg-amber mr-2"></span>
                  {getManifest(id)?.name} ({id})
                </div>
              ))}
            </div>

            <div className="flex justify-end space-x-3 pt-2">
              <button
                onClick={() => setCascadeModal(null)}
                className="px-4 py-2 text-xs font-semibold border border-border rounded-xl hover:bg-surface-hover text-ink-2"
              >
                Cancel
              </button>
              <button
                onClick={() => applyStatusChange(cascadeModal.target, 'OFF')}
                className="px-4 py-2 text-xs font-semibold bg-bad text-white rounded-xl hover:opacity-90 shadow-2xs"
              >
                Disable All Dependent Modules
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
