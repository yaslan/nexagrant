import { ModuleId } from '@/lib/modules/types';
import { WorkspaceRouteKey } from '@/lib/routes';

export type TrainingStage = 'stage1_platform' | 'stage2_grants';

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface LessonSection {
  title: string;
  content: string;
  tips?: string[];
  keyTakeaway?: string;
  checkpoints?: string[];
  codeOrFormula?: string;
}

export interface TrainingLesson {
  id: string;
  stage: TrainingStage;
  moduleRef?: ModuleId | 'GENERAL';
  titleTr: string;
  titleEn: string;
  shortDescTr: string;
  shortDescEn: string;
  category: string;
  categoryEn: string;
  durationMinutes: number;
  level: 'beginner' | 'intermediate' | 'advanced';
  icon: string;
  actionRoute?: WorkspaceRouteKey;
  actionLabelTr?: string;
  actionLabelEn?: string;
  sections: LessonSection[];
  quiz?: QuizQuestion[];
  templates?: {
    title: string;
    description: string;
    fileFormat: string;
    content: string;
  }[];
}

export interface TrainingStageInfo {
  id: TrainingStage;
  titleTr: string;
  titleEn: string;
  subtitleTr: string;
  subtitleEn: string;
  descriptionTr: string;
  descriptionEn: string;
  icon: string;
  badge: string;
  badgeColor: string;
}
