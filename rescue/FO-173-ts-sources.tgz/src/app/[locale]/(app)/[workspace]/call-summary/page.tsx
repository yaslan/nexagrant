import React from 'react';
import { requireTenantPage } from '@/lib/tenant';
import { moduleGate } from '@/lib/modules/guard';
import { CallSummaryClient } from './client';

export default async function CallSummaryPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string; workspace: string }>;
  searchParams?: Promise<{ topicId?: string; title?: string; programme?: string; auto?: string }>;
}) {
  const { locale, workspace } = await params;
  const locked = await moduleGate('M13', locale);
  if (locked) return locked;
  await requireTenantPage(locale);

  const resolvedSearch = searchParams ? await searchParams : {};

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 space-y-6">
      <CallSummaryClient
        locale={locale}
        workspace={workspace}
        initialTopicId={resolvedSearch.topicId}
        initialTitle={resolvedSearch.title}
        initialProgramme={resolvedSearch.programme}
        autoGenerate={resolvedSearch.auto === '1' || resolvedSearch.auto === 'true'}
      />
    </div>
  );
}
