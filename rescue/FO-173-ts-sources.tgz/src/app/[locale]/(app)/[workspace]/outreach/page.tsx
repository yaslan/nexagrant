import React from 'react';
import { requireTenantPage } from '@/lib/tenant';
import { moduleGate } from '@/lib/modules/guard';
import { OutreachClient } from './client';

export default async function OutreachPage({
  params,
}: {
  params: Promise<{ locale: string; workspace: string }>;
}) {
  const { locale, workspace } = await params;
  const locked = await moduleGate('M12', locale);
  if (locked) return locked;
  await requireTenantPage(locale);

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 space-y-6">
      <OutreachClient locale={locale} workspace={workspace} />
    </div>
  );
}
