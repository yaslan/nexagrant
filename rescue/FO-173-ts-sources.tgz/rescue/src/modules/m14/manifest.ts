import { Role } from '@prisma/client';

import { plansGrantingModule } from '@/lib/billing/catalog';
import { ModuleManifest } from '@/lib/modules/types';

export const m14Manifest: ModuleManifest = {
  id: 'M14',
  key: 'training',
  name: 'Academy & Training Module',
  description: 'FonBridge sistem kullanım kılavuzu ve uçtan uca AB/Ulusal proje yaşam döngüsü akademisi.',
  version: '1.0',
  requires: [],
  recommends: ['M1', 'M2', 'M5', 'M6', 'M13'],
  planTiers: plansGrantingModule('M14'),
  addOnSku: null,
  routes: [{ path: 'training', permission: 'training:read' }],
  nav: [{ labelKey: 'training', routeKey: 'training', order: 100 }],
  permissions: [
    { id: 'training:read', minRole: Role.MEMBER },
    { id: 'training:write', minRole: Role.WRITER },
  ],
  tables: ['Call', 'Proposal'],
  isActive: true,
};
